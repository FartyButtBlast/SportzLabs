// Isolated display fixture: does not read or write account data.
import React from 'react';
import {createRoot} from 'react-dom/client';
import ProInsights from '../../src/components/ProInsights';
import type {ProRequest} from '../../src/services/useProAccess';
import type {Insights} from '../../supabase/functions/workout-pro/engine';
import '../../src/styles.css';
const points=[40,45,42,50].map((weight,i)=>({sessionId:`s${i}`,date:`2026-10-0${i+1}T12:00:00Z`,sets:3,reps:24,volume:weight*24,bestWeight:weight,estimatedMax:weight*1.2}));
const result:Insights={days:28,from:'2026-09-11',to:'2026-10-09',previousFrom:'2026-08-14',current:{sessions:4,sets:12,volume:4248},previous:{sessions:0,sets:0,volume:0},weeks:[],exercises:[{id:'bench',name:'Bench Press',points},{id:'row',name:'Row',points:points.slice(0,1)}],muscles:[{name:'chest',sets:12},{name:'back',sets:6},{name:'triceps',sets:3}],personalBests:[],personalBestEvents:[0,1,3].map(i=>({sessionId:`s${i}`,date:points[i].date,exercises:[{id:'bench',name:'Bench Press',records:[{kind:'weight',value:points[i].bestWeight,unit:'kg',date:points[i].date,sessionId:`s${i}`}]}]}))};
const request=(async()=>result) as ProRequest;
createRoot(document.getElementById('root')!).render(<main style={{maxWidth:1100,margin:'0 auto',padding:20}}><ProInsights sessions={[]} userId="fixture" request={request}/></main>);
