import assert from 'node:assert/strict';
import {readFileSync,mkdirSync} from 'node:fs';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
const targets={sets:1,reps:8,weight:50,time:60,distance:1};
const modes=['reps_weight','time_weight','time_distance','time_reps'];
const logs=modes.map((metricMode,i)=>({id:'log'+i,activityId:'fixture'+i,name:['Fixture lift','Fixture hold','Fixture run','Fixture stretch'][i],type:i<2?'strength':i===2?'cardio':'stretching',metricMode,tags:['quads'],planned:targets,rows:[{id:'r'+i,...targets,done:false}]}));
const active={id:'fixture-session',userId:'fixture-user',templateId:'fixture-template',name:'Alignment workout',startedAt:'2026-10-19T00:00:00Z',completedAt:null,activities:logs};
const earlier={...active,id:'old-session',startedAt:'2026-10-18T00:00:00Z',completedAt:'2026-10-18T01:00:00Z',activities:logs.map(a=>({...a,rows:a.rows.map(r=>({...r,done:true,weight:60}))}))};
const saved={version:1,templates:[{id:'fixture-template',userId:'fixture-user',name:'Original routine',description:'Keep me',createdAt:active.startedAt,activities:logs.map(a=>({id:a.id,activityId:a.activityId,targets}))}],customActivities:logs.map(a=>({...a,id:a.activityId,userId:'fixture-user',defaults:targets})),sessions:[earlier],activeSession:active};
const out='artifacts/session-feedback';mkdirSync(out,{recursive:true});
try {
 const context=await browser.newContext({viewport:{width:390,height:844}});
 const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await context.route('**/*',async route=>{
  const url=new URL(route.request().url());
  if(url.hostname!=='127.0.0.1')return route.abort();
  if(url.pathname==='/src/services/auth.ts')return route.fulfill({contentType:'application/javascript',body:'export const supabaseClient=null; export const authConfigurationError=""; export const auth={mode:"local",current:async()=>({id:"fixture-user",name:"Fixture",email:"fixture@example.invalid",verified:true}),subscribe:()=>()=>{},passkeyAvailable:()=>false};'});
  return route.continue();
 });
 await context.addInitScript(data=>{if(!localStorage.getItem('workoutstudio:data:fixture-user'))localStorage.setItem('workoutstudio:data:fixture-user',JSON.stringify(data));},saved);
 await page.goto('http://127.0.0.1:5173/');
 await page.getByRole('button',{name:'Session',exact:true}).click();
 await page.getByRole('heading',{name:'Alignment workout'}).waitFor();
 if(process.env.WORKOUT_THEME)await page.addStyleTag({content:readFileSync(process.env.WORKOUT_THEME,'utf8')});
 assert.match(await page.locator('.exercise-record').first().innerText(),/8 × 60 kg/);
 for(const width of [320,375,390,430,768,1280]){
  await page.setViewportSize({width,height:900});
  const issues=await page.evaluate(()=>{
   const issues=[];if(document.documentElement.scrollWidth>innerWidth)issues.push('page overflow');
   for(const card of document.querySelectorAll('.log-card')){
    const header=card.querySelector('.set-labels');const row=card.querySelector('.set-grid:not(.set-labels)');
    const centers=[...row.children].map(e=>{const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]});
    const heads=[...header.children].map(e=>{const r=e.getBoundingClientRect();return r.x+r.width/2});
    centers.forEach(([x,y],i)=>{if(Math.abs(x-heads[i])>1||Math.abs(y-centers[0][1])>1)issues.push('misaligned '+card.querySelector('h3').textContent+' column '+i)});
    for(const input of row.querySelectorAll('input'))if(parseFloat(getComputedStyle(input).fontSize)<16)issues.push('small input');
   }
   return issues;
  });
  assert.deepEqual(issues,[],`${width}px`);
  if(width===390||width===1280)await page.locator('.log-card').nth(3).screenshot({path:`${out}/session-${width}.png`});
 }
 await page.setViewportSize({width:390,height:844});
 await page.getByRole('button',{name:'Add exercise',exact:true}).click();
 await page.getByRole('textbox',{name:'Find an activity'}).fill('Bench Press');
 await page.locator('.picker-list .activity-item').filter({has:page.getByText('Bench Press',{exact:true})}).click();
 assert.equal(await page.locator('.log-card').count(),5);
 await page.getByRole('button',{name:'Save as new routine',exact:true}).click();
 await page.getByRole('textbox',{name:'Routine name'}).fill('Extended routine');
 await page.getByRole('button',{name:'Save routine',exact:true}).click();
 let stored=await page.evaluate(()=>JSON.parse(localStorage.getItem('workoutstudio:data:fixture-user')));
 assert.deepEqual(stored.templates[0],saved.templates[0]);assert.deepEqual(stored.sessions,saved.sessions);
 assert.equal(stored.templates[1].activities.length,5);assert.equal(stored.activeSession.startedAt,active.startedAt);
 await page.reload();await page.getByRole('button',{name:'Session',exact:true}).click();assert.equal(await page.locator('.log-card').count(),5);
 await page.getByRole('button',{name:'Add exercise',exact:true}).click();
 await page.getByRole('textbox',{name:'Find an activity'}).fill('Fixture custom exercise');
 await page.getByRole('button',{name:'Create custom activity',exact:true}).click();
 await page.getByRole('button',{name:'quads',exact:true}).click();
 await page.getByRole('button',{name:'Create activity',exact:true}).click();
 assert.equal(await page.locator('.log-card').count(),6);
 await page.getByRole('button',{name:'Complete Fixture lift set 1',exact:true}).click();
 await page.getByRole('button',{name:'Finish workout',exact:true}).click();
 await page.getByRole('button',{name:'Save workout',exact:true}).click();
 await page.getByRole('button',{name:'Save as new routine',exact:true}).click();
 await page.getByRole('textbox',{name:'Routine name'}).fill('Completed expanded routine');
 await page.getByRole('button',{name:'Save routine',exact:true}).click();
 stored=await page.evaluate(()=>JSON.parse(localStorage.getItem('workoutstudio:data:fixture-user')));
 assert.equal(stored.activeSession,null);assert.deepEqual(stored.sessions[1],earlier);
 assert.equal(stored.templates.at(-1).activities.length,6);assert.equal(stored.customActivities.at(-1).name,'Fixture custom exercise');
 assert.deepEqual(errors,[]);
 console.log('PASS: 6 viewport widths aligned, PR shown, library/custom additions, save during/after workout, refresh persistence, old data preserved, zero browser errors.');
}finally{await browser.close();}
