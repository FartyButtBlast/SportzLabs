// Local-only browser fixture. Not an application entrypoint or production build input.
import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import '../../src/styles.css';
import ProProgression from '../../src/components/ProProgression';
import ProInsights from '../../src/components/ProInsights';
import {useProAccess} from '../../src/services/useProAccess';
import {supabaseClient} from '../../src/services/auth';
import {createHandler} from '../../supabase/functions/workout-pro/handler';
import type {Template,Session,Activity} from '../../src/data/types';
const win=window as any;win.testMode='free';
const keys=['workouts.progression','workouts.insights.advanced'];
const now=Date.now();
const activity:Activity={id:'bench',userId:null,name:'Bench Press',type:'strength',metricMode:'reps_weight',tags:['chest','triceps'],defaults:{sets:3,reps:10,weight:50,time:0,distance:0}};
const history:Session[]=[2,7,12,19,35].map((days,i)=>({id:'s'+i,userId:'test-user',templateId:'push',name:'Push day',startedAt:new Date(now-days*86400000-3600000).toISOString(),completedAt:new Date(now-days*86400000).toISOString(),activities:[{id:'a'+i,activityId:'bench',name:'Bench Press',type:'strength',metricMode:'reps_weight',tags:['chest','triceps'],planned:activity.defaults,rows:Array.from({length:3},(_,j)=>({id:'r'+j,reps:12,weight:50,time:0,distance:0,done:true}))}]}));
const db={auth:{getUser:async()=>({data:{user:{id:'test-user',email_confirmed_at:'yes'}},error:null})},from(name:string){let rows:any[]=name==='sportzlabs_user_access'?[{user_id:'test-user',tier_id:win.testMode,addon_ids:[]}]:name==='sportzlabs_tiers'?[{id:win.testMode,active:true,capability_keys:win.testMode==='free'?[]:win.testMode==='insights'?[keys[1]]:keys}]:name==='sportzlabs_capabilities'?keys.map(key=>({key,active:true})):[];const q:any={select(){return q;},eq(k:string,v:any){rows=rows.filter(r=>r[k]===v);return q;},in(k:string,v:any[]){rows=rows.filter(r=>v.includes(r[k]));return q;},maybeSingle:async()=>({data:rows[0]||null,error:null}),then:(fn:any)=>Promise.resolve({data:rows,error:null}).then(fn)};return q;}};
const handler=createHandler(db);
if(!supabaseClient)throw new Error('Fixture needs the configured public Supabase client.');
supabaseClient.auth.getSession=(async()=>({data:{session:{user:{id:'test-user'}}},error:null})) as any;
Object.defineProperty(supabaseClient,'functions',{value:{invoke:(async(_:string,options:any)=>{if(win.failAccess)throw new Error('Offline');const response=await handler(new Request('https://fixture.test',{method:'POST',headers:{authorization:'Bearer fixture'},body:JSON.stringify(options.body)}));const data=await response.json();if(!response.ok)return {data:null,error:{context:new Response(JSON.stringify(data),{status:response.status})}};return {data,error:null};}) as any}});
function Preview(){const access=useProAccess('test-user');const [template,setTemplate]=useState<Template>({id:'push',userId:'test-user',name:'Push day',description:'',createdAt:new Date().toISOString(),activities:[{id:'ta',activityId:'bench',targets:activity.defaults}]});return <main style={{maxWidth:900,margin:'auto',padding:16}}><h1>Workout Studio</h1><p>Browser test fixture · no live account changes</p>{access.insights&&<ProInsights sessions={history} userId="test-user" request={access.request}/>} {access.progression&&<ProProgression template={template} activities={[activity]} sessions={history} userId="test-user" request={access.request} onSave={next=>{setTemplate(next);return true;}}/>}</main>;}
createRoot(document.getElementById('root')!).render(<Preview/>);
