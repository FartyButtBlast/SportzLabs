import test from 'node:test';
import assert from 'node:assert/strict';
import {personalBestsForActivity,personalBestCountForSession} from '../src/services/personalBests.ts';
import type {Session} from '../src/data/types.ts';

const base=(id:string,days:number,weight:number):Session=>({id,userId:'u',templateId:'t',name:'Push',startedAt:new Date(Date.parse('2026-10-09T12:00:00Z')-days*86400000).toISOString(),completedAt:new Date(Date.parse('2026-10-09T12:00:00Z')-days*86400000).toISOString(),activities:[{id:`log-${id}`,activityId:'bench',name:'Bench Press',type:'strength',metricMode:'reps_weight',tags:['chest'],planned:{sets:1,reps:8,weight,time:0,distance:0},rows:[{id:`row-${id}`,reps:8,weight,time:0,distance:0,done:true}]}],activeSession:null} as Session);
test('PB badges appear only when a session exceeds earlier exercise records',()=>{
 const old=base('old',20,50),same=base('same',10,50),best=base('best',2,55);
 assert.equal(personalBestsForActivity([old],old,old.activities[0]).length,4);
 assert.equal(personalBestsForActivity([old,same],same,same.activities[0]).length,0);
 assert.equal(personalBestsForActivity([old,same,best],best,best.activities[0]).some(pb=>pb.kind==='weight'),true);
 assert.equal(personalBestCountForSession([old,same,best],best),1);
});
