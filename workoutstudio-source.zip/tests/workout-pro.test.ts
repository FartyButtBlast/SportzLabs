import test from 'node:test';
import assert from 'node:assert/strict';
import {suggest,insights,validateHistory,PROGRESSION,INSIGHTS,type History} from '../supabase/functions/workout-pro/engine.ts';
import {createHandler} from '../supabase/functions/workout-pro/handler.ts';
import {readCapabilities} from '../supabase/functions/workout-pro/access.ts';
const now=Date.parse('2026-10-09T12:00:00Z'),DAY=86400000;
const exercise={id:'bench',name:'Bench Press',type:'strength',metricMode:'reps_weight'};
const target={sets:3,reps:8,weight:50},rule={minReps:8,maxReps:10,increment:2.5};
function session(id:string,days:number,reps=[10,10,10],weight=50):History{return {id,userId:'u',templateId:'push',completedAt:new Date(now-days*DAY).toISOString(),activities:[{activityId:'bench',name:'Bench Press',type:'strength',metricMode:'reps_weight',tags:['chest','triceps'],rows:reps.map(reps=>({reps,weight,done:true}))}]};}
test('progression requires two matching sessions and never modifies the supplied history',()=>{
 const h=[session('1',7),session('2',2)],before=JSON.stringify(h);const next=suggest(h,'push',exercise,target,rule,now);
 assert.equal(next.kind,'increase');assert.equal(next.weight,52.5);assert.equal(next.reps,8);assert.equal(JSON.stringify(h),before);
 assert.equal(suggest([h[0]],'push',exercise,target,rule,now).kind,'hold');
 assert.equal(suggest([session('1',7),session('2',2,[10,9,8])],'push',exercise,target,rule,now).kind,'hold');
});
test('incomplete, changed-load, extra and duplicate exercise sets do not trigger increases',()=>{
 for(const alter of [(s:History)=>{s.activities[0].rows[2].done=false;},(s:History)=>{s.activities[0].rows[0].weight=20;},(s:History)=>{s.activities[0].rows.push({weight:50,reps:10,done:true});},(s:History)=>{s.activities.push(structuredClone(s.activities[0]));},(s:History)=>{s.activities[0].name='Different machine';}]){
  const recent=session('2',2);alter(recent);assert.notEqual(suggest([session('1',7),recent],'push',exercise,target,rule,now).kind,'increase');
 }
});
test('breaks, excessive increments, different workouts and demos do not trigger increases',()=>{
 assert.equal(suggest([session('1',40),session('2',35)],'push',exercise,target,rule,now).kind,'review');
 assert.equal(suggest([session('1',40),session('2',2)],'push',exercise,target,rule,now).kind,'review');
 assert.equal(suggest([session('1',7),session('2',2)],'push',exercise,target,{...rule,increment:10},now).kind,'review');
 assert.equal(suggest([{...session('1',7),templateId:'other'},session('2',2)],'push',exercise,target,rule,now).kind,'hold');
 assert.equal(suggest([{...session('1',7),sample:true},session('2',2)],'push',exercise,target,rule,now).kind,'hold');
});
test('unsupported exercises and invalid rules are rejected',()=>{
 for(const name of ['Assisted Pull Up','Push Up','Band Curl','Clean and Jerk'])assert.throws(()=>suggest([],'push',{...exercise,name},target,rule,now));
 assert.throws(()=>suggest([],'push',{...exercise,metricMode:'time_weight'},target,rule,now));
 for(const patch of [{minReps:0},{maxReps:5},{increment:NaN},{increment:0},{maxReps:31}])assert.throws(()=>suggest([],'push',exercise,target,{...rule,...patch},now));
});
test('insights compare equal periods, ignore skipped/demo work and merge duplicate exercise entries',()=>{
 const recent=session('2',2,[10,10,10]);recent.activities[0].rows[2].done=false;
 recent.activities.push({...structuredClone(recent.activities[0]),rows:[{reps:5,weight:60,done:true}]});
 const r=insights([session('old',29),recent,{...session('demo',1),sample:true}],28,now);
 assert.deepEqual(r.current,{sessions:1,sets:3,volume:1300});assert.deepEqual(r.previous,{sessions:1,sets:3,volume:1500});
 assert.equal(r.weeks.length,4);assert.equal(r.weeks.reduce((n,w)=>n+w.volume,0),1300);assert.equal(r.muscles.find(m=>m.name==='chest')?.sets,3);
 assert.equal(r.exercises[0].points.length,1);assert.equal(r.exercises[0].points[0].estimatedMax,70);
});
test('rolling boundaries, empty history, high-rep estimates and timed work are handled honestly',()=>{
 const boundary=session('boundary',28),prior=session('prior',56),outside=session('outside',57);
 const r=insights([boundary,prior,outside],28,now);assert.equal(r.current.sessions,1);assert.equal(r.previous.sessions,1);
 assert.equal(insights([],84,now).weeks.length,12);assert.equal(insights([],28,now).current.volume,0);
 const high=session('high',2,[15]);assert.equal(insights([high],28,now).exercises[0].points[0].estimatedMax,null);
 const timed=session('timed',2);timed.activities[0].metricMode='time_weight';assert.equal(insights([timed],28,now).current.volume,0);
 assert.throws(()=>insights([],30,now));
});
test('personal bests track exercise records and highlight new records in the selected period',()=>{
 const first=session('first',60,[8,8,8],40);
 const second=session('second',10,[10,10,10],45);
 const third=session('third',2,[10,10,10],45);
 const r=insights([first,second,third],84,now);
 const bench=r.personalBests.find(e=>e.id==='bench');
 assert.equal(bench?.records.find(x=>x.kind==='weight')?.value,45);
 assert.equal(bench?.records.find(x=>x.kind==='volume')?.value,1350);
 assert.equal(r.personalBestEvents.find(e=>e.sessionId==='first')?.exercises[0].records.some(x=>x.kind==='weight'),true);
 assert.equal(r.personalBestEvents.find(e=>e.sessionId==='second')?.exercises[0].records.some(x=>x.kind==='weight'),true);
 assert.equal(r.personalBestEvents.find(e=>e.sessionId==='third'),undefined);
});
test('history validation rejects foreign users, duplicate sessions, negative values and future data',()=>{
 validateHistory([session('ok',1)],'u',now);
 for(const history of [[{...session('bad',1),userId:'another'}],[session('dup',1),session('dup',2)],[session('future',-2)],[session('negative',1,[10],-1)]])assert.throws(()=>validateHistory(history,'u',now));
});
function database({tier='free',keys=[] as string[],inactive=false,addons=[] as any[],capInactive=false,fail=false,user:anyUser={id:'u',email_confirmed_at:'yes'}}={}){
 const rows:Record<string,any[]>={sportzlabs_user_access:[{user_id:'u',tier_id:tier,addon_ids:addons.map(a=>a.id)}],sportzlabs_tiers:[{id:'free',is_default:true,active:true,capability_keys:[]},{id:'pro',is_default:false,active:!inactive,capability_keys:keys}],sportzlabs_addons:addons,sportzlabs_capabilities:[...new Set([...keys,...addons.flatMap(a=>a.capability_keys)])].map(key=>({key,active:!capInactive}))};
 return {rows,auth:{getUser:async()=>({data:{user:anyUser},error:null})},from(name:string){let selected=rows[name]||[];const q:any={select(){return q;},eq(k:string,v:any){selected=selected.filter(r=>r[k]===v);return q;},in(k:string,v:any[]){selected=selected.filter(r=>v.includes(r[k]));return q;},maybeSingle:async()=>({data:selected[0]||null,error:fail?{}:null}),then:(fn:any)=>Promise.resolve({data:selected,error:fail?{}:null}).then(fn)};return q;}};
}
const request=(action:string,extras:object={},token=true)=>new Request('https://example.test',{method:'POST',headers:token?{Authorization:'Bearer verified'}:{},body:JSON.stringify({action,...extras})});
test('free users see no Pro capabilities and cannot call either endpoint, including spoofed claims',async()=>{
 const db=database({user:{id:'u',email_confirmed_at:'yes',email:'derek@sportzlabs.com',user_metadata:{tier:'pro'}}});const handler=createHandler(db,()=>now);
 assert.deepEqual(await (await handler(request('access'))).json(),{capabilities:[]});
 for(const action of ['insights','progression'])assert.equal((await handler(request(action,{capabilities:[PROGRESSION,INSIGHTS],tier:'pro'}))).status,403);
});
test('each active capability independently gates the computation, and revocation takes effect next request',async()=>{
 const db=database({tier:'pro',keys:[INSIGHTS]});const handler=createHandler(db,()=>now);
 const result=await handler(request('insights',{history:[session('1',1)],days:28}));assert.equal(result.status,200);assert.equal((await result.json()).result.current.sessions,1);
 assert.equal((await handler(request('progression'))).status,403);
 db.rows.sportzlabs_user_access[0].tier_id='free';assert.equal((await handler(request('insights',{history:[],days:28}))).status,403);
});
test('active assignments, add-ons and capability status resolve without client claims',async()=>{
 assert.deepEqual(await readCapabilities(database({tier:'pro',keys:[INSIGHTS],inactive:true}),'u'),[]);
 assert.deepEqual(await readCapabilities(database({tier:'pro',keys:[INSIGHTS],capInactive:true}),'u'),[]);
 assert.deepEqual(await readCapabilities(database({addons:[{id:'extra',active:true,capability_keys:[PROGRESSION]}]}),'u'),[PROGRESSION]);
 assert.deepEqual(await readCapabilities(database({addons:[{id:'extra',active:false,capability_keys:[PROGRESSION]}]}),'u'),[]);
 const db=database();db.rows.sportzlabs_user_access=[];assert.deepEqual(await readCapabilities(db,'u'),[]);
});
test('invalid authentication, access failures, malformed input and oversized bodies fail closed',async()=>{
 assert.equal((await createHandler(database())(request('access',{},false))).status,401);
 for(const user of [null,{id:'u',email_confirmed_at:null},{id:'u',email_confirmed_at:'yes',is_anonymous:true}])assert.equal((await createHandler(database({user}))(request('access'))).status,401);
 assert.equal((await createHandler(database({fail:true}))(request('access'))).status,503);
 const handler=createHandler(database({tier:'pro',keys:[INSIGHTS,PROGRESSION]}),()=>now);
 assert.equal((await handler(request('insights',{history:[{...session('1',1),userId:'other'}],days:28}))).status,400);
 assert.equal((await handler(request('access',{padding:'x'.repeat(2*1024*1024)}))).status,413);
 const p=await handler(request('progression',{history:[session('1',7),session('2',2)],exercise,target,rule,templateId:'push'}));assert.equal(p.status,200);assert.equal((await p.json()).result.weight,52.5);
});
