import test from 'node:test';
import assert from 'node:assert/strict';
import {moveExercise} from '../src/components/ExerciseOrder.tsx';
test('Exercise reordering preserves row identities and recording references',()=>{
 const a={id:'a',rows:[{id:'set-a',done:true}]},b={id:'b',rows:[]},c={id:'c',rows:[]};const original=[a,b,c];
 assert.deepEqual(moveExercise(original,2,0),[c,a,b]);assert.deepEqual(original,[a,b,c]);
 assert.equal(moveExercise(original,0,1)[1],a);
 assert.equal(moveExercise(original,0,-1),original);assert.equal(moveExercise(original,2,3),original);
});
