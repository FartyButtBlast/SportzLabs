import test from 'node:test';
import assert from 'node:assert/strict';
import {isOwner,validateExercise,validateCapability,validateTier,validateAddon,validAppUrl,EVENTS} from '../supabase/functions/platform-admin/policy.ts';
test('owner requires a verified, non-anonymous email, never user metadata',()=>{
 assert.equal(isOwner({email:'derek@sportzlabs.com'}),false);
 assert.equal(isOwner({email:'Derek@SportzLabs.com',email_confirmed_at:'2026-10-07'}),true);
 assert.equal(isOwner({email:'attacker@example.com',email_confirmed_at:'2026-10-07',user_metadata:{role:'admin',email:'derek@sportzlabs.com'}} as any),false);
 assert.equal(isOwner({email:'derek@sportzlabs.com',email_confirmed_at:'2026-10-07',is_anonymous:true}),false);
});
const exercise={id:'new-squat',name:' Squat ',description:'Keep control.',type:'strength',tags:['quads'],defaults:{sets:3,reps:10,weight:20,time:0,distance:0}};
test('catalogue rejects malformed fields and strips client ownership',()=>{
 assert.equal(validateExercise({...exercise,userId:'someone',secret:'bad'}).userId,null);
 assert.equal(validateExercise(exercise).name,'Squat');
 for(const patch of [{tags:['invalid']},{description:'x'.repeat(4001)},{defaults:{...exercise.defaults,sets:31}},{defaults:{...exercise.defaults,sets:1.5}},{defaults:{...exercise.defaults,weight:-1}},{type:'unknown'},{name:''},{id:'../../x'}])assert.throws(()=>validateExercise({...exercise,...patch}));
});
test('app URLs cannot execute scripts or contain embedded credentials',()=>{
 assert.equal(validAppUrl('https://www.sportzlabs.com/workoutstudio/'),true);
 for(const url of ['javascript:alert(1)','http://example.com','https://secret:password@example.com','/relative'])assert.equal(validAppUrl(url),false);
});
test('usage event allowlist excludes arbitrary personal data',()=>{
 assert.equal(EVENTS.has('page:Home'),true);assert.equal(EVENTS.has('workout:completed'),true);assert.equal(EVENTS.has('page:/?email=secret@example.com'),false);
});
test('access configuration accepts stable capability keys and valid tier/add-on definitions',()=>{
 assert.deepEqual(validateCapability({key:'workouts.export',name:' Export workouts ',description:'Download completed sessions.',active:true}),{key:'workouts.export',name:'Export workouts',description:'Download completed sessions.',active:true});
 assert.deepEqual(validateTier({id:'pro',name:' Pro ',description:'Advanced tools.',active:true,sort_order:10,capability_keys:['workouts.plan','workouts.track']}),{id:'pro',name:'Pro',description:'Advanced tools.',active:true,sort_order:10,capability_keys:['workouts.plan','workouts.track']});
 assert.deepEqual(validateAddon({id:'reports',name:'Reports',description:'Extra charts.',active:true,capability_keys:['workouts.history']}),{id:'reports',name:'Reports',description:'Extra charts.',active:true,capability_keys:['workouts.history']});
 for(const value of [{key:'../x',name:'Bad',description:'',active:true},{key:'x',name:'',description:'',active:true}])assert.throws(()=>validateCapability(value));
 assert.throws(()=>validateTier({id:'pro',name:'Pro',description:'',active:true,sort_order:-1,capability_keys:[]}));
 assert.throws(()=>validateAddon({id:'reports',name:'Reports',description:'',active:true,capability_keys:['bad key']}));
});
