import test from 'node:test';
import assert from 'node:assert/strict';
import {startSession} from '../src/services/startSession.ts';
import {seedData,library} from '../src/data/seed.ts';
import {shareDraft} from '../src/services/strava.ts';
import {validateShare} from '../supabase/functions/strava/payload.ts';
import {allowedRedirect} from '../supabase/functions/strava/oauth.ts';
import {exerciseCatalog,sportTypes} from '../supabase/functions/strava/catalog.ts';
import {mergeCatalog} from '../src/services/platform.ts';
import {validateStrength} from '../supabase/functions/strava/strength.ts';
const template=seedData('u').templates[0];
const first=startSession(template,library,[],'u','2026-01-01T08:00:00Z');
const completed={...first,completedAt:'2026-01-01T09:00:00Z',activities:first.activities.map(a=>({...a,rows:[{...a.rows[0],reps:11,weight:42.5,time:65,distance:0.5,done:true,completedAt:'2026-01-01T08:30:00Z'},{...a.rows[1],reps:999,done:false}]}))};
test('Starting again copies only completed sets, preserves history and clears completion metadata',()=>{
 const saved=JSON.stringify(completed);
 const next=startSession(template,library,[completed],'u','2026-01-02T08:00:00Z');
 assert.equal(next.activities[0].rows.length,3);
 const row=next.activities[0].rows[0];assert.equal(row.reps,11);assert.equal(row.weight,42.5);assert.equal(row.done,false);assert.equal(row.completedAt,undefined);assert.notEqual(row.id,completed.activities[0].rows[0].id);assert.equal(row.previousSetId,completed.activities[0].rows[0].id);assert.equal(next.activities[0].previousSessionId,completed.id);assert.equal(JSON.stringify(completed),saved);
 assert.deepEqual(next.units,{weight:'kg',distance:'km',time:'s'});
});
test('an accepted progression target fills the next session instead of copying old weights',()=>{
 const updated={...template,activities:template.activities.map((a,i)=>i===0?{...a,targets:{...a.targets,sets:3,reps:8,weight:52.5},useTargetsNextSession:true}:a)};
 const next=startSession(updated,library,[completed],'u','2026-01-02T08:00:00Z');
 assert.equal(next.activities[0].rows.length,3);
 assert.ok(next.activities[0].rows.every(r=>r.weight===52.5&&r.reps===8&&!r.done));
 assert.equal(next.activities[1].rows[0].weight,42.5);
 assert.equal(completed.activities[0].rows[0].weight,42.5);
});
test('Other accounts, samples, unfinished workouts and future sessions cannot seed new values',()=>{
 for(const patch of [{userId:'someone-else'},{sample:true},{completedAt:null},{completedAt:'2027-01-01T00:00:00Z'}]){
  const next=startSession(template,library,[{...completed,...patch}],'u','2026-01-02T08:00:00Z');
  assert.equal(next.activities[0].rows[0].reps,template.activities[0].targets.reps);assert.equal(next.activities[0].previousSessionId,undefined);
 }
});
test('Timed holds send duration and weight; running sends metres without strength JSON',()=>{
 const base={...completed,activities:[{...completed.activities[0],name:'Plank',metricMode:'time_weight' as const,stravaExerciseType:'PLANK_GENERIC',stravaSportType:'WeightTraining'}]};
 const hold=validateShare(shareDraft(base));assert.deepEqual(hold.strength?.sets,[{exercise_type:'PLANK_GENERIC',duration:65,weight:42.5}]);
 const run=validateShare(shareDraft({...base,activities:[{...base.activities[0],name:'Outdoor Run',type:'cardio',metricMode:'time_distance',stravaSportType:'Run',stravaExerciseType:'RUNNING'}]}));
 assert.equal(run.sportType,'Run');assert.equal(run.distance,500);assert.equal(run.strength,undefined);
});
test('Full Strava taxonomy and native callback allowlist reject unsupported data and unsafe redirects',()=>{
 assert.equal(exerciseCatalog.length,656);assert.equal(new Set(exerciseCatalog.map(e=>e.code)).size,656);assert.equal(sportTypes.length,56);
 assert.ok(allowedRedirect('workoutstudio://www.sportzlabs.com/strava/callback'));
 for(const url of ['workoutstudio://evil.test/strava/callback','https://evil.test/workoutstudio/','https://www.sportzlabs.com/workoutstudio/?next=evil','javascript:alert(1)'])assert.equal(allowedRedirect(url),false);
});
test('Every recognised Strava exercise is a default and can be uploaded with its exact identifier',()=>{
 for(const entry of exerciseCatalog){
  const activity=library.find(a=>a.stravaExerciseType===entry.code);
  assert.ok(activity,`Missing default exercise: ${entry.code}`);
  assert.equal(activity.userId,null);
  assert.equal(activity.stravaCategory,entry.category);
  assert.equal(validateStrength({utcOffset:0,sets:[{exercise_type:activity.stravaExerciseType,repetitions:1}]}).sets[0].exercise_type,entry.code);
 }
 assert.equal(new Set(library.map(a=>a.id)).size,library.length);
});
test('An older cached catalogue still receives every default exercise without duplicate IDs',()=>{
 const oldCatalog=library.slice(0,8);
 const merged=mergeCatalog(oldCatalog);
 for(const entry of exerciseCatalog)assert.ok(merged.some(a=>a.stravaExerciseType===entry.code),entry.code);
 assert.equal(new Set(merged.map(a=>a.id)).size,merged.length);
 assert.deepEqual(merged.filter(a=>oldCatalog.some(old=>old.id===a.id)),oldCatalog);
});
