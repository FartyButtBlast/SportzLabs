import test from 'node:test';
import assert from 'node:assert/strict';
import {parseHeartRate,parseTemperature,appendSensorSample,sensorSummary} from '../src/services/sensors.ts';
const view=(...bytes:number[])=>new DataView(Uint8Array.from(bytes).buffer);
test('Heart rate decodes 8/16-bit values and rejects truncation, no contact, and invalid readings',()=>{
 assert.equal(parseHeartRate(view(0,123)),123);assert.equal(parseHeartRate(view(1,4,1)),260);
 for(const v of [view(),view(1,123),view(4,100),view(0,0),view(1,255,255)])assert.equal(parseHeartRate(v),null);
 assert.equal(parseHeartRate(view(6,89)),89);
});
test('Temperature decodes Celsius/Fahrenheit and location, rejects missing optional fields and special values',()=>{
 assert.deepEqual(parseTemperature(view(4,109,1,0,255,2)),{celsius:36.5,location:'Body (general)'});
 assert.equal(parseTemperature(view(1,218,3,0,255))?.celsius,37);
 for(const v of [view(),view(4,109,1,0,255),view(2,109,1,0,255),view(0,255,255,127,0)])assert.equal(parseTemperature(v),null);
});
test('Recording throttles observations but preserves exercise transitions and rest',()=>{
 const s={at:10000,heartRate:100,exerciseId:'squat',source:'strap'};
 let samples=[s];assert.equal(appendSensorSample(samples,{...s,at:11000}),samples);
 samples=appendSensorSample(samples,{...s,at:11000,exerciseId:'row',heartRate:140});
 samples=appendSensorSample(samples,{...s,at:12000,exerciseId:null,heartRate:80});
 assert.equal(sensorSummary(samples,'squat').average,100);assert.equal(sensorSummary(samples,'row').max,140);assert.equal(sensorSummary(samples,null).count,1);
 assert.equal(sensorSummary(samples,'missing').average,null);
});
