import test from 'node:test';
import assert from 'node:assert/strict';
import { validateShare } from '../supabase/functions/strava/payload.ts';
import { shareDraft } from '../src/services/strava.ts';
import type { Session } from '../src/data/types.ts';
const session: Session = {id:'99e4be10-641c-489e-812c-16165b7e1e0d',userId:'user',templateId:'template',name:'Morning strength',startedAt:'2026-01-05T08:00:00Z',completedAt:'2026-01-05T08:40:00Z',activities:[{id:'a',activityId:'squat',name:'Squat',type:'strength',tags:['quads'],planned:{sets:2,reps:8,weight:60,time:0,distance:0},rows:[{id:'1',reps:8,weight:60,time:0,distance:0,done:true},{id:'2',reps:99,weight:900,time:0,distance:0,done:false}]}]};
test('Strava draft includes only completed work and preserves the start instant',()=>{
 const draft=shareDraft(session);assert.equal(draft.elapsedTime,2400);assert.equal(draft.sportType,'WeightTraining');assert.match(draft.description,/8 reps × 60 kg/);assert.doesNotMatch(draft.description,/900|99 reps/);assert.equal(Date.parse(draft.startedAt),Date.parse(session.startedAt));assert.deepEqual(validateShare(draft),draft);
});
test('Unfinished, sample and empty workouts cannot be shared',()=>{assert.throws(()=>shareDraft({...session,completedAt:null}));assert.throws(()=>shareDraft({...session,sample:true}));assert.throws(()=>shareDraft({...session,activities:[]}));});
test('API validates duration, identifier, type and text limits',()=>{const d=shareDraft(session);for(const patch of [{elapsedTime:0},{elapsedTime:NaN},{elapsedTime:1.5},{elapsedTime:604801},{sessionId:'other'},{sportType:'invalid'},{name:' '},{description:'x'.repeat(4001)},{startedAt:'not-a-date'}])assert.throws(()=>validateShare({...d,...patch}));});
test('Heart-rate summaries require opt-in and temperature is never included',()=>{
 const s={...session,sensorSamples:[{at:1,exerciseId:'a',source:'strap',heartRate:120},{at:5001,exerciseId:'a',source:'strap',heartRate:160},{at:6001,exerciseId:'a',source:'thermometer',temperatureC:36.5}]};
 assert.doesNotMatch(shareDraft(s).description,/bpm|36.5/);
 assert.match(shareDraft(s,true).description,/140 bpm/);assert.match(shareDraft(s,true).description,/160 bpm/);assert.doesNotMatch(shareDraft(s,true).description,/36.5|temperature/i);
});
