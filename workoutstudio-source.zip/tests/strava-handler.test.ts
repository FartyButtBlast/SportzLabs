import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as uploads from '../supabase/functions/strava/upload.ts';
import * as payload from '../supabase/functions/strava/payload.ts';
import * as fit from '../supabase/functions/strava/fit.ts';
import * as oauth from '../supabase/functions/strava/oauth.ts';

const source=ts.transpileModule(readFileSync('supabase/functions/strava/index.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const workout={sessionId:'99e4be10-641c-489e-812c-16165b7e1e0d',name:'Regression workout',sportType:'WeightTraining',startedAt:'2026-01-05T08:00:00Z',elapsedTime:2400,description:'Back Squat: 8 reps at 60 kg',strength:{utcOffset:39600,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:8,weight:60}]}};
function fixture(responses:Array<Response|Error>,previous:any=null,user:any={id:'athlete'}){
 let handler:(req:Request)=>Promise<Response>;
 let post=previous;
 const requests:Array<{url:string;body:any}>=[];
 const connection={athlete_id:123,access_token:'fixture-only',refresh_token:'fixture-only',expires_at:Date.now()/1000+3600};
 const db={auth:{getUser:async()=>({data:{user},error:null})},rpc:async()=>({error:null}),from(name:string){
  let operation='select';let value:any;const filters:Record<string,any>={};
  const result=()=>{
   if(name==='workoutstudio_strava_posts'){
    assert.equal(operation==='upsert'?value.user_id:filters.user_id,'athlete');
    if(operation==='update')post={...post,...value};
    if(operation==='upsert')post={...post,...value};
    return {data:post,error:null};
   }
   return {data:name==='sportzlabs_integrations'?{client_id:'123',client_secret:'fixture-only',enabled:true}:connection,error:null};
  };
  const q:any={select(){return q;},eq(k:string,v:any){filters[k]=v;return q;},lt(){return q;},update(v:any){operation='update';value=v;return q;},upsert(v:any){operation='upsert';value=v;return q;},maybeSingle:async()=>result(),then(resolve:any){return Promise.resolve(result()).then(resolve);}};
  return q;
 }};
 vm.runInNewContext(source,{exports:{},require:(name:string)=>name.startsWith('npm:')?{createClient:()=>db}:name==='./upload.ts'?uploads:name==='./payload.ts'?payload:name==='./fit.ts'?fit:oauth,Deno:{env:{get:()=>''},serve:(fn:any)=>{handler=fn;}},fetch:async(url:string,init:any)=>{requests.push({url,body:init.body});const response=responses.shift();if(response instanceof Error)throw response;if(!response)throw new Error('Unexpected request');return response;},crypto,AbortSignal,Response,Request,URL,URLSearchParams,JSON,Date,Error,SyntaxError,Promise,Set});
 return {requests,getPost:()=>post,request:(body:any={action:'share',workout})=>handler!(new Request('https://example.test',{method:'POST',headers:{authorization:'Bearer fixture-only'},body:JSON.stringify(body)}))};
}
const response=(body:any,status=200)=>new Response(JSON.stringify(body),{status});

test('HTTP-success processing rejection falls back once and repeat sharing returns the same activity',async()=>{
 const f=fixture([response({id:123,error:'Unsupported file format'},201),response({error:'FIT unavailable'},400),response({id:42},201)]);
 assert.equal((await f.request()).status,200);
 assert.equal(f.getPost().status,'posted');assert.equal(f.getPost().activity_id,42);
 assert.equal(f.getPost().structured_diagnostic.error,'FIT unavailable');
 assert.equal(f.getPost().structured_diagnostic.httpStatus,400);
 assert.deepEqual(f.requests.map(r=>new URL(r.url).pathname),['/api/v3/uploads','/api/v3/uploads','/api/v3/activities']);
 assert.equal(f.requests[2].body.get('description'),workout.description);
 assert.equal(f.requests[2].body.get('sport_type'),'WeightTraining');
 assert.equal((await f.request()).status,200);assert.equal(f.requests.length,3);
});
test('Asynchronous file failure retains upload ID and next share tries FIT without repeating the rejected JSON',async()=>{
 const f=fixture([response({id:123,error:'Unsupported file format'}),response({activity_id:43,id:124},201)],{status:'sending',upload_id:'123'});
 assert.equal((await f.request({action:'reconcile',sessionId:workout.sessionId})).status,422);
 assert.equal(f.getPost().status,'failed');assert.equal(f.getPost().upload_id,'123');
 assert.equal(f.getPost().structured_diagnostic.error,'Unsupported file format');
 assert.equal((await f.request()).status,200);assert.equal(f.getPost().activity_id,43);
 assert.deepEqual(f.requests.map(r=>new URL(r.url).pathname),['/api/v3/uploads/123','/api/v3/uploads']);
});
test('Pending and successful structured uploads do not create summary activities',async()=>{
 for(const body of [{id:123,error:null},{id:123,activity_id:44}]){
  const f=fixture([response(body,201)]);assert.equal((await f.request()).status,200);assert.equal(f.requests.length,1);
 }
});
test('Duplicate, timeout, malformed and server-error results never trigger a summary or automatic repost',async()=>{
 for(const item of [response({error:'duplicate activity'},201),response({error:'already exists'},400),new Error('timeout'),response({message:'unavailable'},503),response({},201)]){
  const f=fixture([item]);assert.ok((await f.request()).status>=400);assert.equal(f.requests.length,1);
  assert.ok((await f.request()).status>=400);assert.equal(f.requests.length,1);
 }
});
test('Lost summary response blocks retry instead of creating a duplicate',async()=>{
 const f=fixture([response({error:'Unsupported file format'},201),response({error:'FIT rejected'},400),new Error('timeout')]);
 assert.equal((await f.request()).status,502);assert.equal(f.getPost().status,'unknown');
 assert.equal((await f.request()).status,409);assert.equal(f.requests.length,3);
});
test('Unauthenticated caller cannot post or inspect an upload',async()=>{
 const f=fixture([],null,null);assert.equal((await f.request()).status,401);assert.equal(f.requests.length,0);
});

test('Strava scopes accept the documented space-delimited response and legacy commas',()=>{
 assert.equal(oauth.hasScope('activity:read activity:write','activity:write'),true);
 assert.equal(oauth.hasScope('activity:read,activity:write','activity:write'),true);
 assert.equal(oauth.hasScope('activity:read','activity:write'),false);
});

test('JSON rejection preserves heart-rate samples in FIT fallback and never creates a chartless summary',async()=>{
 const w={...workout,streams:{time:[0,5],heartrate:[120,150]}};
 const f=fixture([response({error:'JSON unsupported'},400),response({activity_id:50,id:125},201)]);
 assert.equal((await f.request({action:'share',workout:w})).status,200);
 const json=JSON.parse(await f.requests[0].body.get('file').text());assert.deepEqual(json.streams,w.streams);
 assert.equal(f.requests[1].body.get('data_type'),'fit');assert.equal(f.getPost().activity_id,50);
 const rejected=fixture([response({error:'JSON unsupported'},400),response({error:'FIT rejected'},400)]);
 assert.equal((await rejected.request({action:'share',workout:w})).status,422);
 assert.equal(rejected.requests.length,2);assert.equal(rejected.getPost().status,'failed');
});
test('HR-only cardio uses the file upload and reconciles without duplicate posting',async()=>{
 const w={...workout,sportType:'Run',strength:undefined,streams:{time:[0,5],heartrate:[120,150]}};
 const f=fixture([response({id:123},201),response({id:123,activity_id:51})]);
 assert.equal((await f.request({action:'share',workout:w})).status,200);
 assert.equal(f.requests[0].body.get('data_type'),'fit');assert.equal(f.getPost().status,'sending');
 assert.equal((await f.request({action:'reconcile',sessionId:w.sessionId})).status,200);
 assert.equal((await f.request({action:'share',workout:w})).status,200);assert.equal(f.requests.length,2);
});
