import test from 'node:test';
import assert from 'node:assert/strict';
import {exerciseCode,validateStrength} from '../supabase/functions/strava/strength.ts';
import {uploadForm,uploadResult} from '../supabase/functions/strava/upload.ts';
import {validateShare} from '../supabase/functions/strava/payload.ts';
import {shareDraft,strengthCoverage} from '../src/services/strava.ts';
import {library} from '../src/data/seed.ts';
import type {Session} from '../src/data/types.ts';
const session:Session={id:'99e4be10-641c-489e-812c-16165b7e1e0d',userId:'u',templateId:'t',name:'Test',startedAt:'2026-01-05T08:00:00Z',completedAt:'2026-01-05T08:40:00Z',activities:[{id:'a',activityId:'squat',name:'Back Squat',type:'strength',tags:['quads'],planned:{sets:2,reps:8,weight:60,time:0,distance:0},rows:[{id:'r',reps:8,weight:60,time:0,distance:0,done:true},{id:'skip',reps:10,weight:500,time:0,distance:0,done:false}]}]};
test('Every built-in strength movement has a documented exercise mapping',()=>{
 for(const a of library.filter(a=>a.type==='strength'))assert.ok(exerciseCode(a.name),a.name);
 assert.equal(exerciseCode('Unusual custom movement'),undefined);
 assert.equal(exerciseCode('Custom squat','BARBELL_BACK_SQUAT'),'BARBELL_BACK_SQUAT');
});
test('Completed sets become structured exercise data without skipped work or raw sensor samples',async()=>{
 const draft=validateShare(shareDraft({...session,sensorSamples:[{at:1,exerciseId:'a',source:'strap',heartRate:120,temperatureC:37}]}));
 const form=uploadForm(draft,'u');assert.equal(form.get('data_type'),'json');assert.equal(form.get('sport_type'),'WeightTraining');
 const file=JSON.parse(await (form.get('file') as Blob).text());
 assert.deepEqual(file.sets,[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:8,weight:60}]);assert.equal(file.version,'1.0');assert.equal(file.elapsed_time,2400);assert.equal(Date.parse(file.start_time),Date.parse(session.startedAt));assert.equal(file.streams,undefined);assert.ok(String(form.get('external_id')).includes(session.id));
});
test('Unknown custom movements stay description-only and explicit matches are preserved',()=>{
 const a={...session.activities[0],name:'My custom exercise'};const s={...session,activities:[a]};assert.equal(shareDraft(s).strength,undefined);assert.equal(strengthCoverage(s).unmapped.length,1);assert.match(shareDraft(s).description,/My custom exercise/);
 assert.equal(shareDraft({...s,activities:[{...a,stravaExerciseType:'BARBELL_BACK_SQUAT'}]}).strength?.sets.length,1);
});
test('Structured input is bounded and strips unsupported health data',()=>{
 const good={utcOffset:36000,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:8,weight:20}]};
 for(const value of [{...good,utcOffset:999999},{...good,sets:[]},{...good,sets:[{exercise_type:'BOGUS',repetitions:1}]},{...good,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:1.5}]},{...good,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:1,weight:-1}]}])assert.throws(()=>validateStrength(value));
 assert.deepEqual(validateStrength({...good,temperature:37,streams:{heartrate:[123]}}),good);
 assert.throws(()=>validateShare({...shareDraft(session),sportType:'Run'}));
});
test('Upload responses preserve 64-bit IDs and distinguish processing, completion, rejection and ambiguity',()=>{
 assert.deepEqual(uploadResult({id_str:'9223372036854775807'}),{state:'processing',uploadId:'9223372036854775807'});
 assert.deepEqual(uploadResult({activity_id:42}),{state:'posted',activityId:42});assert.equal(uploadResult({error:'bad data'}).state,'failed');assert.equal(uploadResult({error:'duplicate activity'}).state,'unknown');assert.throws(()=>uploadResult({id:9007199254740992}));assert.throws(()=>uploadResult({id_str:'../../other'}));
});
