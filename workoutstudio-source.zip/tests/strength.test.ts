import test from 'node:test';
import assert from 'node:assert/strict';
import {exerciseCode,validateStrength} from '../supabase/functions/strava/strength.ts';
import {uploadForm,uploadResult,canUseSummaryFallback,rejectionDiagnostic} from '../supabase/functions/strava/upload.ts';
import {validateShare} from '../supabase/functions/strava/payload.ts';
import {shareDraft,strengthCoverage} from '../src/services/strava.ts';
import {library} from '../src/data/seed.ts';
import type {Session} from '../src/data/types.ts';
const session:Session={id:'99e4be10-641c-489e-812c-16165b7e1e0d',userId:'u',templateId:'t',name:'Test',startedAt:'2026-01-05T08:00:00Z',completedAt:'2026-01-05T08:40:00Z',activities:[{id:'a',activityId:'squat',name:'Back Squat',type:'strength',tags:['quads'],planned:{sets:2,reps:8,weight:60,time:0,distance:0},rows:[{id:'r',reps:8,weight:60,time:0,distance:0,done:true},{id:'skip',reps:10,weight:500,time:0,distance:0,done:false}]}]};
test('Provider diagnostics retain bounded rejection fields without payloads or credentials',()=>{
 const d=rejectionDiagnostic(422,{error:'<b>Invalid file</b> Bearer SECRET access_token=TOKEN',message:'x'.repeat(1000),access_token:'OMIT',workout:{name:'OMIT'},errors:[{resource:'Upload',field:'file',code:'invalid',headers:'OMIT'}]});
 assert.match(d.error!,/Invalid file/);assert.equal(d.message!.length,512);
 assert.doesNotMatch(JSON.stringify(d),/SECRET|TOKEN|OMIT|<b>/);
 assert.equal(d.errors![0].field,'file');assert.equal(d.httpStatus,422);
});
test('Every built-in strength movement has a documented exercise mapping',()=>{
 for(const a of library.filter(a=>a.type==='strength'))assert.ok(exerciseCode(a.name),a.name);
 assert.equal(exerciseCode('Unusual custom movement'),undefined);
 assert.equal(exerciseCode('Custom squat','BARBELL_BACK_SQUAT'),'BARBELL_BACK_SQUAT');
});
test('Completed sets become structured exercise data without skipped work or raw sensor samples',async()=>{
 const draft=validateShare(shareDraft({...session,sensorSamples:[{at:1,exerciseId:'a',source:'strap',heartRate:120,temperatureC:37}]}));
 const form=uploadForm(draft,'u');assert.equal(form.get('data_type'),'json');assert.equal(form.get('sport_type'),'WeightTraining');
 const file=JSON.parse(await (form.get('file') as Blob).text());
 assert.deepEqual(file.sets,[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:8,weight:60}]);assert.equal(file.version,'1.0');assert.equal(file.elapsed_time,2400);assert.equal(Date.parse(file.start_time),Date.parse(session.startedAt));assert.equal(file.streams,undefined);assert.ok(String(form.get('external_id')).includes(session.id));
});
test('Unknown custom movements stay description-only and explicit matches are preserved',()=>{
 const a={...session.activities[0],name:'My custom exercise'};const s={...session,activities:[a]};assert.equal(shareDraft(s).strength,undefined);assert.equal(strengthCoverage(s).unmapped.length,1);assert.match(shareDraft(s).description,/My custom exercise/);
 assert.equal(shareDraft({...s,activities:[{...a,stravaExerciseType:'BARBELL_BACK_SQUAT'}]}).strength?.sets.length,1);
});
test('Structured input is bounded and strips unsupported health data',()=>{
 const good={utcOffset:36000,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:8,weight:20}]};
 for(const value of [{...good,utcOffset:999999},{...good,sets:[]},{...good,sets:[{exercise_type:'BOGUS',repetitions:1}]},{...good,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:1.5}]},{...good,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:1,weight:-1}]}])assert.throws(()=>validateStrength(value));
 assert.deepEqual(validateStrength({...good,temperature:37,streams:{heartrate:[123]}}),good);
 assert.throws(()=>validateShare({...shareDraft(session),sportType:'Run'}));
});
test('Upload responses preserve 64-bit IDs and distinguish processing, completion, rejection and ambiguity',()=>{
 assert.deepEqual(uploadResult({id_str:'9223372036854775807'}),{state:'processing',uploadId:'9223372036854775807'});
 assert.deepEqual(uploadResult({activity_id:42}),{state:'posted',activityId:42});assert.equal(uploadResult({error:'bad data'}).state,'failed');assert.equal(uploadResult({error:'duplicate activity'}).state,'unknown');assert.throws(()=>uploadResult({id:9007199254740992}));assert.throws(()=>uploadResult({id_str:'../../other'}));
});

test('Mixed mobility and weights uses WeightTraining and preserves recognized sets',()=>{
 const mobility={...session.activities[0],id:'mobility',name:'Book Opener',type:'stretching' as const,rows:[{...session.activities[0].rows[0],time:70,reps:6,weight:0}]};
 const draft=shareDraft({...session,activities:[mobility,...session.activities]});
 assert.equal(draft.sportType,'WeightTraining');
 assert.equal(draft.strength?.sets[0].exercise_type,'THORACIC_ROTATION');
 assert.equal(draft.strength?.sets[1].exercise_type,'BARBELL_BACK_SQUAT');
 const {strength,...oldClient}=draft;
 const recovered=validateShare({...oldClient,sportType:'Workout'});
 assert.equal(recovered.sportType,'WeightTraining');
 assert.deepEqual(recovered.strength,strength);
 assert.equal(validateShare({...oldClient,description:'An unrelated freeform note'}).strength,undefined);
});

test('Only confirmed file rejection permits a summary fallback; duplicates and ambiguous results never do',()=>{
 for(const status of [400,403,415,422])assert.equal(canUseSummaryFallback(status,{message:'File unsupported'}),true);
 for(const status of [200,201,401,429,500,502,503])assert.equal(canUseSummaryFallback(status,{}),false);
 assert.equal(canUseSummaryFallback(400,{errors:[{code:'duplicate'}]}),false);
 for(const status of [200,201])assert.equal(canUseSummaryFallback(status,{id:123,error:'Unsupported file format'}),true);
 for(const body of [null,{}, {id:123,error:null},{error:'duplicate activity'},{error:'already exists'},{activity_id:42,error:'bad file'}])assert.equal(canUseSummaryFallback(201,body),false);
 assert.equal(canUseSummaryFallback(422,null),false);
});
