import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {strengthFit,fitExercise,fitUploadForm} from '../supabase/functions/strava/fit.ts';
import type {ShareInput} from '../supabase/functions/strava/payload.ts';
const require=createRequire(new URL('../supabase/functions/strava/package.json',import.meta.url));
const {Decoder,Stream}=await import(require.resolve('@garmin/fitsdk'));
const workout:ShareInput={sessionId:'99e4be10-641c-489e-812c-16165b7e1e0d',name:'Strength',description:'Completed work',sportType:'WeightTraining',startedAt:'2026-10-07T19:31:00+11:00',elapsedTime:1822,strength:{utcOffset:39600,sets:[{exercise_type:'BARBELL_BACK_SQUAT',repetitions:8,weight:62.5},{exercise_type:'PLANK_GENERIC',duration:60}]}};
test('Garmin decoder verifies FIT checksum, completed sets, units and workout timestamps',()=>{
 const decoder=new Decoder(Stream.fromByteArray(strengthFit(workout)));
 assert.equal(decoder.checkIntegrity(),true);
 const {messages,errors}=decoder.read();assert.deepEqual(errors,[]);
 assert.equal(messages.fileIdMesgs[0].type,'activity');
 assert.equal(messages.setMesgs.length,2);
 assert.equal(messages.setMesgs[0].repetitions,8);assert.equal(messages.setMesgs[0].weight,62.5);
 assert.equal(messages.setMesgs[1].duration,60);
 assert.equal(messages.setMesgs[0].startTime,undefined);assert.equal(messages.recordMesgs,undefined);
 assert.equal(messages.sessionMesgs[0].totalElapsedTime,1822);
 assert.equal(messages.sessionMesgs[0].startTime.toISOString(),new Date(workout.startedAt).toISOString());
 assert.equal(messages.activityMesgs[0].timestamp.getTime(),Date.parse(workout.startedAt)+1822000);
});
test('Exact exercise mappings do not invent subtypes for unknown movements',()=>{
 assert.equal(fitExercise('BARBELL_BACK_SQUAT').category,28);
 assert.ok('subtype' in fitExercise('BARBELL_BACK_SQUAT'));
 assert.equal(fitExercise('PLANK_GENERIC').category,19);
 assert.deepEqual(fitExercise('MY_CUSTOM_EXERCISE'),{category:65534});
});
test('FIT upload preserves activity description and distinct file identity',async()=>{
 const form=fitUploadForm(workout,'u');assert.equal(form.get('data_type'),'fit');assert.equal(form.get('description'),workout.description);
 assert.match(String(form.get('external_id')),/-fit$/);
 const decoder=new Decoder(Stream.fromByteArray(new Uint8Array(await (form.get('file') as Blob).arrayBuffer())));
 assert.equal(decoder.checkIntegrity(),true);
});

test('FIT carries real timestamped heart-rate records alongside strength sets',()=>{
 const w={...workout,streams:{time:[0,5,60],heartrate:[110,140,125]}};
 const decoder=new Decoder(Stream.fromByteArray(strengthFit(w)));
 assert.equal(decoder.checkIntegrity(),true);
 const {messages,errors}=decoder.read();assert.deepEqual(errors,[]);
 assert.deepEqual(messages.recordMesgs.map((r:any)=>r.heartRate),[110,140,125]);
 assert.deepEqual(messages.recordMesgs.map((r:any)=>r.timestamp.getTime()),w.streams.time.map(t=>Date.parse(w.startedAt)+t*1000));
 assert.equal(messages.setMesgs.length,2);assert.equal(messages.sessionMesgs[0].maxHeartRate,140);
});
test('Cardio without strength mappings still carries heart rate and the correct sport in FIT',()=>{
 const decoder=new Decoder(Stream.fromByteArray(strengthFit({...workout,strength:undefined,sportType:'Run',distance:5000,streams:{time:[0,30],heartrate:[120,150]}})));
 assert.equal(decoder.checkIntegrity(),true);
 const {messages,errors}=decoder.read();assert.deepEqual(errors,[]);
 assert.equal(messages.recordMesgs.length,2);assert.equal(messages.setMesgs,undefined);
 assert.equal(messages.sessionMesgs[0].sport,'running');assert.equal(messages.sessionMesgs[0].totalDistance,5000);
});
