import test from 'node:test';
import assert from 'node:assert/strict';
import {addSessionExercise,saveSessionRoutine} from '../src/services/sessionRoutine.ts';
import {exerciseRecord} from '../src/services/personalBests.ts';
import {startSession} from '../src/services/startSession.ts';
import {seedData,library} from '../src/data/seed.ts';
import {repository} from '../src/services/repository.ts';

const data=seedData('fixture-user');
const original=startSession(data.templates[0],library,[],'fixture-user','2026-01-05T08:00:00Z');
const saved={...original,id:'earlier',startedAt:'2026-01-01T08:00:00Z',completedAt:'2026-01-01T09:00:00Z',activities:original.activities.map(a=>({...a,rows:a.rows.map((r,i)=>({...r,done:i===0,weight:i===0?70:999,reps:8}))}))};

test('Adding an exercise preserves current work, timer, sensor data and original routine',()=>{
 const active={...original,sensorSamples:[{at:Date.parse(original.startedAt),heartRate:120,source:'fixture',exerciseId:null}],trackingExerciseId:original.activities[0].id};
 active.activities[0].rows[0].done=true;
 const before=JSON.stringify(active),templateBefore=JSON.stringify(data.templates);
 const next=addSessionExercise(active,library.find(a=>a.id===saved.activities[0].activityId)!,[saved]);
 assert.equal(next.startedAt,active.startedAt);assert.equal(next.id,active.id);
 assert.deepEqual(next.activities.slice(0,-1),active.activities);assert.deepEqual(next.sensorSamples,active.sensorSamples);
 assert.equal(next.trackingExerciseId,active.trackingExerciseId);assert.equal(next.addedDuringSession,true);
 assert.equal(next.activities.at(-1)!.rows[0].weight,70);assert.ok(next.activities.at(-1)!.rows.every(r=>!r.done&&!r.completedAt));
 assert.equal(JSON.stringify(active),before);assert.equal(JSON.stringify(data.templates),templateBefore);
 assert.throws(()=>addSessionExercise(saved,library[0],[]));
});

test('Old version-1 saved data round-trips and a new routine leaves every existing record intact',()=>{
 const stored=new Map<string,string>();
 Object.defineProperty(globalThis,'localStorage',{configurable:true,value:{getItem:(k:string)=>stored.get(k)||null,setItem:(k:string,v:string)=>stored.set(k,v)}});
 const old=JSON.parse(JSON.stringify({...data,sessions:[saved],activeSession:original}));
 stored.set('workoutstudio:data:fixture-user',JSON.stringify(old));
 stored.set('workoutstudio:strava-preferences:fixture-user','preserve');
 const loaded=repository.load('fixture-user');assert.deepEqual(loaded,old);
 const extended=addSessionExercise(loaded.activeSession!,library[0],loaded.sessions);
 const next=saveSessionRoutine({...loaded,activeSession:extended},extended,library,'My extended routine');
 repository.save('fixture-user',next);
 const reloaded=repository.load('fixture-user');
 assert.deepEqual(reloaded.templates.slice(0,-1),old.templates);assert.deepEqual(reloaded.sessions,old.sessions);
 assert.deepEqual(reloaded.activeSession,JSON.parse(JSON.stringify(extended)));assert.equal(reloaded.version,1);
 assert.equal(reloaded.templates.at(-1)!.activities.length,extended.activities.length);
 assert.equal(stored.get('workoutstudio:strava-preferences:fixture-user'),'preserve');
 const again=startSession(reloaded.templates.at(-1)!,library,reloaded.sessions,'fixture-user','2026-01-06T08:00:00Z');
 assert.equal(again.activities.length,extended.activities.length);
});

test('Saving a routine restores missing custom exercises from snapshots without modifying history',()=>{
 const session={...saved,activities:[{...saved.activities[0],activityId:'deleted-custom',name:'My custom lift'}]};
 const before=JSON.stringify(session);
 const next=saveSessionRoutine({...data,sessions:[session]},session,library,'Recovered routine');
 assert.equal(next.customActivities.at(-1)!.name,'My custom lift');
 assert.notEqual(next.customActivities.at(-1)!.id,'deleted-custom');
 assert.equal(next.templates.at(-1)!.activities[0].activityId,next.customActivities.at(-1)!.id);
 assert.equal(JSON.stringify(session),before);
});

test('Exercise PR uses only earlier completed compatible records owned by the current user',()=>{
 const a=original.activities[0];
 assert.equal(exerciseRecord([saved],original,a)?.weight,70);
 for(const patch of [{userId:'someone-else'},{sample:true},{completedAt:null},{completedAt:'2027-01-01T00:00:00Z'}]) assert.equal(exerciseRecord([{...saved,...patch}],original,a),undefined);
 assert.equal(exerciseRecord([{...saved,activities:saved.activities.map(a=>({...a,metricMode:'time_weight' as const}))}],original,a),undefined);
 assert.equal(exerciseRecord([],original,a),undefined);
});
