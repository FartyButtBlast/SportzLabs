import assert from "node:assert/strict";
import test from "node:test";
import { mergeWorkoutData, readLegacyWorkoutForEmail } from "../src/services/workoutCloudSync";
import type { UserData } from "../src/data/types";

const data = (templates: UserData["templates"], sessions: UserData["sessions"] = []): UserData => ({
  version: 1,
  templates,
  customActivities: [],
  sessions,
  activeSession: null,
});

test("workout sync merge keeps records from both devices and gives the cloud copy precedence by default", () => {
  const cloud = data([{ id: "same", userId: "u", name: "Cloud", description: "", activities: [], createdAt: "2026-01-01" }]);
  const local = data([
    { id: "same", userId: "u", name: "Local stale", description: "", activities: [], createdAt: "2026-01-01" },
    { id: "local-only", userId: "u", name: "Local only", description: "", activities: [], createdAt: "2026-01-02" },
  ]);
  const merged = mergeWorkoutData(cloud, local);
  assert.deepEqual(merged.templates.map((item) => item.id), ["same", "local-only"]);
  assert.equal(merged.templates[0].name, "Cloud");
});

test("workout sync merge uses the newer local copy for matching records", () => {
  const cloud = data([{ id: "same", userId: "u", name: "Earlier", description: "", activities: [], createdAt: "2026-01-01" }]);
  const local = data([{ id: "same", userId: "u", name: "Later", description: "", activities: [], createdAt: "2026-01-01" }]);
  assert.equal(mergeWorkoutData(cloud, local, true).templates[0].name, "Later");
});

test("legacy local workouts are imported only for the matching account email", () => {
  const oldData = data([{ id: "saved-before-cloud", userId: "legacy-id", name: "Saved workout", description: "", activities: [], createdAt: "2026-01-01" }]);
  const rows = new Map<string, string>([
    ["workoutstudio:accounts", JSON.stringify([{ id: "legacy-id", email: "DEREK@example.com" }])],
    ["workoutstudio:data:legacy-id", JSON.stringify(oldData)],
    ["workoutstudio:modified:legacy-id", "1760000000000"],
  ]);
  const storage = { getItem: (key: string) => rows.get(key) ?? null } as Pick<Storage, "getItem">;
  assert.equal(readLegacyWorkoutForEmail("derek@example.com", storage)?.data.sessions.length, 0);
  assert.equal(readLegacyWorkoutForEmail("other@example.com", storage), null);
  assert.deepEqual(readLegacyWorkoutForEmail("derek@example.com", storage)?.data.templates.map((item) => item.id), ["saved-before-cloud"]);
});

import { seedData } from "../src/data/seed";
import { initialWorkoutData } from "../src/services/workoutCloudSync";
import { repairStarterBatches } from "../src/services/starterRepair";

test("five reinstalls read the existing four workouts without importing generated defaults", () => {
  let cloud = seedData("u");
  const originalIds = cloud.templates.map(t => t.id);
  for (let install = 0; install < 5; install++) {
    const fresh = seedData("u");
    cloud = initialWorkoutData(cloud, null, fresh);
    assert.deepEqual(cloud.templates.map(t => t.id), originalIds);
  }
});

test("an intentionally empty cloud account stays empty on reinstall", () => {
  assert.equal(initialWorkoutData(data([]), null, seedData("u")).templates.length, 0);
});

test("a genuinely new account receives its first starter set and saved local work migrates", () => {
  const fresh = seedData("u");
  assert.deepEqual(initialWorkoutData(null, null, fresh), fresh);
  const saved = data([{ ...fresh.templates[0], name: "My custom workout" }]);
  assert.deepEqual(initialWorkoutData(null, saved, fresh), saved);
});

const duplicateBatches = () => {
  const batches = Array.from({ length: 4 }, (_, i) => {
    const d = seedData("u");
    d.templates.forEach(t => t.createdAt = `2026-10-0${i + 1}T00:00:00.000Z`);
    return d;
  });
  return { ...batches[0], templates: batches.flatMap(b => b.templates) };
};

test("repair reduces sixteen generated starters to four and retains all history", () => {
  const source = duplicateBatches();
  const session = { id: "session", userId: "u", templateId: source.templates[14].id,
    name: "Pull day", startedAt: "2026-10-06", completedAt: null, activities: [] };
  source.sessions = [session];
  source.activeSession = { ...session, id: "active" };
  const fixed = repairStarterBatches(source);
  assert.equal(fixed.templates.length, 4);
  assert.equal(source.templates.length, 16);
  assert.equal(fixed.sessions.length, 1);
  assert.equal(fixed.sessions[0].templateId, source.templates[2].id);
  assert.equal(fixed.activeSession?.templateId, source.templates[2].id);
  assert.deepEqual(repairStarterBatches(fixed), fixed);
});

test("repair preserves edited batches and individually copied workouts", () => {
  const source = duplicateBatches();
  source.templates[4].activities[0].targets.weight = 75;
  const individual = { ...source.templates[0], id: "intentional-copy", createdAt: "2026-11-01T00:00:00Z" };
  source.templates.push(individual);
  const fixed = repairStarterBatches(source);
  assert.equal(fixed.templates.length, 9);
  assert.ok(fixed.templates.some(t => t.id === source.templates[4].id));
  assert.ok(fixed.templates.some(t => t.id === individual.id));
});
