import assert from "node:assert/strict";
import test from "node:test";
import { seedData } from "../src/data/seed";
import type { UserData } from "../src/data/types";

const rows = new Map<string, string>();
const storage = { getItem: (key: string) => rows.get(key) ?? null,
  setItem: (key: string, value: string) => { rows.set(key, value); },
  removeItem: (key: string) => { rows.delete(key); } };
Object.defineProperty(globalThis, "localStorage", { value: storage, configurable: true });
Object.defineProperty(globalThis, "window", { value: Object.assign(new EventTarget(), {
  __WORKOUTSTUDIO_CONFIG__: { VITE_SUPABASE_URL: "https://example.supabase.co",
    VITE_SUPABASE_PUBLISHABLE_KEY: "sb_publishable_test", VITE_CLOUDFLARE_API_URL: "https://cloud.example" },
  location: { href: "https://app.example/" },
}), configurable: true });
Object.defineProperty(globalThis, "navigator", { value: { onLine: true }, configurable: true });
const { supabaseClient } = await import("../src/services/auth");
assert.ok(supabaseClient);
supabaseClient.auth.getSession = async () => ({ data: { session: { access_token: "test-token" } }, error: null }) as never;
const { initializeCloudWorkoutSync } = await import("../src/services/workoutCloudSync");
let cloud: { data: UserData | null; revision: number; modifiedAt: number };
let writes = 0;
globalThis.fetch = async (_url, init) => {
  if (init?.method === "PUT") {
    const body = JSON.parse(String(init.body));
    if (body.expectedRevision !== cloud.revision) return Response.json(cloud, { status: 409 });
    cloud = { data: body.data, revision: cloud.revision + 1, modifiedAt: body.modifiedAt };
    writes++;
  }
  return Response.json(cloud);
};

test("real initialization repeatedly reinstalls without creating or uploading duplicate starters", async () => {
  cloud = { data: seedData("u"), revision: 1, modifiedAt: 100 };
  writes = 0;
  const original = structuredClone(cloud.data);
  for (let i = 0; i < 5; i++) {
    rows.clear();
    const result = await initializeCloudWorkoutSync("u", seedData("u"));
    assert.deepEqual(result, original);
    assert.equal(JSON.parse(storage.getItem("workoutstudio:data:u")!).templates.length, 4);
  }
  assert.equal(writes, 0);
});

test("initialization backs up and repairs sixteen starters once", async () => {
  rows.clear(); writes = 0;
  const data = seedData("u");
  for (let i = 0; i < 3; i++) {
    const extra = seedData("u");
    extra.templates.forEach(t => t.createdAt = `2026-11-0${i + 1}T00:00:00Z`);
    data.templates.push(...extra.templates);
  }
  cloud = { data, revision: 3, modifiedAt: 100 };
  assert.equal((await initializeCloudWorkoutSync("u", seedData("u"))).templates.length, 4);
  assert.equal(cloud.data?.templates.length, 4);
  const backup = JSON.parse(storage.getItem("workoutstudio:backup:starter-repair-v1:u")!);
  assert.equal(backup.cloud.templates.length, 16);
  await initializeCloudWorkoutSync("u", seedData("u"));
  assert.equal(writes, 1);
});

test("a clean cached copy does not resurrect cloud deletions on the next sign-in", async () => {
  rows.clear();
  cloud = { data: seedData("u"), revision: 1, modifiedAt: 100 };
  await initializeCloudWorkoutSync("u", seedData("u"));
  cloud = { data: { ...cloud.data!, templates: [] }, revision: 2, modifiedAt: 200 };
  assert.equal((await initializeCloudWorkoutSync("u", seedData("u"))).templates.length, 0);
});

test("concurrent startup effects create only one starter set", async () => {
  rows.clear(); writes = 0;
  cloud = { data: null, revision: 0, modifiedAt: 0 };
  const [a, b] = await Promise.all([
    initializeCloudWorkoutSync("u", seedData("u")),
    initializeCloudWorkoutSync("u", seedData("u")),
  ]);
  assert.deepEqual(a, b);
  assert.equal(writes, 1);
  assert.equal(cloud.data?.templates.length, 4);
});
