import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {resolve} from 'node:path';
// Local visual test only. This configuration is never used by a production build.
export default defineConfig({plugins:[{name:'admin-ui-fixture',enforce:'pre',resolveId(source,importer){if(importer?.endsWith('/src/admin/Admin.tsx')&&['../services/auth','../services/platform'].includes(source))return resolve('tests/admin-ui/fixture.ts');}},react()],server:{host:'127.0.0.1',port:5175,strictPort:true}});
