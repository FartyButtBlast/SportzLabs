import test from 'node:test';
import assert from 'node:assert/strict';
import {performSync,prepareCompletedSession,type SyncDependencies} from '../src/services/stravaSync.ts';
import type {Session} from '../src/data/types.ts';
const session:Session={id:'99e4be10-641c-489e-812c-16165b7e1e0d',userId:'u',templateId:'t',name:'Test',startedAt:'2026-01-05T08:00:00Z',completedAt:'2026-01-05T08:40:00Z',activities:[{id:'a',activityId:'squat',name:'Squat',type:'strength',tags:[],planned:{sets:1,reps:8,weight:60,time:0,distance:0},rows:[{id:'r',reps:8,weight:60,time:0,distance:0,done:true}]}]};
const prefs={autoUpload:true,includeHeartRate:false};
function harness(status:object={configured:true,connected:true},failShare=false){
 let current=prepareCompletedSession(session,true,prefs);const calls:string[]=[];
 const deps:SyncDependencies={load:u=>{assert.equal(u,'u');return {sessions:[current]};},update:(u,id,job)=>{assert.equal(u,'u');assert.equal(id,current.id);current={...current,stravaUpload:job};},preferences:()=>prefs,online:()=>true,request:async(body:any,u:any)=>{assert.equal(u,'u');calls.push(body.action);if(body.action==='status')return status as any;if(failShare)throw new Error('Lost response');return {activityId:42} as any;}};
 return {deps,calls,get:()=>current};
}
test('Only new completed non-sample sessions are queued when connected and enabled',()=>{
 assert.equal(prepareCompletedSession(session,false,prefs).stravaUpload,undefined);
 assert.equal(prepareCompletedSession({...session,sample:true},true,prefs).stravaUpload,undefined);
 assert.equal(prepareCompletedSession(session,true,{...prefs,autoUpload:false}).stravaUpload,undefined);
});
test('Upload checks server first, then shares with the correct account',async()=>{const h=harness();await performSync('u',session.id,h.deps);assert.deepEqual(h.calls,['status','share']);assert.equal(h.get().stravaUpload?.activityId,42);await performSync('u',session.id,h.deps);assert.equal(h.calls.length,2);});
test('Server success and uncertain outcomes never trigger a duplicate POST',async()=>{
 for(const state of ['posted','sending','unknown']){const h=harness({configured:true,connected:true,post:{status:state,activity_id:42}});await performSync('u',session.id,h.deps);assert.deepEqual(h.calls,['status']);assert.equal(h.get().stravaUpload?.state,state==='posted'?'posted':'unknown');}
});
test('Offline queues are retained; lost responses back off and reconcile before any retry',async()=>{
 const h=harness(undefined,true);h.deps.online=()=>false;await performSync('u',session.id,h.deps);assert.deepEqual(h.calls,[]);assert.equal(h.get().stravaUpload?.state,'pending');h.deps.online=()=>true;await performSync('u',session.id,h.deps);assert.equal(h.get().stravaUpload?.attempts,1);assert.ok(h.get().stravaUpload!.nextAt!>Date.now());await performSync('u',session.id,h.deps);assert.deepEqual(h.calls,['status','share']);
});
test('Disabling sharing cancels an outstanding queued upload',async()=>{const h=harness();h.deps.preferences=()=>({...prefs,autoUpload:false});await performSync('u',session.id,h.deps);assert.equal(h.get().stravaUpload?.state,'skipped');assert.deepEqual(h.calls,['status']);});

test('An accepted structured upload is reconciled, never submitted again, even with auto sharing disabled',async()=>{
 const h=harness({configured:true,connected:true,post:{status:'sending',upload_id:'9223372036854775807'}});h.deps.preferences=()=>({...prefs,autoUpload:false});
 await performSync('u',session.id,h.deps);assert.deepEqual(h.calls,['status','reconcile']);assert.equal(h.get().stravaUpload?.state,'posted');
});
test('Processing replies retain a polling job without consuming retry attempts',async()=>{
 const h=harness();h.deps.request=async(body:any)=>{h.calls.push(body.action);return (body.action==='status'?{configured:true,connected:true}:{processing:true}) as any;};
 await performSync('u',session.id,h.deps);assert.equal(h.get().stravaUpload?.state,'pending');assert.equal(h.get().stravaUpload?.attempts,0);assert.ok(h.get().stravaUpload!.nextAt!>Date.now());
});
