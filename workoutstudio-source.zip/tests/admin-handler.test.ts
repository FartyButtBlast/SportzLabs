import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as policy from '../supabase/functions/platform-admin/policy.ts';
const source=ts.transpileModule(readFileSync('supabase/functions/platform-admin/index.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
function fixture(user:any,rows:Record<string,any>={}){
 let handler:(req:Request)=>Promise<Response>;const writes:any[]=[];const reads:string[]=[];
 const db={auth:{getUser:async()=>({data:{user},error:user?null:new Error('invalid')}),admin:{listUsers:async()=>({data:{users:[],total:0},error:null})}},from(name:string){reads.push(name);const q:any={select(){return q;},eq(){return q;},in(column:string,values:any[]){q.filter={column,values};return q;},order(){return q;},limit(){return q;},maybeSingle(){return Promise.resolve({data:rows[name]??null,error:null});},upsert(value:any){writes.push({name,value});return Promise.resolve({error:null,data:null});},insert(value:any){writes.push({name,value});return Promise.resolve({error:null,data:null});},then(resolve:any){const data=rows[name]??[];const filtered=q.filter&&Array.isArray(data)?data.filter((value:any)=>q.filter.values.includes(value[q.filter.column])):data;return Promise.resolve({data:filtered,error:null}).then(resolve);}};return q;},rpc:async()=>({data:{},error:null})};
 const sandbox={exports:{},require:(name:string)=>name.startsWith('npm:')?{createClient:()=>db}:policy,Deno:{env:{get:()=>''},serve:(fn:any)=>{handler=fn;}},Response,Request,Set,JSON,Date,Error,SyntaxError,Promise,URL};vm.runInNewContext(source,sandbox);
 return {writes,reads,request:(body:any,token='valid')=>handler!(new Request('https://example.test',{method:'POST',headers:token?{authorization:'Bearer '+token}:{},body:JSON.stringify(body)}))};
}
const owner={id:'owner',email:'derek@sportzlabs.com',email_confirmed_at:'2026-10-07'};
test('admin API rejects missing, invalid and unverified identities before accessing tables',async()=>{
 for(const [user,token] of [[owner,''],[null,'invalid'],[{...owner,email_confirmed_at:null},'valid']] as any){const f=fixture(user);assert.equal((await f.request({action:'users'},token)).status,401);assert.equal(f.reads.length,0);}
});
test('ordinary verified users cannot access user lists, credentials or mutations',async()=>{
 for(const action of ['users','overview','integrations','saveIntegration','saveExercise','saveApp']){const f=fixture({...owner,email:'athlete@example.test',user_metadata:{role:'admin'}});assert.equal((await f.request({action})).status,403);assert.equal(f.writes.length,0);assert.deepEqual(f.reads,['sportzlabs_admins']);}
});
test('owner integration list never returns stored secrets',async()=>{
 const f=fixture(owner,{sportzlabs_integrations:[{id:'strava',name:'Strava',client_id:'123',client_secret:'DO-NOT-DISCLOSE',enabled:true}]});const response=await f.request({action:'integrations'});assert.equal(response.status,200);const body=await response.text();assert.ok(!body.includes('DO-NOT-DISCLOSE'));assert.equal(JSON.parse(body).integrations[0].configured,true);
});
test('blank secret preserves saved secret and credential changes are audited without it',async()=>{
 const f=fixture(owner,{sportzlabs_integrations:{client_secret:'KEEP-THIS'}});const response=await f.request({action:'saveIntegration',integration:{id:'strava',name:'Strava',client_id:'123',client_secret:'',enabled:false,notes:''}});assert.equal(response.status,200);assert.equal(f.writes[0].value.client_secret,'KEEP-THIS');assert.equal(f.writes[0].value.enabled,false);assert.equal(f.writes[1].name,'sportzlabs_audit');assert.ok(!JSON.stringify(f.writes[1]).includes('KEEP-THIS'));
});
test('delegated administrators cannot update provider credentials',async()=>{
 const f=fixture({...owner,email:'delegate@example.test'},{sportzlabs_admins:{user_id:'owner'}});assert.equal((await f.request({action:'saveIntegration'})).status,403);assert.equal(f.writes.length,0);
});

test('access catalogue, tier, and add-on controls are admin-only',async()=>{
 for(const action of ['accessCatalog','saveCapability','saveTier','saveAddon','setUserAccess']){const f=fixture({...owner,email:'athlete@example.test'});assert.equal((await f.request({action})).status,403);assert.equal(f.writes.length,0);}
});
test('owner can read the capability, tier, and add-on catalogue',async()=>{
 const f=fixture(owner,{sportzlabs_capabilities:[{key:'workouts.plan',name:'Plan workouts',active:true}],sportzlabs_tiers:[{id:'free',name:'Free',is_default:true,active:true,capability_keys:['workouts.plan']}],sportzlabs_addons:[]});
 const response=await f.request({action:'accessCatalog'});assert.equal(response.status,200);const result=await response.json();assert.equal(result.tiers[0].id,'free');assert.equal(result.capabilities[0].key,'workouts.plan');
});
test('tier and add-on saves validate capabilities and write audit events',async()=>{
 const rows={sportzlabs_capabilities:[{key:'workouts.plan'},{key:'workouts.track'}]};
 const tier=await fixture(owner,rows).request({action:'saveTier',tier:{id:'plus',name:' Plus ',description:'More workouts',active:true,sort_order:10,capability_keys:['workouts.plan','workouts.track']}});assert.equal(tier.status,200,await tier.clone().text());
 const addon=await fixture(owner,rows).request({action:'saveAddon',addon:{id:'reports',name:'Reports',description:'Extra reports',active:true,capability_keys:['workouts.track']}});assert.equal(addon.status,200,await addon.clone().text());
 const bad=await fixture(owner,rows).request({action:'saveTier',tier:{id:'plus',name:'Plus',description:'',active:true,sort_order:10,capability_keys:['missing']}});assert.equal(bad.status,400);
});
test('manual user access grants only active tiers and add-ons',async()=>{
 const f=fixture(owner,{sportzlabs_tiers:{id:'plus',active:true},sportzlabs_addons:[{id:'reports',active:true}]});
 const response=await f.request({action:'setUserAccess',access:{user_id:'123e4567-e89b-42d3-a456-426614174000',tier_id:'plus',addon_ids:['reports','reports']}});assert.equal(response.status,200);assert.equal(Array.from(f.writes[0].value.addon_ids).join(','),'reports');
 const invalid=await fixture(owner,{sportzlabs_tiers:{id:'free',active:false}}).request({action:'setUserAccess',access:{user_id:'123e4567-e89b-42d3-a456-426614174000',tier_id:'free',addon_ids:[]}});assert.equal(invalid.status,400);
});
