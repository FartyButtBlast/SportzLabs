# WorkoutStudio

## Pro capability decision — 9 October 2026

Pro includes all Free capabilities plus `workouts.progression` (Progression suggestions) and `workouts.insights.advanced` (Advanced progress insights). `scripts/configure-pro-capabilities.sql` configures this catalogue without assigning users, creating payments, or implementing the features.

Each feature must be completely absent from the workout application unless the authenticated user's current subscription includes its capability: no navigation entry, card, locked preview, disabled control, or upgrade prompt. Unknown/loading/failed access checks must not reveal it. Backend feature operations must independently verify current access; a hidden button or locally stored flag is not authorization. Removing access must clear any displayed feature results. Basic history and existing summaries remain Free.

Both features are implemented. Pro users see advanced insights on Home and progression suggestions inside a workout template. The `workout-pro` Edge Function verifies the authenticated user and resolves active tier/add-on capabilities from server-owned tables on every request. Local flags and administrator status cannot grant access. The UI checks access at startup, on focus/reconnection and every 30 seconds, and removes both panels on offline/hidden state or failed verification. Feature requests independently check current access. No Pro UI is shown while access is unknown.

The access console still supports manual tier/add-on assignments only. Payment webhooks and automatic subscription expiry are not implemented: a manually assigned Pro tier remains valid until an administrator changes it or disables its capabilities. No prices, charges, or user assignments were changed by this feature release.

Progression is opt-in for conventional externally loaded repetition exercises. It compares two matching sessions, requires all configured working sets at the current weight to reach the selected rep ceiling, and offers an equipment increment up to 10%. Breaks over 28 days require review. Warm-ups must be logged separately. These are product rules informed by the sources shown in the UI, not an exercise-specific coaching prescription. Accepting updates the template and prefills the next session once; Undo is available until that session starts. Completed and active sessions are not changed.

Insights compare rolling 28- or 84-day periods with the preceding equal period, show weekly consistency, per-exercise set/rep/load/volume history and estimated 1RM, and count tagged muscle-group sets. Both features use at most the latest 1,000 completed non-demo sessions and require connectivity; only necessary log fields are sent for calculation, not sensor samples. Requests are limited to 2 MiB. Estimated 1RM is approximate, and muscle tags overlap; neither is a recovery or medical assessment.

Verification: `pnpm test`, `pnpm build`. Browser fixture: serve Vite locally and run `tests/browser/pro-features.mjs` with Playwright available (`PLAYWRIGHT_MODULE` can point to its module and `CHROME_PATH` to Chrome). It uses synthetic data and a local instance of the real server handler, not live accounts. Test fixtures are not production build inputs.

A mobile-first React + TypeScript + Vite workout tracker. Supabase handles sign-in; workout data is cached locally and can sync through a Cloudflare Worker to Cloudflare D1 when the Worker and `VITE_CLOUDFLARE_API_URL` are configured. Until that deployment setting is present, workout data stays on the current browser or installed app. The Cloudflare service, D1 database and public app deployment still need to be connected to their accounts.

## Run locally

Use Node.js 22+ and pnpm 11.19.0.

```sh
pnpm install
pnpm dev
```

Open the printed local URL. Choose **Try the demo** for three labeled example sessions, or create a local account to start with empty history. Four editable starter templates and 81 built-in activities are included. With no Supabase environment configuration, registration, verification, sign-in, and reset are simulated in this browser. No verification/reset email is sent in local mode. Use disposable demo credentials. With Supabase configured, demo sign-in and simulated verification/reset are disabled, and these operations use Supabase Auth.

```sh
pnpm test        # Metrics, auth lifecycle, and storage separation tests
pnpm build       # TypeScript check and production output in dist/
pnpm preview     # Serve the production build
pnpm seed:export # Regenerate Supabase library seed from the shared catalog
```

## Using the app

- **Home:** newest sessions first; open one for set-level details, planned versus actual values, trends, and a front/back muscle map.
- **Workouts:** header **+** creates a template. Tap a template to edit it; the same **+** adds an activity. Pencil edits the name/goal. Targets save automatically.
- **Session:** choose a workout; edit actual reps, kilograms, seconds, or kilometres directly. Mark each set complete on the left. Previous completed values appear beside it. The timer continues across refreshes and tab switches; Home offers Resume. Only one session can be active per account.
- **Library:** search by name/body tag, filter by type or Custom, and use **+** to create an activity. Built-ins are read-only. Custom activities have a pencil. Creating one from a workout saves it in both places.
- Swipe a row left to reveal Delete, or use its three-dot button with keyboard/mouse. A confirmation precedes deletion. Saved logs retain names, tags, targets, and actual values when templates or library items change.
- Profile avatar opens account information and sign-out.

Units are kg, km, and seconds (cardio and stretch inputs); the timer displays hours:minutes:seconds. Targets and additional set counts are capped at 30. There is no billing or real email service in the prototype. Cloud workout sync is inactive until the Cloudflare Worker is deployed and configured.

## Architecture

- `src/data/types.ts`: shared entities and allowed muscle tags.
- `src/data/seed.ts`: original broad gym catalog and starter templates; not a TrainingPeaks data import.
- `src/data/metrics.ts`: pure calculations, previous-session lookup, and intensity.
- `src/services/repository.ts`: the local workout cache boundary; namespaced by account ID, schema version 1.
- `src/services/workoutCloudSync.ts`: optional Cloudflare sync, first-login merge, offline queue and revision conflict handling.
- `cloudflare/workout-api/`: D1 schema and Worker API. Setup instructions are in its README.
- `src/services/auth.ts`: chooses Supabase or local authentication. `supabaseAuth.ts` implements real auth; `localAuth.ts` contains the isolated demo. Local passwords are salted and derived using Web Crypto PBKDF2. Local verification/reset are **not an authentication security boundary**.
- `src/components/`: reusable dialogs, swipe rows, forms, body map, and session logger.
- `src/services/webmcp.ts`: optional, feature-detected read-only `list_workout_templates` browser tool. It unregisters when user state changes/unmounts.
- `supabase/migrations/001_workoutstudio.sql`: normalized production schema blueprint, ownership rules, parent-child ownership constraints, grants, and RLS.
- `supabase/seed.sql`: generated built-in catalog, inserted only by an administrative migration role.

The app keeps a local cache for offline use. Until Cloudflare sync is configured, that cache is the only copy of workouts. Browser or device storage is not encrypted by the app; someone with access to the unlocked device/browser may inspect it. With Cloudflare sync enabled, workout plans, session history and recorded sensor samples are also stored in the user's Cloudflare D1 record. Clearing local storage does not delete the cloud copy. Keep the local cache and cloud copy in mind when deleting or moving data.

## Intensity and comparison rules

Only checked rows contribute. Strength volume is reps × kg; bodyweight/zero-load rows use reps × max(kg, 1) for the intensity estimate. Cardio work is seconds + kilometres × 60. Stretching work is seconds × count. Each activity credits its tags; map colors are relative to the most-worked tag in that session. The map is a simplified front/back diagram, not a physiological fatigue measure. Combined modality colors are heuristic, not a clinical or calibrated workload scale.

Trends compare the same activity ID against its latest earlier completed session that contains checked work. Strength compares volume; cardio and stretching compare the above work score. Unchecked rows are retained as Skipped in history but excluded from all summaries. The stored activity snapshots protect historical values against library edits/deletion. Example history appears only in the explicit demo workspace.

## Connect Supabase login

This checkout is configured in ignored `.env.local` for the existing **WorkOutStudio** project (`npllwuavofpfudchotma`, Singapore region). The project is restored and reports ACTIVE_HEALTHY. Email/password authentication and email confirmation are enabled. The exact local redirect URLs listed below are saved alongside the existing custom-domain URL. The public auth settings endpoint returns HTTP 200, and a deliberately nonexistent login receives the expected invalid_credentials response. Successful sign-in with the user’s credentials and end-to-end email delivery still require user verification.

1. Copy `.env.example` to `.env.local`.
2. Fill `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` from the chosen Supabase project’s settings. Use a publishable key (`sb_publishable_...`) or the legacy **anon** key. Never use a secret or service-role key. These Vite values are public and bundled into the frontend.
3. In Supabase Authentication settings, enable the Email provider, signups, and email confirmation. Keep confirmation enabled. Add these exact Redirect URLs for local development:
   - `http://127.0.0.1:5173/`
   - `http://127.0.0.1:5173/?auth=recovery`
   - If using `localhost` instead, add that hostname’s equivalent URLs too.
4. Restart `pnpm dev`. The login footer should say **Secure sign-in with Supabase** and the demo button should be absent. One missing environment value shows a configuration error rather than reverting to local login.
5. Create your real account from WorkoutStudio. Open the emailed verification link, then sign in. Existing local demo accounts do not become Supabase accounts automatically, and their workout data remains under its old local ID; it is not silently reassigned.
6. Test **Forgot password?**, open the recovery email, choose your new password yourself, then verify sign-out/sign-in and page refresh. The app uses Supabase’s client-only implicit callback handling so links can open in another browser. Recovery passwords are updated only with a valid authenticated session.

Set the Supabase **Site URL** to the final deployed app URL when publishing, and add its root and `?auth=recovery` redirect URLs, including any GitHub repository subpath. During local-only development it can be the local URL above. For GitHub Actions, add repository **Variables** named `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`; the workflow supplies them during the build. A public key is sufficient for login; do not run the workout database migration just to enable authentication.

The app uses real confirmation/resend and password-recovery email requests, token refresh, startup session restoration, and auth-change subscriptions. Configure SMTP in Supabase for delivery beyond its restricted built-in test email service. See [Supabase password authentication](https://supabase.com/docs/guides/auth/passwords) and [custom SMTP](https://supabase.com/docs/guides/auth/auth-smtp).

Adapter tests use controlled mock API responses. Real account creation, email delivery, callbacks, and project settings must be verified against the connected project before considering login setup complete.

## Supabase database blueprint

`supabase/migrations/001_workoutstudio.sql` remains an optional, unapplied schema blueprint. The current cloud-workout design stores workout documents in Cloudflare D1; Supabase is used for sign-in and token verification. Do not apply the Supabase workout migration as part of the Cloudflare setup. See [Cloudflare Worker setup](cloudflare/workout-api/README.md).

## GitHub Pages / static deployment

The repository includes `.github/workflows/deploy.yml`. Push to a GitHub repository with a `main` branch, then choose **Settings → Pages → Build and deployment → GitHub Actions**. The workflow installs the locked dependencies, runs tests/build, uploads `dist`, and deploys it. The relative Vite base works under a repository subpath. The app uses in-memory tab navigation, so it does not need server rewrite rules.

Other static hosts can run `pnpm build` and serve `dist/`. HTTPS is required for authentication crypto APIs outside localhost. To enable cloud sync in a published build, provide the public Supabase URL and publishable key, and `VITE_CLOUDFLARE_API_URL` as build settings. Never put a service-role key in a client build.

For the future domain `WorkoutStudio.Sportzlabs.com`, configure `workoutstudio.sportzlabs.com` in the chosen host and the DNS provider after the domain is ready. For GitHub Pages, set the custom domain in repository Pages settings and follow its DNS/HTTPS checks. No DNS, CNAME, remote repository, or public deployment has been changed by this build.

See [GitHub's custom Pages workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

## SportzLabs deployment and Strava

The live homepage is `https://www.sportzlabs.com/`; the application is served at `/workoutstudio/`. GoDaddy manages the domain, while the `FartyButtBlast/SportzLabs` GitHub Pages repository hosts the files. Production builds use the `/workoutstudio/` asset base; local Vite development uses `/`.

The homepage source lives in `site/`. Build with `pnpm build`, then run `node scripts/build-site.mjs /path/to/SportzLabs`. Review and publish the resulting static files in the site's existing branch. The remote `workoutstudio-source.zip` archive contains a copy of this app's source for reproducibility. `.env.local` and server secrets must never be committed. The public Supabase URL/key and Cloudflare Worker URL are supplied at build time.

The optional Strava integration uses a deployed Supabase Edge Function and server-only tables. See [activation and operational notes](docs/STRAVA.md). Account settings contains the connection control; completed session details contains review and post controls. The integration remains unavailable until the owner supplies Strava API credentials.

Workout data is stored per account in local browser/app storage, and also syncs to Cloudflare only when the Worker is deployed and `VITE_CLOUDFLARE_API_URL` is set for that build. The hosted domain has a separate local store from localhost; first sync merges saved local records into the cloud account.

## Bluetooth sensors and native mobile apps

See [SENSORS-AND-MOBILE.md](docs/SENSORS-AND-MOBILE.md) for iPhone/Android setup, Garmin/Wahoo compatibility limits, exercise tracking and physical-device acceptance tests. `pnpm native:sync` prepares both native projects. They still require platform builds, signing and real-device validation. Newly completed workouts queue for automatic Strava upload when connected; Account controls automatic sharing and optional heart-rate summaries.

## Platform administration

SportzLabs administration is available at `https://www.sportzlabs.com/admin/`. It shares Supabase authentication, supports verified owner email sign-in, lists platform users, manages the exercise catalogue and integration settings, registers applications, and reports authenticated Workout Studio usage. See [Administration setup and operations](docs/ADMIN.md). Build with `pnpm build:admin` in addition to `pnpm build` before running the combined site-copy script.


## Session feedback update — 19 October 2026

Active sessions support adding library or custom exercises. The current session keeps its timer, checked rows and sensor readings. After adding an exercise, **Save as new routine** is available during the workout and on its completed history screen; it creates a separate template using the current order, set counts, and first completed (or first available) set as each exercise target. The original routine and history stay intact.

Each exercise shows its historical PR: heaviest set (reps/time break ties), furthest cardio round (time breaks ties), or longest timed set (reps break ties). Unchecked, sample, other-account, future and incompatible measurement records are excluded. Last-set values remain visible. All session columns share centred tracks; minute/second inputs use header labels rather than extra captions underneath.

Compatibility is additive: UserData stays version 1 and existing storage keys/IDs are preserved. `Session.addedDuringSession` is optional. Regression checks cover older saved data, library/custom additions, routine reuse, refresh, completion, Strava streams and FIT decoding. Run `node --import tsx --test tests/*.test.ts`, TypeScript/Vite builds, and `tests/browser/session-feedback.mjs` against local Vite. The browser test blocks external traffic and uses only an isolated synthetic account.
