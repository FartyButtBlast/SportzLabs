# Preserve user data across updates

The owner requires all future updates to preserve existing user data.

- Treat accounts, tier assignments, workouts, history, custom exercises, templates, and settings as persistent user-owned records.
- Do not reset, reseed, clear browser/app storage, delete records, or recreate production databases as part of a build or deployment.
- Preserve production authentication and sync configuration, storage keys, app identifiers, and the hosted origin when releasing updates.
- Use additive, backward-compatible migrations. Before any necessary data transformation, retain a recoverable backup and verify existing records survive.
- Verify update compatibility with existing saved data, not only a freshly seeded account. Keep synthetic test records out of real accounts.
- Report separately which backend, website, and mobile releases were actually deployed; a local build is not a public release.
