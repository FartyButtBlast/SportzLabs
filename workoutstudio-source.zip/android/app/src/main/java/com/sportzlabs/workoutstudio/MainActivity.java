package com.sportzlabs.workoutstudio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
