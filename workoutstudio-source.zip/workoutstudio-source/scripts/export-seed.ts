import { writeFileSync } from "node:fs";
import { library } from "../src/data/seed";
const quote = (v: string) => `'${v.replaceAll("'", "''")}'`;
const rows = library.map(
  (a) =>
    `(${quote(a.id)},null,${quote(a.name)},${quote(a.type)},ARRAY[${a.tags.map(quote).join(",")}]::public.body_tag[],${a.defaults.sets},${a.defaults.reps},${a.defaults.weight},${a.defaults.time},${a.defaults.distance})`,
);
writeFileSync(
  "supabase/seed.sql",
  `-- Generated from src/data/seed.ts. Run as a migration/admin role.\ninsert into public.activities(id,user_id,name,type,tags,default_sets,default_reps,default_weight,default_time,default_distance) values\n${rows.join(",\n")}\non conflict(id) do nothing;\n`,
);
console.log(`Exported ${library.length} built-in activities`);
