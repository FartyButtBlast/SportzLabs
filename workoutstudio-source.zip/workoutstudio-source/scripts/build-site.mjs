import { cp, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
// Run after pnpm build. Usage: node scripts/build-site.mjs /path/to/SportzLabs
const target=process.argv[2];
if(!target) throw new Error('Provide the SportzLabs checkout directory.');
await mkdir(resolve(target,'workoutstudio'),{recursive:true});
await cp('dist',resolve(target,'workoutstudio'),{recursive:true});
await cp('site/index.html',resolve(target,'index.html'));
await cp('site/sportzlabs.css',resolve(target,'sportzlabs.css'));
console.log('Copied homepage and app build to '+resolve(target));
