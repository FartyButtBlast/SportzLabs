import { test } from "node:test";
import assert from "node:assert/strict";
import type { SupabaseClient } from "@supabase/supabase-js";
import { readAuthConfig } from "../src/services/authConfig";
import { createSupabaseAuth } from "../src/services/supabaseAuth";

test("Supabase configuration permits only public client keys and never falls back when incomplete", () => {
  assert.deepEqual(readAuthConfig({}), { mode: "local" });
  assert.throws(
    () => readAuthConfig({ VITE_SUPABASE_URL: "https://project.supabase.co" }),
    /incomplete/,
  );
  assert.throws(
    () =>
      readAuthConfig({
        VITE_SUPABASE_URL: "https://project.supabase.co",
        VITE_SUPABASE_PUBLISHABLE_KEY: "sb_secret_fake",
      }),
    /Secret and service-role/,
  );
  const jwt = (role: string) =>
    `header.${btoa(JSON.stringify({ role }))}.signature`;
  assert.throws(
    () =>
      readAuthConfig({
        VITE_SUPABASE_URL: "https://project.supabase.co",
        VITE_SUPABASE_PUBLISHABLE_KEY: jwt("service_role"),
      }),
    /Secret and service-role/,
  );
  assert.equal(
    readAuthConfig({
      VITE_SUPABASE_URL: "https://project.supabase.co",
      VITE_SUPABASE_PUBLISHABLE_KEY: jwt("anon"),
    }).mode,
    "supabase",
  );
  assert.equal(
    readAuthConfig({
      VITE_SUPABASE_URL: "https://project.supabase.co",
      VITE_SUPABASE_PUBLISHABLE_KEY: "sb_publishable_fake",
    }).mode,
    "supabase",
  );
  assert.throws(
    () =>
      readAuthConfig({
        VITE_SUPABASE_URL: "http://untrusted.example",
        VITE_SUPABASE_PUBLISHABLE_KEY: "sb_publishable_fake",
      }),
    /HTTPS/,
  );
});
function fixture() {
  const calls: Array<{ method: string; input: unknown }> = [];
  const user = {
    id: "supabase-user",
    email: "user@example.invalid",
    email_confirmed_at: "2026-10-05T00:00:00Z",
    user_metadata: { display_name: "Test athlete" },
  };
  let session: unknown = { user };
  let listener: ((event: string, session: unknown) => void) | undefined;
  let unsubscribed = false;
  let failure: Error | null = null;
  const client = {
    auth: {
      getSession: async () => ({ data: { session }, error: failure }),
      signUp: async (input: unknown) => {
        calls.push({ method: "signUp", input });
        return {
          data: { user: { ...user, email_confirmed_at: null }, session: null },
          error: failure,
        };
      },
      signInWithPassword: async (input: unknown) => {
        calls.push({ method: "login", input });
        return { data: { user, session }, error: failure };
      },
      resend: async (input: unknown) => {
        calls.push({ method: "resend", input });
        return { error: failure };
      },
      resetPasswordForEmail: async (email: string, options: unknown) => {
        calls.push({ method: "reset", input: { email, options } });
        return { error: failure };
      },
      updateUser: async (input: unknown) => {
        calls.push({ method: "update", input });
        return { error: failure };
      },
      signOut: async (input: unknown) => {
        calls.push({ method: "logout", input });
        return { error: failure };
      },
      onAuthStateChange: (fn: typeof listener) => {
        listener = fn;
        return {
          data: {
            subscription: {
              unsubscribe() {
                unsubscribed = true;
              },
            },
          },
        };
      },
    },
  };
  const service = createSupabaseAuth(
    client as unknown as Pick<SupabaseClient, "auth">,
    () => "https://example.com/workoutstudio/?old=1#home",
  );
  return {
    service,
    calls,
    user,
    setSession(value: unknown) {
      session = value;
    },
    fail(error: Error) {
      failure = error;
    },
    emit(event: string) {
      listener?.(event, session);
    },
    unsubscribed: () => unsubscribed,
  };
}
test("signup uses real confirmation, normalized email, metadata and the correct subpath redirect", async () => {
  const f = fixture();
  const profile = await f.service.register(
    " Test athlete ",
    " USER@example.invalid ",
    "example-only-password",
  );
  assert.equal(profile.verified, false);
  assert.deepEqual(f.calls[0], {
    method: "signUp",
    input: {
      email: "user@example.invalid",
      password: "example-only-password",
      options: {
        data: { display_name: "Test athlete" },
        emailRedirectTo: "https://example.com/workoutstudio/",
      },
    },
  });
  await assert.rejects(f.service.verify("id"), /verification link/);
  await assert.rejects(f.service.demo(), /unavailable/);
});
test("login and restored sessions map Supabase identity; token/recovery changes are subscribed with cleanup", async () => {
  const f = fixture();
  assert.equal((await f.service.current())?.id, "supabase-user");
  assert.equal(
    (await f.service.login(" USER@example.invalid ", "example-only-password"))
      .name,
    "Test athlete",
  );
  const events: string[] = [];
  const stop = f.service.subscribe((event, p) => {
    events.push(event);
    assert.equal(p?.id, "supabase-user");
  });
  f.emit("PASSWORD_RECOVERY");
  f.emit("TOKEN_REFRESHED");
  stop();
  assert.deepEqual(events, ["PASSWORD_RECOVERY", "TOKEN_REFRESHED"]);
  assert.equal(f.unsubscribed(), true);
});
test("reset sends an email without passing a new password; update requires a recovered session", async () => {
  const f = fixture();
  await f.service.reset(" USER@example.invalid ");
  assert.deepEqual(f.calls[0], {
    method: "reset",
    input: {
      email: "user@example.invalid",
      options: {
        redirectTo: "https://example.com/workoutstudio/?auth=recovery",
      },
    },
  });
  await f.service.updatePassword("new-example-password");
  assert.deepEqual(f.calls[1], {
    method: "update",
    input: { password: "new-example-password" },
  });
  f.setSession(null);
  await assert.rejects(
    f.service.updatePassword("new-example-password"),
    /expired/,
  );
  assert.equal(f.calls.length, 2);
});
test("resend and signout use Supabase and API errors propagate", async () => {
  const f = fixture();
  await f.service.resendVerification(" USER@example.invalid ");
  assert.deepEqual(f.calls[0], {
    method: "resend",
    input: {
      type: "signup",
      email: "user@example.invalid",
      options: { emailRedirectTo: "https://example.com/workoutstudio/" },
    },
  });
  await f.service.logout();
  assert.deepEqual(f.calls[1], { method: "logout", input: { scope: "local" } });
  f.fail(new Error("Network unavailable"));
  await assert.rejects(
    f.service.login("user@example.invalid", "example-only-password"),
    /Network unavailable/,
  );
  await assert.rejects(f.service.logout(), /Network unavailable/);
});
