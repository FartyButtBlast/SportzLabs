import { test } from "node:test";
import assert from "node:assert/strict";
import {
  completedRows,
  intensity,
  volume,
  score,
  previousLog,
  trend,
} from "../src/data/metrics";
import { seedData, library } from "../src/data/seed";
import { Session, ActivityLog } from "../src/data/types";
const a: ActivityLog = {
  id: "a",
  activityId: "bench-press",
  name: "Bench Press",
  type: "strength",
  tags: ["chest", "triceps"],
  planned: { sets: 2, reps: 10, weight: 20, time: 0, distance: 0 },
  rows: [
    { id: "1", done: true, reps: 10, weight: 20, time: 0, distance: 0 },
    { id: "2", done: false, reps: 100, weight: 100, time: 0, distance: 0 },
  ],
};
const s: Session = {
  id: "s",
  userId: "u",
  templateId: "t",
  name: "Test",
  startedAt: "2026-10-01T10:00:00Z",
  completedAt: "2026-10-01T11:00:00Z",
  activities: [a],
};
test("unchecked rows never contribute to volume or body-map intensity", () => {
  assert.equal(volume(s), 200);
  assert.equal(completedRows(s).length, 1);
  assert.deepEqual(intensity(s), { chest: 200, triceps: 200 });
  assert.deepEqual(
    intensity({
      ...s,
      activities: [{ ...a, rows: a.rows.map((r) => ({ ...r, done: false })) }],
    }),
    {},
  );
});
test("previous comparison finds the latest earlier completed exercise, ignoring later and skipped sessions", () => {
  const older = { ...s, id: "older", completedAt: "2026-09-30T11:00:00Z" };
  const skipped = {
    ...s,
    id: "skipped",
    completedAt: "2026-10-02T11:00:00Z",
    activities: [{ ...a, rows: a.rows.map((r) => ({ ...r, done: false })) }],
  };
  assert.equal(
    previousLog([older, s, skipped], a.activityId, "2026-10-03T10:00:00Z"),
    a,
  );
  assert.equal(
    previousLog([s], a.activityId, "2026-09-01T10:00:00Z"),
    undefined,
  );
});
test("trends distinguish up, down, unchanged and no prior comparison", () => {
  assert.equal(trend(a).direction, "new");
  assert.equal(trend(a, a).direction, "same");
  assert.equal(
    trend({ ...a, rows: [{ ...a.rows[0], weight: 30 }] }, a).percent,
    50,
  );
  assert.equal(
    trend({ ...a, rows: [{ ...a.rows[0], weight: 10 }] }, a).direction,
    "down",
  );
});
test("cardio and stretching use only checked work", () => {
  const cardio = {
    ...a,
    type: "cardio" as const,
    tags: ["cardio" as const],
    rows: [
      { ...a.rows[0], time: 60, distance: 1 },
      { ...a.rows[1], time: 999, distance: 99 },
    ],
  };
  assert.equal(score(cardio), 120);
  assert.deepEqual(intensity({ ...s, activities: [cardio] }), { cardio: 120 });
  assert.equal(
    score({
      ...a,
      type: "stretching",
      rows: [{ ...a.rows[0], time: 30, reps: 2 }],
    }),
    60,
  );
});
test("new users have no fabricated history and built-ins have valid tags and unique IDs", () => {
  const data = seedData("new-user");
  assert.equal(data.sessions.length, 0);
  assert.equal(data.activeSession, null);
  assert.ok(library.length >= 70);
  assert.equal(new Set(library.map((a) => a.id)).size, library.length);
  assert.ok(library.every((a) => a.tags.length && a.userId === null));
});
