import { test } from "node:test";
import assert from "node:assert/strict";
import { auth } from "../src/services/localAuth";
import { repository } from "../src/services/repository";
const memory = new Map<string, string>();
Object.defineProperty(globalThis, "localStorage", {
  value: {
    getItem: (k: string) => memory.get(k) || null,
    setItem: (k: string, v: string) => memory.set(k, v),
    removeItem: (k: string) => memory.delete(k),
  },
});
test("prototype register, verification, login, reset, logout and user isolation", async () => {
  const first = await auth.register(
    "Test",
    "test@example.invalid",
    "test-only-password",
  );
  assert.equal(first.verified, false);
  assert.equal(auth.current(), null);
  assert.equal(
    (await auth.login(first.email, "test-only-password")).verified,
    false,
  );
  auth.verify(first.id);
  assert.equal(auth.current()?.id, first.id);
  auth.logout();
  await assert.rejects(auth.login(first.email, "wrong-password"));
  await auth.reset(first.email, "new-test-password");
  await auth.login(first.email, "new-test-password");
  assert.equal(auth.current()?.id, first.id);
  const second = await auth.register(
    "Other",
    "other@example.invalid",
    "other-test-password",
  );
  const d = repository.load(first.id);
  d.templates[0].name = "Private template";
  repository.save(first.id, d);
  assert.equal(repository.load(first.id).templates[0].name, "Private template");
  assert.notEqual(
    repository.load(second.id).templates[0].name,
    "Private template",
  );
  assert.ok(
    !JSON.stringify([...memory.values()]).includes("new-test-password"),
  );
  auth.logout();
  assert.equal(auth.current(), null);
});
