# WorkoutStudio

A mobile-first React + TypeScript + Vite workout tracker. This deliverable has **Supabase-ready authentication** with a local demo fallback, isolated workout storage, and a proposed Supabase database migration. Supabase authentication activates when its project URL and public key are configured. Workout data still stays in this browser; cloud workout synchronization is not implemented. No public deployment is connected.

## Run locally

Use Node.js 22+ and pnpm 11.19.0.

```sh
pnpm install
pnpm dev
```

Open the printed local URL. Choose **Try the demo** for three labeled example sessions, or create a local account to start with empty history. Four editable starter templates and 81 built-in activities are included. With no Supabase environment configuration, registration, verification, sign-in, and reset are simulated in this browser. No verification/reset email is sent in local mode. Use disposable demo credentials. With Supabase configured, demo sign-in and simulated verification/reset are disabled, and these operations use Supabase Auth.

```sh
pnpm test        # Metrics, auth lifecycle, and storage separation tests
pnpm build       # TypeScript check and production output in dist/
pnpm preview     # Serve the production build
pnpm seed:export # Regenerate Supabase library seed from the shared catalog
```

## Using the app

- **Home:** newest sessions first; open one for set-level details, planned versus actual values, trends, and a front/back muscle map.
- **Workouts:** header **+** creates a template. Tap a template to edit it; the same **+** adds an activity. Pencil edits the name/goal. Targets save automatically.
- **Session:** choose a workout; edit actual reps, kilograms, seconds, or kilometres directly. Mark each set complete on the left. Previous completed values appear beside it. The timer continues across refreshes and tab switches; Home offers Resume. Only one session can be active per account.
- **Library:** search by name/body tag, filter by type or Custom, and use **+** to create an activity. Built-ins are read-only. Custom activities have a pencil. Creating one from a workout saves it in both places.
- Swipe a row left to reveal Delete, or use its three-dot button with keyboard/mouse. A confirmation precedes deletion. Saved logs retain names, tags, targets, and actual values when templates or library items change.
- Profile avatar opens account information and sign-out.

Units are kg, km, and seconds (cardio and stretch inputs); the timer displays hours:minutes:seconds. Targets and additional set counts are capped at 30. There is no billing, cloud sync, or real email service in the prototype.

## Architecture

- `src/data/types.ts`: shared entities and allowed muscle tags.
- `src/data/seed.ts`: original broad gym catalog and starter templates; not a TrainingPeaks data import.
- `src/data/metrics.ts`: pure calculations, previous-session lookup, and intensity.
- `src/services/repository.ts`: the only workout localStorage boundary; namespaced by account ID, schema version 1.
- `src/services/auth.ts`: chooses Supabase or local authentication. `supabaseAuth.ts` implements real auth; `localAuth.ts` contains the isolated demo. Local passwords are salted and derived using Web Crypto PBKDF2. Local verification/reset are **not an authentication security boundary**.
- `src/components/`: reusable dialogs, swipe rows, forms, body map, and session logger.
- `src/services/webmcp.ts`: optional, feature-detected read-only `list_workout_templates` browser tool. It unregisters when user state changes/unmounts.
- `supabase/migrations/001_workoutstudio.sql`: normalized production schema blueprint, ownership rules, parent-child ownership constraints, grants, and RLS.
- `supabase/seed.sql`: generated built-in catalog, inserted only by an administrative migration role.

LocalStorage keeps active and completed sessions in this browser. It is not encrypted or suitable as a SaaS security boundary; anyone with device/browser access can inspect it. Clearing site data removes accounts and workouts. Simultaneous tabs are not coordinated: the last writer wins. Storage failures show an error and do not replace the in-memory state with an unsaved mutation.

## Intensity and comparison rules

Only checked rows contribute. Strength volume is reps × kg; bodyweight/zero-load rows use reps × max(kg, 1) for the intensity estimate. Cardio work is seconds + kilometres × 60. Stretching work is seconds × count. Each activity credits its tags; map colors are relative to the most-worked tag in that session. The map is a simplified front/back diagram, not a physiological fatigue measure. Combined modality colors are heuristic, not a clinical or calibrated workload scale.

Trends compare the same activity ID against its latest earlier completed session that contains checked work. Strength compares volume; cardio and stretching compare the above work score. Unchecked rows are retained as Skipped in history but excluded from all summaries. The stored activity snapshots protect historical values against library edits/deletion. Example history appears only in the explicit demo workspace.

## Connect Supabase login

This checkout is configured in ignored `.env.local` for the existing **WorkOutStudio** project (`npllwuavofpfudchotma`, Singapore region). The project is restored and reports ACTIVE_HEALTHY. Email/password authentication and email confirmation are enabled. The exact local redirect URLs listed below are saved alongside the existing custom-domain URL. The public auth settings endpoint returns HTTP 200, and a deliberately nonexistent login receives the expected invalid_credentials response. Successful sign-in with the user’s credentials and end-to-end email delivery still require user verification.

1. Copy `.env.example` to `.env.local`.
2. Fill `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` from the chosen Supabase project’s settings. Use a publishable key (`sb_publishable_...`) or the legacy **anon** key. Never use a secret or service-role key. These Vite values are public and bundled into the frontend.
3. In Supabase Authentication settings, enable the Email provider, signups, and email confirmation. Keep confirmation enabled. Add these exact Redirect URLs for local development:
   - `http://127.0.0.1:5173/`
   - `http://127.0.0.1:5173/?auth=recovery`
   - If using `localhost` instead, add that hostname’s equivalent URLs too.
4. Restart `pnpm dev`. The login footer should say **Secure sign-in with Supabase** and the demo button should be absent. One missing environment value shows a configuration error rather than reverting to local login.
5. Create your real account from WorkoutStudio. Open the emailed verification link, then sign in. Existing local demo accounts do not become Supabase accounts automatically, and their workout data remains under its old local ID; it is not silently reassigned.
6. Test **Forgot password?**, open the recovery email, choose your new password yourself, then verify sign-out/sign-in and page refresh. The app uses Supabase’s client-only implicit callback handling so links can open in another browser. Recovery passwords are updated only with a valid authenticated session.

Set the Supabase **Site URL** to the final deployed app URL when publishing, and add its root and `?auth=recovery` redirect URLs, including any GitHub repository subpath. During local-only development it can be the local URL above. For GitHub Actions, add repository **Variables** named `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`; the workflow supplies them during the build. A public key is sufficient for login; do not run the workout database migration just to enable authentication.

The app uses real confirmation/resend and password-recovery email requests, token refresh, startup session restoration, and auth-change subscriptions. Configure SMTP in Supabase for delivery beyond its restricted built-in test email service. See [Supabase password authentication](https://supabase.com/docs/guides/auth/passwords) and [custom SMTP](https://supabase.com/docs/guides/auth/auth-smtp).

Adapter tests use controlled mock API responses. Real account creation, email delivery, callbacks, and project settings must be verified against the connected project before considering login setup complete.

## Supabase production integration

The SQL is a blueprint, **not applied or integration-tested against a live project**. Before a production launch:

1. Create a Supabase project, apply the migration, and run the library seed with an admin role. Never expose a service-role key in frontend code.
2. Configure the implemented Supabase auth adapter as described below. Display names are stored in Auth user metadata. When enabling database storage, insert the user's own profile after verification, or add a secure signup trigger.
3. Replace `repository.ts` with an async Supabase repository and update the `Studio` loading/save boundary for async status, retries, and conflicts. Map camelCase fields to SQL columns. Use transactional server RPCs for multi-table session creation/completion and template edits; do not delete and rewrite the entire user dataset on each keypress.
4. Set `user_id` from the authenticated session; retain RLS. User-owned parent/child records share composite foreign keys. Built-in activities have null ownership and no client write policy. Session activity IDs are historical references; their snapshot records belong to the session owner.
5. Add and run database tests with two real test users: allow own CRUD; deny cross-user reads/writes and reparenting; deny built-in mutation and anonymous access. Verify the one-active-session constraint, cascade behavior, and transaction rollback.
6. Configure allowed auth redirect URLs, real SMTP/email delivery, and password recovery on the final domain. Remove all local demo auth routes from the production auth adapter.

See [Supabase RLS guidance](https://supabase.com/docs/guides/database/postgres/row-level-security).

## GitHub Pages / static deployment

The repository includes `.github/workflows/deploy.yml`. Push to a GitHub repository with a `main` branch, then choose **Settings → Pages → Build and deployment → GitHub Actions**. The workflow installs the locked dependencies, runs tests/build, uploads `dist`, and deploys it. The relative Vite base works under a repository subpath. The app uses in-memory tab navigation, so it does not need server rewrite rules.

Other static hosts can run `pnpm build` and serve `dist/`. HTTPS is required for authentication crypto APIs outside localhost. No secrets or production configuration are required for this prototype.

For the future domain `WorkoutStudio.Sportzlabs.com`, configure `workoutstudio.sportzlabs.com` in the chosen host and the DNS provider after the domain is ready. For GitHub Pages, set the custom domain in repository Pages settings and follow its DNS/HTTPS checks. No DNS, CNAME, remote repository, or public deployment has been changed by this build.

See [GitHub's custom Pages workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

## SportzLabs deployment and Strava

The live homepage is `https://www.sportzlabs.com/`; the application is served at `/workoutstudio/`. GoDaddy manages the domain, while the `FartyButtBlast/SportzLabs` GitHub Pages repository hosts the files. Production builds use the `/workoutstudio/` asset base; local Vite development uses `/`.

The homepage source lives in `site/`. Build with `pnpm build`, then run `node scripts/build-site.mjs /path/to/SportzLabs`. Review and publish the resulting static files in the site's existing branch. The remote `workoutstudio-source.zip` archive contains a copy of this app's source for reproducibility. `.env.local` and server secrets must never be committed. The public Supabase URL/key are supplied at build time.

The optional Strava integration uses a deployed Supabase Edge Function and server-only tables. See [activation and operational notes](docs/STRAVA.md). Account settings contains the connection control; completed session details contains review and post controls. The integration remains unavailable until the owner supplies Strava API credentials.

Workout data is still stored per account in local browser storage. The hosted domain has a separate store from localhost; existing local workouts do not automatically migrate or sync to production.
