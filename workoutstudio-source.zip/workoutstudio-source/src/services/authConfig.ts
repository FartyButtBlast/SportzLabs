export type AuthConfig =
  { mode: "local" } | { mode: "supabase"; url: string; key: string };
export function readAuthConfig(
  env: Record<string, string | undefined>,
): AuthConfig {
  const url = env.VITE_SUPABASE_URL?.trim();
  const key = env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim();
  if (!url && !key) return { mode: "local" };
  if (!url || !key)
    throw new Error(
      "Supabase configuration is incomplete. Set both the project URL and publishable key.",
    );
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("The Supabase project URL is invalid.");
  }
  if (
    parsed.username ||
    parsed.password ||
    parsed.search ||
    parsed.hash ||
    !(
      parsed.protocol === "https:" ||
      (parsed.protocol === "http:" &&
        ["localhost", "127.0.0.1"].includes(parsed.hostname))
    )
  )
    throw new Error("Use a valid HTTPS Supabase project URL.");
  if (!key.startsWith("sb_publishable_")) {
    let role: string | undefined;
    try {
      role = JSON.parse(
        atob(key.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")),
      ).role;
    } catch {
      /* Invalid or secret key. */
    }
    if (role !== "anon")
      throw new Error(
        "Use the Supabase publishable or legacy anon key. Secret and service-role keys must never be placed in this app.",
      );
  }
  return { mode: "supabase", url: parsed.origin, key };
}
