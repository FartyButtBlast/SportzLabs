import { Profile, uid } from "../data/types";
interface Account extends Profile {
  salt: string;
  hash: string;
}
const KEY = "workoutstudio:accounts";
const accounts = (): Account[] => JSON.parse(localStorage.getItem(KEY) || "[]");
const write = (a: Account[]) => localStorage.setItem(KEY, JSON.stringify(a));
async function digest(password: string, salt: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: new TextEncoder().encode(salt),
      iterations: 100000,
      hash: "SHA-256",
    },
    key,
    256,
  );
  return Array.from(new Uint8Array(bits))
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
}
const profile = ({ id, name, email, verified }: Profile): Profile => ({
  id,
  name,
  email,
  verified,
});
export interface AuthService {
  current(): Profile | null;
  register(name: string, email: string, password: string): Promise<Profile>;
  login(email: string, password: string): Promise<Profile>;
  verify(id: string): Profile;
  reset(email: string, password: string): Promise<void>;
  demo(): Profile;
  logout(): void;
}
// Device-only simulation: verification/reset are explicit demo actions, never real emails.
export const auth: AuthService = {
  current() {
    const id = localStorage.getItem("workoutstudio:user");
    return id === "demo"
      ? {
          id: "demo",
          name: "Alex",
          email: "demo@workoutstudio.local",
          verified: true,
        }
      : profileOrNull(accounts().find((a) => a.id === id && a.verified));
  },
  async register(name, email, password) {
    email = email.trim().toLowerCase();
    if (accounts().some((a) => a.email === email))
      throw new Error("This email already has a local account.");
    if (password.length < 8) throw new Error("Use at least 8 characters.");
    const salt = uid();
    const a = {
      id: uid(),
      name: name.trim(),
      email,
      verified: false,
      salt,
      hash: await digest(password, salt),
    };
    write([...accounts(), a]);
    return profile(a);
  },
  async login(email, password) {
    const a = accounts().find((a) => a.email === email.trim().toLowerCase());
    if (!a || a.hash !== (await digest(password, a.salt)))
      throw new Error("Email or password is incorrect.");
    if (!a.verified) return profile(a);
    localStorage.setItem("workoutstudio:user", a.id);
    return profile(a);
  },
  verify(id) {
    const list = accounts();
    const a = list.find((x) => x.id === id);
    if (!a) throw new Error("Account not found.");
    a.verified = true;
    write(list);
    localStorage.setItem("workoutstudio:user", a.id);
    return profile(a);
  },
  async reset(email, password) {
    if (password.length < 8) throw new Error("Use at least 8 characters.");
    const list = accounts();
    const a = list.find((x) => x.email === email.trim().toLowerCase());
    if (!a) throw new Error("No local account found for that email.");
    a.salt = uid();
    a.hash = await digest(password, a.salt);
    write(list);
  },
  demo() {
    const p = {
      id: "demo",
      name: "Alex",
      email: "demo@workoutstudio.local",
      verified: true,
    };
    localStorage.setItem("workoutstudio:user", p.id);
    return p;
  },
  logout() {
    localStorage.removeItem("workoutstudio:user");
  },
};
function profileOrNull(a?: Account) {
  return a ? profile(a) : null;
}
