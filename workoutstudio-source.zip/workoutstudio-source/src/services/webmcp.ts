import { useEffect } from "react";
import { UserData } from "../data/types";
interface ModelContext {
  registerTool(
    tool: {
      name: string;
      description: string;
      inputSchema: object;
      annotations: { readOnlyHint: boolean; untrustedContentHint: boolean };
      execute: (input: unknown) => unknown;
    },
    options: { signal: AbortSignal },
  ): void | Promise<void>;
}
export function useWorkoutTools(data: UserData | null) {
  useEffect(() => {
    const context = (document as Document & { modelContext?: ModelContext })
      .modelContext;
    if (!data || !context?.registerTool) return;
    const lifecycle = new AbortController();
    try {
      void Promise.resolve(
        context.registerTool(
          {
            name: "list_workout_templates",
            description:
              "Read the signed-in user’s workout templates and activity counts shown in the Workouts tab.",
            inputSchema: {
              type: "object",
              properties: {},
              additionalProperties: false,
            },
            annotations: { readOnlyHint: true, untrustedContentHint: true },
            execute(input) {
              if (
                !input ||
                typeof input !== "object" ||
                Array.isArray(input) ||
                Object.keys(input).length
              )
                throw new Error("Expected an empty object");
              return {
                workouts: data.templates.map((t) => ({
                  id: t.id,
                  name: t.name,
                  description: t.description,
                  activities: t.activities.length,
                })),
              };
            },
          },
          { signal: lifecycle.signal },
        ),
      ).catch(() => {
        /* Optional browser capability: UI remains available. */
      });
    } catch {
      /* Unsupported implementation. */
    }
    return () => lifecycle.abort();
  }, [data]);
}
