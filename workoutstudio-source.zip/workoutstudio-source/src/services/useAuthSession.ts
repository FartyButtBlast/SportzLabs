import { useEffect, useState } from "react";
import { Profile } from "../data/types";
import { auth, authConfigurationError } from "./auth";
const recoveryKey = "workoutstudio:password-recovery";
function initialRecovery() {
  if (auth.mode !== "supabase") return false;
  return (
    new URLSearchParams(location.search).get("auth") === "recovery" ||
    new URLSearchParams(location.hash.slice(1)).get("type") === "recovery" ||
    sessionStorage.getItem(recoveryKey) === "1"
  );
}
function callbackError() {
  const params = new URLSearchParams(location.hash.slice(1));
  return params.has("error")
    ? "This authentication link is invalid or expired. Request a new confirmation or password reset email."
    : "";
}
export function useAuthSession() {
  const [user, setUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(authConfigurationError || callbackError);
  const [recovery, setRecovery] = useState(initialRecovery);
  useEffect(() => {
    if (authConfigurationError) {
      setLoading(false);
      return;
    }
    let mounted = true;
    const unsubscribe = auth.subscribe((event, profile) => {
      if (!mounted) return;
      setUser(profile?.verified ? profile : null);
      if (event === "PASSWORD_RECOVERY") {
        sessionStorage.setItem(recoveryKey, "1");
        setRecovery(true);
      }
      if (event === "SIGNED_OUT") {
        sessionStorage.removeItem(recoveryKey);
        setRecovery(false);
      }
      if (event === "INITIAL_SESSION") setLoading(false);
    });
    void auth
      .current()
      .then((profile) => {
        if (mounted) {
          setUser(profile?.verified ? profile : null);
          setLoading(false);
        }
      })
      .catch((e) => {
        if (mounted) {
          setError((e as Error).message);
          setLoading(false);
        }
      });
    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);
  function clearRecovery() {
    sessionStorage.removeItem(recoveryKey);
    const url = new URL(location.href);
    url.searchParams.delete("auth");
    if (new URLSearchParams(url.hash.slice(1)).has("error")) url.hash = "";
    history.replaceState(null, "", url);
    setRecovery(false);
    setError("");
  }
  async function logout() {
    await auth.logout();
    setUser(null);
    clearRecovery();
  }
  return { user, setUser, loading, error, recovery, clearRecovery, logout };
}
