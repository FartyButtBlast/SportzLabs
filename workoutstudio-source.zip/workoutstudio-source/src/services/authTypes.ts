import { Profile } from "../data/types";
export type AuthEvent =
  | "INITIAL_SESSION"
  | "SIGNED_IN"
  | "SIGNED_OUT"
  | "PASSWORD_RECOVERY"
  | "TOKEN_REFRESHED"
  | "USER_UPDATED";
export interface AuthService {
  mode: "local" | "supabase";
  current(): Promise<Profile | null>;
  subscribe(
    listener: (event: AuthEvent, user: Profile | null) => void,
  ): () => void;
  register(name: string, email: string, password: string): Promise<Profile>;
  login(email: string, password: string): Promise<Profile>;
  verify(id: string): Promise<Profile>;
  resendVerification(email: string): Promise<void>;
  reset(email: string, localPassword?: string): Promise<void>;
  updatePassword(password: string): Promise<void>;
  demo(): Promise<Profile>;
  logout(): Promise<void>;
}
