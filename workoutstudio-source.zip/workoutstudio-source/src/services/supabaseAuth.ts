import type { SupabaseClient, User } from "@supabase/supabase-js";
import { AuthService, AuthEvent } from "./authTypes";
import { Profile } from "../data/types";
export function toProfile(user: User): Profile {
  return {
    id: user.id,
    email: user.email || "",
    name: String(
      user.user_metadata?.display_name ||
        user.email?.split("@")[0] ||
        "Athlete",
    ),
    verified: !!user.email_confirmed_at,
  };
}
export function createSupabaseAuth(
  client: Pick<SupabaseClient, "auth">,
  baseUrl: () => string,
): AuthService {
  const redirect = (recovery = false) => {
    const url = new URL(baseUrl());
    url.search = "";
    url.hash = "";
    if (recovery) url.searchParams.set("auth", "recovery");
    return url.href;
  };
  return {
    mode: "supabase",
    async current() {
      const { data, error } = await client.auth.getSession();
      if (error) throw error;
      return data.session ? toProfile(data.session.user) : null;
    },
    subscribe(listener) {
      const { data } = client.auth.onAuthStateChange((event, session) =>
        listener(event as AuthEvent, session ? toProfile(session.user) : null),
      );
      return () => data.subscription.unsubscribe();
    },
    async register(name, email, password) {
      const displayName = name.trim();
      if (!displayName) throw new Error("Enter your name.");
      const { data, error } = await client.auth.signUp({
        email: email.trim().toLowerCase(),
        password,
        options: {
          data: { display_name: displayName },
          emailRedirectTo: redirect(),
        },
      });
      if (error) throw error;
      if (!data.user)
        throw new Error("Could not create your account. Please try again.");
      return { ...toProfile(data.user), verified: !!data.session };
    },
    async login(email, password) {
      const { data, error } = await client.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });
      if (error) throw error;
      if (!data.user || !data.session)
        throw new Error("Sign-in did not return a session.");
      return toProfile(data.user);
    },
    async verify() {
      throw new Error(
        "Open the verification link in your email to confirm your account.",
      );
    },
    async resendVerification(email) {
      const { error } = await client.auth.resend({
        type: "signup",
        email: email.trim().toLowerCase(),
        options: { emailRedirectTo: redirect() },
      });
      if (error) throw error;
    },
    async reset(email) {
      const { error } = await client.auth.resetPasswordForEmail(
        email.trim().toLowerCase(),
        { redirectTo: redirect(true) },
      );
      if (error) throw error;
    },
    async updatePassword(password) {
      if (password.length < 8) throw new Error("Use at least 8 characters.");
      const { data, error: sessionError } = await client.auth.getSession();
      if (sessionError) throw sessionError;
      if (!data.session)
        throw new Error("Your reset link has expired. Request a new one.");
      const { error } = await client.auth.updateUser({ password });
      if (error) throw error;
    },
    async demo() {
      throw new Error(
        "Demo sign-in is unavailable when Supabase is connected.",
      );
    },
    async logout() {
      const { error } = await client.auth.signOut({ scope: "local" });
      if (error) throw error;
    },
  };
}
