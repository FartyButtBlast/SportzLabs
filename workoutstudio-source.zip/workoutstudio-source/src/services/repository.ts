import { UserData } from "../data/types";
import { seedData } from "../data/seed";
// Replace this adapter with Supabase queries. UI components never read storage directly.
export interface WorkoutRepository {
  load(userId: string): UserData;
  save(userId: string, data: UserData): void;
}
export const repository: WorkoutRepository = {
  load(userId) {
    const raw = localStorage.getItem(`workoutstudio:data:${userId}`);
    if (!raw) return seedData(userId, userId === "demo");
    const value = JSON.parse(raw);
    if (value.version !== 1) throw new Error("Unsupported saved data version");
    return value;
  },
  save(userId, data) {
    localStorage.setItem(`workoutstudio:data:${userId}`, JSON.stringify(data));
  },
};
