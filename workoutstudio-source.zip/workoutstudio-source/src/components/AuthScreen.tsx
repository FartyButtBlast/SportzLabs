import { useState } from "react";
import { Dumbbell, Check, ArrowLeft } from "lucide-react";
import { auth } from "../services/auth";
import { Profile } from "../data/types";
type Mode = "login" | "register" | "reset";
export default function AuthScreen({
  onLogin,
  initialError = "",
  initialMode = "login",
}: {
  onLogin: (p: Profile) => void;
  initialError?: string;
  initialMode?: Mode;
}) {
  const live = auth.mode === "supabase";
  const [mode, setMode] = useState<Mode>(initialMode);
  const [pending, setPending] = useState<Profile | null>(null);
  const [error, setError] = useState(initialError);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  async function act(action: () => Promise<void>) {
    setError("");
    setMessage("");
    setBusy(true);
    try {
      await action();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const changeMode = (next: Mode) => {
    setMode(next);
    setError("");
    setMessage("");
  };
  return (
    <div className="auth-layout">
      <div className="auth-brand">
        <Dumbbell />
        <span>
          Workout<b>Studio</b>
        </span>
      </div>
      <div className="auth-art">
        <span className="eyebrow">A LITTLE STRONGER. EVERY DAY.</span>
        <h1>
          Make every <br />
          rep count.
        </h1>
        <p>
          Your workouts, your progress,
          <br />
          your own pace.
        </p>
        <div className="auth-bars">
          <i />
          <i />
          <i />
          <i />
          <i />
          <i />
          <i />
        </div>
      </div>
      <section className="auth-form panel">
        {pending ? (
          <>
            <span className="success-icon">
              <Check />
            </span>
            <h2>Verify your email</h2>
            <p className="muted">
              {live ? (
                <>
                  Check <b>{pending.email}</b> for a confirmation link. Open it
                  to activate your account, then sign in here.
                </>
              ) : (
                <>
                  This prototype doesn’t send email. Simulate the verification
                  link for <b>{pending.email}</b> below.
                </>
              )}
            </p>
            <button
              className="primary full"
              disabled={busy}
              onClick={() =>
                act(async () => {
                  if (live) {
                    await auth.resendVerification(pending.email);
                    setMessage(
                      "If this account needs confirmation, a new link has been sent.",
                    );
                  } else onLogin(await auth.verify(pending.id));
                })
              }
            >
              {busy
                ? "Please wait…"
                : live
                  ? "Resend confirmation email"
                  : "Simulate email verification"}
            </button>
            <button
              className="text-button"
              disabled={busy}
              onClick={() => {
                setPending(null);
                changeMode("login");
              }}
            >
              Back to sign in
            </button>
          </>
        ) : (
          <>
            <p className="eyebrow">YOUR PERSONAL TRAINING SPACE</p>
            <h2>
              {mode === "login"
                ? "Welcome back."
                : mode === "register"
                  ? "Start your next chapter."
                  : "Reset your password"}
            </h2>
            <p className="muted">
              {mode === "login"
                ? "Pick up where you left off."
                : mode === "register"
                  ? "Build a routine that belongs to you."
                  : live
                    ? "Enter your email and we’ll send a secure reset link."
                    : "Demo reset updates only this browser’s local account. No email is sent."}
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const f = new FormData(e.currentTarget);
                const email = String(f.get("email"));
                void act(async () => {
                  if (mode === "reset") {
                    await auth.reset(
                      email,
                      live ? undefined : String(f.get("password")),
                    );
                    setMessage(
                      live
                        ? "If an account exists for that email, you’ll receive a password reset link. Check your inbox and spam folder."
                        : "Local password updated. Sign in with your new password.",
                    );
                    if (!live) setMode("login");
                  } else {
                    try {
                      const p =
                        mode === "register"
                          ? await auth.register(
                              String(f.get("name")),
                              email,
                              String(f.get("password")),
                            )
                          : await auth.login(email, String(f.get("password")));
                      if (p.verified) onLogin(p);
                      else setPending(p);
                    } catch (e) {
                      if (
                        live &&
                        (e as { code?: string }).code === "email_not_confirmed"
                      ) {
                        setPending({
                          id: "",
                          name: "",
                          email,
                          verified: false,
                        });
                        return;
                      }
                      throw e;
                    }
                  }
                });
              }}
            >
              {mode === "register" && (
                <label>
                  Your name
                  <input
                    name="name"
                    required
                    maxLength={60}
                    autoComplete="given-name"
                    placeholder="Alex"
                  />
                </label>
              )}
              <label>
                Email address
                <input
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  placeholder="you@example.com"
                />
              </label>
              {(mode !== "reset" || !live) && (
                <label>
                  {mode === "reset" ? "New password" : "Password"}
                  <input
                    name="password"
                    type="password"
                    required
                    minLength={mode === "login" ? undefined : 8}
                    autoComplete={
                      mode === "login" ? "current-password" : "new-password"
                    }
                    placeholder={
                      mode === "login"
                        ? "Your password"
                        : "At least 8 characters"
                    }
                  />
                </label>
              )}
              {mode === "login" && (
                <button
                  type="button"
                  className="text-button align-right"
                  disabled={busy}
                  onClick={() => changeMode("reset")}
                >
                  Forgot password?
                </button>
              )}
              <button className="primary full" disabled={busy}>
                {busy
                  ? "Please wait…"
                  : mode === "login"
                    ? "Sign in"
                    : mode === "register"
                      ? "Create account"
                      : live
                        ? "Send reset link"
                        : "Simulate password reset"}
              </button>
            </form>
            {mode === "login" ? (
              <>
                <p className="auth-switch">
                  New here?{" "}
                  <button
                    className="text-button"
                    disabled={busy}
                    onClick={() => changeMode("register")}
                  >
                    Create an account
                  </button>
                </p>
                {!live && (
                  <>
                    <div className="or">
                      <span />
                      or explore first
                      <span />
                    </div>
                    <button
                      className="secondary full"
                      disabled={busy}
                      onClick={() =>
                        act(async () => onLogin(await auth.demo()))
                      }
                    >
                      Try the demo
                    </button>
                  </>
                )}
              </>
            ) : (
              <button
                className="text-button"
                disabled={busy}
                onClick={() => changeMode("login")}
              >
                <ArrowLeft size={16} /> Back to sign in
              </button>
            )}
          </>
        )}
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        {message && (
          <p className="success" role="status">
            {message}
          </p>
        )}
        <p className="demo-note">
          {live ? (
            <>
              Secure sign-in with Supabase.
              <br />
              Workout data is still saved in this browser.
            </>
          ) : (
            <>
              LOCAL PROTOTYPE · Data stays in this browser.
              <br />
              Demo authentication is not production security.
            </>
          )}
        </p>
      </section>
    </div>
  );
}
