import { useEffect, useState } from 'react';
import { Session } from '../data/types';
import { completeStravaCallback, shareDraft, stravaRequest, StravaStatus } from '../services/strava';
import type { ShareInput } from '../../supabase/functions/strava/payload';
export function StravaCallback() {
 const [message,setMessage] = useState('');
 useEffect(()=>{const p = completeStravaCallback(); if(p){setMessage('Finishing your Strava connection…');p.then(()=>setMessage('Strava connected. Open a completed session to review and share it.')).catch(e=>setMessage(e.message));}},[]);
 return message ? <div className="strava-notice" role="status">{message}</div> : null;
}
export default function StravaPanel({session}:{session?:Session}) {
 const [status,setStatus] = useState<StravaStatus|null>(null);
 const [error,setError] = useState('');
 const [busy,setBusy] = useState(false);
 const [draft,setDraft] = useState<ShareInput|null>(null);
 const [disconnecting,setDisconnecting] = useState(false);
 const refresh = () => stravaRequest<StravaStatus>({action:'status',sessionId:session?.id}).then(setStatus);
 useEffect(()=>{let alive=true;stravaRequest<StravaStatus>({action:'status',sessionId:session?.id}).then(s=>{if(alive)setStatus(s);}).catch(e=>{if(alive)setError(e.message);});return()=>{alive=false;};},[session?.id]);
 const run = async(fn:()=>Promise<void>)=>{setBusy(true);setError('');try{await fn();}catch(e){setError((e as Error).message);}finally{setBusy(false);}};
 if(session?.sample) return null;
 const posted = status?.post?.status === 'posted';
 const uncertain = status?.post && ['sending','unknown'].includes(status.post.status);
 return <section className="strava-panel">
  <div className="section-title"><h3>Strava</h3><span className="small muted">{status?.connected?'Connected':'Optional connection'}</span></div>
  <p className="small muted">{session ? 'Share this completed session as a manual Strava activity. No route or GPS data is added.' : 'Connect to post completed workouts when you choose. Workout Studio requests permission to upload activities.'}</p>
  {error && <p role="alert" className="strava-error">{error}</p>}
  {!status && !error && <p className="small muted">Checking connection…</p>}
  {!status && error && <button className="secondary" disabled={busy} onClick={()=>run(refresh)}>Try again</button>}
  {status && !status.configured && <p className="small muted">Strava sharing is awaiting the site owner’s API setup. Your completed workout stays saved here.</p>}
  {status?.configured && !status.connected && <button className="strava-button" disabled={busy} onClick={()=>run(async()=>{const r=await stravaRequest<{url:string}>({action:'connect',redirectUri:new URL(import.meta.env.BASE_URL,window.location.href).href});window.location.assign(r.url);})}>{busy?'Connecting…':'Connect with Strava'}</button>}
  {posted && <a className="strava-link" href={`https://www.strava.com/activities/${status?.post?.activity_id}`} target="_blank" rel="noopener noreferrer">View on Strava ↗</a>}
  {uncertain && <p role="status" className="small muted">This workout may already be on Strava. Check your activity feed; another post is blocked to prevent duplicates.</p>}
  {status?.configured && status.connected && session && !posted && !uncertain && !draft && <button className="strava-button" disabled={busy} onClick={()=>{try{setDraft(shareDraft(session));}catch(e){setError((e as Error).message);}}}>Review for Strava</button>}
  {draft && !posted && !uncertain && <form className="strava-review" onSubmit={e=>{e.preventDefault();run(async()=>{await stravaRequest({action:'share',workout:draft});await refresh();setDraft(null);});}}>
   <label>Activity title<input required maxLength={100} value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})}/></label>
   <label>Activity type<select value={draft.sportType} onChange={e=>setDraft({...draft,sportType:e.target.value})}><option value="Workout">Workout</option><option value="WeightTraining">Weight training</option><option value="Yoga">Yoga</option><option value="Run">Run</option><option value="Ride">Ride</option><option value="Walk">Walk</option><option value="Swim">Swim</option></select></label>
   <label>Duration (minutes)<input type="number" min="0.0167" max="10080" step="any" required value={Number((draft.elapsedTime/60).toFixed(2))} onChange={e=>setDraft({...draft,elapsedTime:Math.round(Number(e.target.value)*60)})}/></label>
   <p className="small muted">Started {new Date(draft.startedAt).toLocaleString()}. Review the duration if your session timer was left running.</p>
   <label>Description<textarea rows={7} maxLength={4000} value={draft.description} onChange={e=>setDraft({...draft,description:e.target.value})}/></label>
   <p className="small muted">This sends the details above to Strava. Visibility follows your Strava account settings. Only checked sets are included.</p>
   <div className="form-actions"><button type="button" className="secondary" disabled={busy} onClick={()=>setDraft(null)}>Cancel</button><button type="submit" className="strava-button" disabled={busy}>{busy?'Posting…':'Post to Strava'}</button></div>
  </form>}
  {status?.connected && !session && <>{disconnecting?<div><p className="small muted">Disconnecting revokes Workout Studio’s access. Workouts already posted to Strava remain there.</p><button className="secondary" disabled={busy} onClick={()=>run(async()=>{await stravaRequest({action:'disconnect'});await refresh();setDisconnecting(false);})}>Confirm disconnect</button> <button className="text-button" disabled={busy} onClick={()=>setDisconnecting(false)}>Cancel</button></div>:<button className="text-button" onClick={()=>setDisconnecting(true)}>Disconnect Strava</button>}</>}
 </section>;
}
