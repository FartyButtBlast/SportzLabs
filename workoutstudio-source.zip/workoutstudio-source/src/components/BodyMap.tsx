import { Tag } from "../data/types";
// Anatomical diagram: front and back areas deliberately separated; color is relative work per session.
export default function BodyMap({
  values,
  large = false,
}: {
  values: Partial<Record<Tag, number>>;
  large?: boolean;
}) {
  const max = Math.max(1, ...Object.values(values));
  const color = (tag: Tag) =>
    !values[tag]
      ? "#dfe5df"
      : values[tag]! / max > 0.65
        ? "#387f53"
        : values[tag]! / max > 0.3
          ? "#86b768"
          : "#c4df95";
  return (
    <svg
      className={`body-map ${large ? "large" : ""}`}
      viewBox="0 0 160 154"
      role="img"
      aria-label={`Worked areas: ${
        Object.entries(values)
          .filter(([, v]) => v > 0)
          .map(([k]) => k)
          .join(", ") || "none"
      }`}
    >
      <g fill="#dfe5df" stroke="#f8faf5" strokeWidth="1.5">
        <circle cx="41" cy="14" r="10" />
        <path d="M34 24h14l3 7 16 6 9 41-8 4-13-33-3 33 4 27-5 35H40l-1-33-3 33H25l-1-35 5-27-3-33-12 33-8-4 10-41 16-6z" />
        <path
          d="M28 36l12-3v18l-12-4zM42 33l13 3v11l-13 4z"
          fill={color("chest")}
        />
        <path
          d="M20 36l7-3 1 14-10 1zM55 33l8 3 3 12-10-1z"
          fill={color("shoulders")}
        />
        <path
          d="M17 49l9 1-5 16-8-2zM57 50l9-1 5 15-8 2z"
          fill={color("biceps")}
        />
        <path d="M32 53h17l2 27H30z" fill={color("abs")} />
        <path
          d="M29 85h10l-2 28-11-3zM42 85h10l3 25-12 3z"
          fill={color("quads")}
        />
        <path
          d="M26 114h10l-2 24h-8zM43 114h10l-3 24h-7z"
          fill={color("calves")}
        />
        <circle cx="119" cy="14" r="10" />
        <path d="M112 24h14l3 7 16 6 9 41-8 4-13-33-3 33 4 27-5 35h-11l-1-33-3 33h-11l-1-35 5-27-3-33-12 33-8-4 10-41 16-6z" />
        <path d="M106 35l13-4 13 4-4 43h-18z" fill={color("back")} />
        <path
          d="M98 36l7-3 1 14-10 1zM133 33l8 3 3 12-10-1z"
          fill={color("shoulders")}
        />
        <path
          d="M95 49l9 1-5 16-8-2zM135 50l9-1 5 15-8 2z"
          fill={color("triceps")}
        />
        <path
          d="M109 80h10v16h-13zM120 80h9l4 16h-13z"
          fill={color("glutes")}
        />
        <path
          d="M105 98h12l-2 16h-12zM121 98h12l-1 16h-11z"
          fill={color("hamstrings")}
        />
        <path
          d="M104 117h10l-2 21h-8zM121 117h10l-3 21h-7z"
          fill={color("calves")}
        />
      </g>
      {values.cardio ? (
        <g>
          <circle cx="41" cy="43" r="7" fill={color("cardio")} />
          <path
            d="M36 43h3l2-3 2 6 2-3h2"
            fill="none"
            stroke="#fff"
            strokeWidth="1.4"
          />
        </g>
      ) : null}
    </svg>
  );
}
