import { useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { auth } from "../services/auth";
export default function PasswordRecovery({
  onDone,
  onCancel,
}: {
  onDone: () => void;
  onCancel: () => Promise<void>;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  return (
    <main className="recovery-layout">
      <section className="panel auth-form">
        <p className="eyebrow">WORKOUTSTUDIO</p>
        {done ? (
          <>
            <CheckCircle2 />
            <h2>Password updated</h2>
            <p className="muted">Your new password is ready to use.</p>
            <button className="primary full" onClick={onDone}>
              Continue to workouts
            </button>
          </>
        ) : (
          <>
            <h2>Choose a new password</h2>
            <p className="muted">Use at least eight characters.</p>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const f = new FormData(e.currentTarget);
                const password = String(f.get("password"));
                if (password !== f.get("confirm")) {
                  setError("The passwords don’t match.");
                  return;
                }
                setBusy(true);
                setError("");
                try {
                  await auth.updatePassword(password);
                  setDone(true);
                } catch (e) {
                  setError((e as Error).message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              <label>
                New password
                <input
                  type="password"
                  name="password"
                  autoComplete="new-password"
                  required
                  minLength={8}
                />
              </label>
              <label>
                Confirm new password
                <input
                  type="password"
                  name="confirm"
                  autoComplete="new-password"
                  required
                  minLength={8}
                />
              </label>
              <button className="primary full" disabled={busy}>
                {busy ? "Updating…" : "Update password"}
              </button>
            </form>
            <button
              className="text-button"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                setError("");
                try {
                  await onCancel();
                } catch (e) {
                  setError((e as Error).message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              Cancel and sign out
            </button>
          </>
        )}
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
      </section>
    </main>
  );
}
