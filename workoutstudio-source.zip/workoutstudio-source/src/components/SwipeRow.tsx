import { ReactNode, useRef, useState } from "react";
import { MoreHorizontal, Trash2 } from "lucide-react";
export default function SwipeRow({
  children,
  onDelete,
  label,
}: {
  children: ReactNode;
  onDelete: () => void;
  label: string;
}) {
  const [open, setOpen] = useState(false);
  const start = useRef<{ x: number; y: number } | null>(null);
  return (
    <div className={`swipe-row ${open ? "revealed" : ""}`}>
      <button
        className="swipe-delete"
        aria-label={`Delete ${label}`}
        onClick={onDelete}
      >
        <Trash2 size={19} />
        Delete
      </button>
      <div
        className="swipe-content"
        onTouchStart={(e) =>
          (start.current = { x: e.touches[0].clientX, y: e.touches[0].clientY })
        }
        onTouchEnd={(e) => {
          if (!start.current) return;
          const dx = e.changedTouches[0].clientX - start.current.x,
            dy = e.changedTouches[0].clientY - start.current.y;
          if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) setOpen(dx < 0);
          start.current = null;
        }}
      >
        {children}
        <button
          className="row-menu"
          aria-label={`${open ? "Hide" : "Show"} delete for ${label}`}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <MoreHorizontal size={19} />
        </button>
      </div>
    </div>
  );
}
