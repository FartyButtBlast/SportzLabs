import {
  Activity,
  ActivityType,
  Tag,
  Targets,
  Template,
  UserData,
  uid,
} from "./types";
export const defaultTargets = (type: ActivityType): Targets => ({
  sets: type === "cardio" ? 1 : 3,
  reps: type === "strength" ? 10 : type === "stretching" ? 1 : 0,
  weight: type === "strength" ? 20 : 0,
  time: type === "cardio" ? 1200 : type === "stretching" ? 30 : 0,
  distance: type === "cardio" ? 5 : 0,
});
const groups: [ActivityType, string, Tag[]][] = [
  [
    "strength",
    "Back Squat|Front Squat|Goblet Squat|Leg Press|Single Leg Press|Hack Squat|Bulgarian Split Squat|Walking Lunge|Reverse Lunge|Step Up",
    ["quads", "glutes"],
  ],
  [
    "strength",
    "Deadlift|Romanian Deadlift|Single Leg Deadlift|Good Morning",
    ["hamstrings", "glutes", "back"],
  ],
  [
    "strength",
    "Bench Press|Incline Bench Press|DB Bench Press|Incline DB Press|Chest Fly|Cable Fly|Push Up",
    ["chest", "triceps"],
  ],
  [
    "strength",
    "DB Row|Seated Row|Lat Pulldown|Pull Up|Chin Up|Barbell Row|T Bar Row|Assisted Pull Up",
    ["back", "biceps"],
  ],
  [
    "strength",
    "Shoulder Press|DB Shoulder Press|Arnold Press",
    ["shoulders", "triceps"],
  ],
  [
    "strength",
    "Lateral Raise|Front Raise|Reverse Fly|Face Pull",
    ["shoulders"],
  ],
  ["strength", "Bicep Curl|Hammer Curl|Preacher Curl|Cable Curl", ["biceps"]],
  [
    "strength",
    "Tricep Pushdown|Overhead Tricep Extension|Skull Crusher|Tricep Dip",
    ["triceps"],
  ],
  [
    "strength",
    "Plank|Side Plank|Cable Crunch|Hanging Knee Raise|Russian Twist|Ab Wheel Rollout",
    ["abs"],
  ],
  ["strength", "Hip Thrust|Glute Bridge|Cable Kickback", ["glutes"]],
  ["strength", "Leg Extension", ["quads"]],
  ["strength", "Seated Leg Curl|Lying Leg Curl", ["hamstrings"]],
  ["strength", "Standing Calf Raise|Seated Calf Raise", ["calves"]],
  [
    "cardio",
    "Stationary Bike|Rowing|Jump Rope|Treadmill Run|Outdoor Run|Walking|Elliptical|Stair Climber|Swimming|Assault Bike",
    ["cardio"],
  ],
  ["stretching", "Hamstring Stretch|Seated Forward Fold", ["hamstrings"]],
  ["stretching", "Hip Flexor Stretch|Quad Stretch", ["quads"]],
  ["stretching", "Pigeon Stretch|Figure Four Stretch", ["glutes"]],
  ["stretching", "Calf Stretch", ["calves"]],
  ["stretching", "Chest Stretch", ["chest"]],
  ["stretching", "Child’s Pose|Lat Stretch", ["back"]],
  ["stretching", "Shoulder Stretch", ["shoulders"]],
  ["stretching", "Tricep Stretch", ["triceps"]],
  ["stretching", "Cobra Stretch", ["abs"]],
];
export const library: Activity[] = groups.flatMap(([type, names, tags]) =>
  names
    .split("|")
    .map((name) => ({
      id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      userId: null,
      name,
      type,
      tags,
      defaults: defaultTargets(type),
    })),
);
export function seedData(userId: string, demo = false): UserData {
  const make = (
    name: string,
    description: string,
    ids: string[],
  ): Template => ({
    id: uid(),
    userId,
    name,
    description,
    createdAt: new Date().toISOString(),
    activities: ids.map((id) => ({
      id: uid(),
      activityId: id,
      targets: { ...library.find((a) => a.id === id)!.defaults },
    })),
  });
  const templates = [
    make("Push day", "Chest, shoulders & triceps", [
      "bench-press",
      "incline-db-press",
      "shoulder-press",
      "lateral-raise",
      "tricep-pushdown",
    ]),
    make("Leg day", "Build a stronger foundation", [
      "back-squat",
      "romanian-deadlift",
      "leg-press",
      "standing-calf-raise",
    ]),
    make("Pull day", "Back & biceps", [
      "lat-pulldown",
      "db-row",
      "seated-row",
      "bicep-curl",
    ]),
    make("Cardio & mobility", "Move well. Feel better.", [
      "stationary-bike",
      "hamstring-stretch",
      "hip-flexor-stretch",
    ]),
  ];
  const data: UserData = {
    version: 1,
    templates,
    customActivities: [],
    sessions: [],
    activeSession: null,
  };
  if (demo)
    [5, 3, 1].forEach((days, i) => {
      const t = templates[i === 1 ? 1 : 0];
      const end = new Date();
      end.setDate(end.getDate() - days);
      end.setHours(7, 45, 0, 0);
      data.sessions.push({
        id: uid(),
        userId,
        templateId: t.id,
        name: t.name,
        startedAt: new Date(+end - 42 * 60000).toISOString(),
        completedAt: end.toISOString(),
        sample: true,
        activities: t.activities.map((ta, j) => {
          const a = library.find((x) => x.id === ta.activityId)!;
          return {
            id: uid(),
            activityId: a.id,
            name: a.name,
            type: a.type,
            tags: a.tags,
            planned: { ...ta.targets },
            rows: Array.from({ length: 3 }, () => ({
              id: uid(),
              reps: 10,
              weight: [60, 22, 25, 8, 18][j] + (i === 2 ? 2 : 0),
              time: 0,
              distance: 0,
              done: true,
            })),
          };
        }),
      });
    });
  return data;
}
