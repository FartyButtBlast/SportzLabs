export const TAGS = [
  "chest",
  "back",
  "shoulders",
  "biceps",
  "triceps",
  "abs",
  "glutes",
  "quads",
  "hamstrings",
  "calves",
  "cardio",
] as const;
export type Tag = (typeof TAGS)[number];
export type ActivityType = "strength" | "cardio" | "stretching";
export interface Targets {
  sets: number;
  reps: number;
  weight: number;
  time: number;
  distance: number;
}
export interface Activity {
  id: string;
  userId: string | null;
  name: string;
  type: ActivityType;
  tags: Tag[];
  defaults: Targets;
}
export interface TemplateActivity {
  id: string;
  activityId: string;
  targets: Targets;
}
export interface Template {
  id: string;
  userId: string;
  name: string;
  description: string;
  activities: TemplateActivity[];
  createdAt: string;
}
export interface SetRow {
  id: string;
  reps: number;
  weight: number;
  time: number;
  distance: number;
  done: boolean;
}
export interface ActivityLog {
  id: string;
  activityId: string;
  name: string;
  type: ActivityType;
  tags: Tag[];
  planned: Targets;
  rows: SetRow[];
}
export interface Session {
  id: string;
  userId: string;
  templateId: string;
  name: string;
  startedAt: string;
  completedAt: string | null;
  activities: ActivityLog[];
  sample?: boolean;
}
export interface UserData {
  version: 1;
  templates: Template[];
  customActivities: Activity[];
  sessions: Session[];
  activeSession: Session | null;
}
export interface Profile {
  id: string;
  name: string;
  email: string;
  verified: boolean;
}
export const uid = () => crypto.randomUUID();
export const labels: Record<ActivityType, string> = {
  strength: "Weight lifting",
  cardio: "Cardio",
  stretching: "Stretching",
};
