import { ActivityLog, Session, Tag } from "./types";
export const completedRows = (s: Session) =>
  s.activities.flatMap((a) => a.rows.filter((r) => r.done));
export const volume = (s: Session) =>
  s.activities
    .filter((a) => a.type === "strength")
    .reduce(
      (n, a) =>
        n +
        a.rows.filter((r) => r.done).reduce((v, r) => v + r.reps * r.weight, 0),
      0,
    );
export const duration = (s: Session) =>
  Math.max(
    0,
    Math.round(
      ((s.completedAt ? +new Date(s.completedAt) : Date.now()) -
        +new Date(s.startedAt)) /
        60000,
    ),
  );
export const score = (a: ActivityLog) =>
  a.rows
    .filter((r) => r.done)
    .reduce(
      (n, r) =>
        n +
        (a.type === "strength"
          ? r.reps * Math.max(r.weight, 1)
          : a.type === "cardio"
            ? r.time + r.distance * 60
            : r.time * Math.max(r.reps, 1)),
      0,
    );
export function intensity(s: Session): Partial<Record<Tag, number>> {
  const values: Partial<Record<Tag, number>> = {};
  s.activities.forEach((a) => {
    const work = score(a);
    if (work > 0)
      a.tags.forEach((tag) => (values[tag] = (values[tag] || 0) + work));
  });
  return values;
}
export function previousLog(
  sessions: Session[],
  activityId: string,
  before: string,
  exclude?: string,
) {
  return [...sessions]
    .filter(
      (s) =>
        s.completedAt &&
        s.id !== exclude &&
        +new Date(s.completedAt) < +new Date(before),
    )
    .sort((a, b) => +new Date(b.completedAt!) - +new Date(a.completedAt!))
    .flatMap((s) => s.activities)
    .find((a) => a.activityId === activityId && a.rows.some((r) => r.done));
}
export function trend(a: ActivityLog, previous?: ActivityLog) {
  if (!a.rows.some((r) => r.done))
    return { label: "Skipped", direction: "new", percent: 0 };
  if (!previous)
    return { label: "First session", direction: "new", percent: 0 };
  const old = score(previous),
    current = score(a);
  if (!old)
    return {
      label: current ? "Up from zero" : "Unchanged",
      direction: current ? "up" : "same",
      percent: 0,
    };
  const p = Math.round(((current - old) / old) * 100);
  return {
    label:
      p === 0
        ? "Unchanged"
        : `${p > 0 ? "+" : ""}${p}% ${a.type === "strength" ? "volume" : "work"}`,
    direction: p > 0 ? "up" : p < 0 ? "down" : "same",
    percent: p,
  };
}
