# Strava integration

Server: Supabase project `npllwuavofpfudchotma`, Edge Function `strava`.
Frontend: https://www.sportzlabs.com/workoutstudio/

## One-time activation

1. Sign in at https://www.strava.com/settings/api and create or select a Strava API application for Workout Studio.
2. Use website `https://www.sportzlabs.com/workoutstudio/` and Authorization Callback Domain `www.sportzlabs.com` (no protocol or path). Review Strava's API terms yourself before accepting.
3. In Supabase > Edge Functions > Secrets, add `STRAVA_CLIENT_ID` and `STRAVA_CLIENT_SECRET`. Never put the client secret, service-role key or access tokens in Vite variables, this repository, or chat.
4. Open Workout Studio, sign in, and choose Account > Connect with Strava. Approve activity upload permission personally.
5. Complete a real session, review the title, sport type, duration and description, then choose Post to Strava. Open the returned Strava link and verify it. No real activity has been posted during implementation testing.

New Strava API applications may be restricted to their owner's athlete account until Strava approves broader access. Confirm current capacity in the Strava dashboard before offering the connection to other users.

## Design

The Edge Function authenticates every action with `supabase.auth.getUser(bearerToken)`. Gateway `verify_jwt=false` is intentional: user authentication is performed in the handler, compatible with current Supabase signing keys. There is no unauthenticated OAuth callback endpoint. The browser returns the OAuth code/state while signed into Workout Studio; a single-use 10-minute state binds it to the user.

The two integration tables have RLS enabled and all grants revoked from anon/authenticated/public. Only server service_role can access tokens and posting records. The no-policy advisor notices are intentional default-deny behavior. The frontend only receives connection status and activity IDs.

A per-user atomic lease serializes OAuth exchange, refresh, disconnect and posting. Refresh-token rotations are saved before uploading. A unique `(user_id, session_id)` record prevents repeated uploads. Ambiguous network/server failures remain blocked to avoid duplicates; support should verify the athlete's feed before manually reconciling that record. Do not blindly retry unknown/sending records.

The app sends a manual activity, not a GPS route. It requests `activity:write`, generates descriptions from checked sets only, and lets the user review/edit every outgoing field. Strava account settings determine activity visibility. Disconnect revokes the grant and removes local server tokens; it does not delete posted activities or the minimal duplicate-protection records.

## Validation

Run `pnpm test` and `pnpm build`. Deploy the migration with the Supabase migration tool, then deploy `supabase/functions/strava/index.ts` and `payload.ts`. Test unauthenticated requests (401), invalid origin (403), denied client table access, and signed-in connection status. OAuth exchange and actual posting require the owner's credentials and explicit athlete consent.

References: https://developers.strava.com/docs/authentication/ and https://developers.strava.com/docs/reference/#api-Activities-createActivity
