export type ShareInput = {
  sessionId: string; name: string; sportType: string; startedAt: string;
  elapsedTime: number; description: string;
};
export function validateShare(input: unknown): ShareInput {
  const x = input as ShareInput;
  if (!x || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x.sessionId || '')) throw new Error('Invalid session.');
  if (typeof x.name !== 'string' || !x.name.trim() || x.name.length > 100) throw new Error('Use a workout title of 1–100 characters.');
  if (!['Workout', 'WeightTraining', 'Yoga', 'Run', 'Ride', 'Walk', 'Swim'].includes(x.sportType)) throw new Error('Choose a supported activity type.');
  if (!Number.isInteger(x.elapsedTime) || x.elapsedTime < 1 || x.elapsedTime > 604800) throw new Error('Enter a duration between 1 second and 7 days.');
  if (typeof x.startedAt !== 'string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?(?:Z|[+-]\d\d:\d\d)$/.test(x.startedAt) || !Number.isFinite(Date.parse(x.startedAt)) || Date.parse(x.startedAt) > Date.now() + 60000) throw new Error('Invalid workout start time.');
  if (typeof x.description !== 'string' || x.description.length > 4000) throw new Error('Keep the description under 4,000 characters.');
  return { ...x, name: x.name.trim() };
}
