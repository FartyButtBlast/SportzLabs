-- Production migration blueprint; apply to a fresh Supabase project, then validate RLS.
begin;
create type public.activity_type as enum ('strength','cardio','stretching');
create type public.body_tag as enum ('chest','back','shoulders','biceps','triceps','abs','glutes','quads','hamstrings','calves','cardio');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null check (length(display_name) between 1 and 60),
 created_at timestamptz not null default now()
);
create table public.activities (
 id text primary key, user_id uuid references auth.users(id) on delete cascade,
 name text not null check (length(name) between 1 and 80),
 type public.activity_type not null, tags public.body_tag[] not null check (cardinality(tags)>0),
 default_sets integer not null default 3 check(default_sets between 1 and 30),
 default_reps integer not null default 10 check(default_reps>=0),
 default_weight numeric not null default 0 check(default_weight>=0),
 default_time integer not null default 0 check(default_time>=0),
 default_distance numeric not null default 0 check(default_distance>=0),
 created_at timestamptz not null default now()
);
create table public.workout_templates (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 name text not null check(length(name) between 1 and 60), description text not null default '',
 created_at timestamptz not null default now(), unique(id,user_id)
);
create table public.workout_template_activities (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 template_id uuid not null, activity_id text not null references public.activities(id) on delete cascade,
 position integer not null check(position>=0), sets integer not null check(sets between 1 and 30),
 reps integer not null check(reps>=0), weight numeric not null check(weight>=0),
 time_seconds integer not null check(time_seconds>=0), distance_km numeric not null check(distance_km>=0),
 foreign key(template_id,user_id) references public.workout_templates(id,user_id) on delete cascade,
 unique(template_id,position)
);
create table public.workout_sessions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 template_id uuid references public.workout_templates(id) on delete set null,
 name text not null, started_at timestamptz not null default now(), completed_at timestamptz,
 check(completed_at is null or completed_at>=started_at), unique(id,user_id)
);
create unique index one_active_session_per_user on public.workout_sessions(user_id) where completed_at is null;
create table public.session_activity_logs (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 session_id uuid not null, activity_id text, name text not null, type public.activity_type not null,
 tags public.body_tag[] not null check(cardinality(tags)>0), planned jsonb not null,
 position integer not null check(position>=0),
 -- Snapshot fields intentionally survive edits/deletion of the library entry.
 foreign key(session_id,user_id) references public.workout_sessions(id,user_id) on delete cascade,
 unique(id,user_id), unique(session_id,position)
);
create table public.set_rows (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 log_id uuid not null, position integer not null check(position>=0),
 reps integer not null default 0 check(reps>=0), weight numeric not null default 0 check(weight>=0),
 time_seconds integer not null default 0 check(time_seconds>=0), distance_km numeric not null default 0 check(distance_km>=0),
 done boolean not null default false,
 foreign key(log_id,user_id) references public.session_activity_logs(id,user_id) on delete cascade,
 unique(log_id,position)
);
create index activities_owner on public.activities(user_id);
create index templates_owner on public.workout_templates(user_id);
create index template_activity_owner on public.workout_template_activities(user_id);
create index sessions_owner_date on public.workout_sessions(user_id,completed_at desc);
create index logs_owner on public.session_activity_logs(user_id);
create index rows_owner on public.set_rows(user_id);

alter table public.profiles enable row level security;
alter table public.activities enable row level security;
alter table public.workout_templates enable row level security;
alter table public.workout_template_activities enable row level security;
alter table public.workout_sessions enable row level security;
alter table public.session_activity_logs enable row level security;
alter table public.set_rows enable row level security;
revoke all on public.profiles,public.activities,public.workout_templates,public.workout_template_activities,public.workout_sessions,public.session_activity_logs,public.set_rows from anon,authenticated;
grant select,insert,update,delete on public.profiles,public.activities,public.workout_templates,public.workout_template_activities,public.workout_sessions,public.session_activity_logs,public.set_rows to authenticated;
create policy own_profile on public.profiles for all to authenticated using(id=(select auth.uid())) with check(id=(select auth.uid()));
create policy read_library on public.activities for select to authenticated using(user_id is null or user_id=(select auth.uid()));
create policy create_custom on public.activities for insert to authenticated with check(user_id=(select auth.uid()));
create policy edit_custom on public.activities for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy delete_custom on public.activities for delete to authenticated using(user_id=(select auth.uid()));
create policy own_templates on public.workout_templates for all to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy own_template_activities on public.workout_template_activities for all to authenticated
 using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()) and exists(select 1 from public.activities a where a.id=activity_id and (a.user_id is null or a.user_id=(select auth.uid()))));
create policy own_sessions on public.workout_sessions for all to authenticated
 using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()) and (template_id is null or exists(select 1 from public.workout_templates t where t.id=template_id and t.user_id=(select auth.uid()))));
create policy own_logs on public.session_activity_logs for all to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy own_rows on public.set_rows for all to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
commit;
