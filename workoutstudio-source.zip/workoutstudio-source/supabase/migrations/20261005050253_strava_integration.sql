-- Server-only integration records. No browser role can access these tables.
create table public.workoutstudio_strava_connections (
 user_id uuid primary key references auth.users(id) on delete cascade,
 athlete_id bigint, access_token text, refresh_token text, expires_at bigint,
 oauth_state uuid, state_expires timestamptz, redirect_uri text,
 lock_id uuid, lock_until timestamptz not null default '-infinity',
 updated_at timestamptz not null default now()
);
create table public.workoutstudio_strava_posts (
 user_id uuid not null references auth.users(id) on delete cascade,
 session_id uuid not null,
 status text not null check (status in ('sending','posted','failed','unknown')),
 activity_id bigint,
 created_at timestamptz not null default now(),
 primary key (user_id, session_id)
);
alter table public.workoutstudio_strava_connections enable row level security;
alter table public.workoutstudio_strava_posts enable row level security;
revoke all on public.workoutstudio_strava_connections, public.workoutstudio_strava_posts from public, anon, authenticated;
grant select, insert, update, delete on public.workoutstudio_strava_connections, public.workoutstudio_strava_posts to service_role;
comment on table public.workoutstudio_strava_connections is 'Server-only Strava tokens. Intentionally no client RLS policies; access through authenticated Edge Function only.';
comment on table public.workoutstudio_strava_posts is 'Server-only duplicate-post guard. No client RLS policies by design.';
