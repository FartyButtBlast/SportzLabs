import { cp, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
// Run after pnpm build. Usage: node scripts/build-site.mjs /path/to/SportzLabs
const target=process.argv[2];
if(!target) throw new Error('Provide the SportzLabs checkout directory.');
await mkdir(resolve(target,'workoutstudio'),{recursive:true});
await cp('dist',resolve(target,'workoutstudio'),{recursive:true});
await cp('site',resolve(target),{recursive:true});
await mkdir(resolve(target,'admin'),{recursive:true});
await cp('dist-admin',resolve(target,'admin'),{recursive:true});
console.log('Copied site pages and app build to '+resolve(target));
