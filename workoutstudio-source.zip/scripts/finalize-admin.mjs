import {rename} from 'node:fs/promises';
await rename('dist-admin/admin.html','dist-admin/index.html');
