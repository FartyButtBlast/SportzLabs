-- Pro catalogue configuration. Does not grant users access or create charges.
-- Run after the subscription access tables have been created.
begin;

insert into public.sportzlabs_capabilities(key,name,description,active) values
  ('workouts.progression','Progression suggestions','Suggest next-session targets from training history and configured progression rules. Visible and usable only when included in the user subscription; no locked previews or upgrade prompts.',true),
  ('workouts.insights.advanced','Advanced progress insights','Analyse longer-term performance, training periods, and progress trends. Visible and usable only when included in the user subscription; no locked previews or upgrade prompts.',true)
on conflict(key) do update set name=excluded.name, description=excluded.description, active=excluded.active, updated_at=now();

insert into public.sportzlabs_tiers(id,name,description,is_default,active,sort_order,capability_keys)
select 'pro','Pro','All Free capabilities, plus progression suggestions and advanced progress insights.',false,true,10,
  array(select distinct k from unnest(f.capability_keys || array['workouts.progression','workouts.insights.advanced']) as keys(k) order by k)
from public.sportzlabs_tiers f where f.id='free'
on conflict(id) do update set
  name=excluded.name, description=excluded.description, active=true,
  capability_keys=array(select distinct k from unnest(public.sportzlabs_tiers.capability_keys || excluded.capability_keys) as keys(k) order by k),
  updated_at=now();

commit;
