import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig(({ command, mode }) => ({ plugins: [react()], base: command === "build" && mode !== "native" ? (mode === "admin" ? "/admin/" : "/workoutstudio/") : "/", ...(mode === "admin" ? {build:{outDir:"dist-admin",rollupOptions:{input:"admin.html"}}}: {}) }));
