create table if not exists public.sportzlabs_usage_receipts (
 user_id uuid not null references auth.users(id) on delete cascade,
 event_id text not null check(length(event_id) between 1 and 160),
 created_at timestamptz not null default now(),
 primary key(user_id,event_id)
);
alter table public.sportzlabs_usage_receipts enable row level security;
revoke all on public.sportzlabs_usage_receipts from public,anon,authenticated;
grant all on public.sportzlabs_usage_receipts to service_role;
create or replace function public.sportzlabs_record_usage_once(p_user uuid,p_app text,p_event text,p_id text,p_at timestamptz default now()) returns void language plpgsql set search_path='' as $$
begin
 insert into public.sportzlabs_usage_receipts(user_id,event_id) values(p_user,p_id) on conflict do nothing;
 if found then
  insert into public.sportzlabs_usage(day,user_id,app_id,event) values((least(p_at,now()) at time zone 'UTC')::date,p_user,p_app,p_event)
  on conflict(day,user_id,app_id,event) do update set count=least(public.sportzlabs_usage.count+1,10000);
 end if;
end;$$;
revoke all on function public.sportzlabs_record_usage_once(uuid,text,text,text,timestamptz) from public,anon,authenticated;
grant execute on function public.sportzlabs_record_usage_once(uuid,text,text,text,timestamptz) to service_role;
