# Strava integration

Server: Supabase project `npllwuavofpfudchotma`, Edge Function `strava`.
Frontend: https://www.sportzlabs.com/workoutstudio/

## One-time activation

1. Sign in at https://www.strava.com/settings/api and create or select a Strava API application for Workout Studio.
2. Use website `https://www.sportzlabs.com/workoutstudio/` and Authorization Callback Domain `www.sportzlabs.com` (no protocol or path). Review Strava's API terms yourself before accepting.
3. In Supabase > Edge Functions > Secrets, add `STRAVA_CLIENT_ID` and `STRAVA_CLIENT_SECRET`. Never put the client secret, service-role key or access tokens in Vite variables, this repository, or chat.
4. Open Workout Studio, sign in, and choose Account > Connect with Strava. Approve activity upload permission personally.
5. Newly completed real sessions upload automatically when connected and automatic sharing is enabled. Turn it off in Account to use manual review instead. Open the returned Strava link and verify it. No real activity has been posted during implementation testing.

New Strava API applications may be restricted to their owner's athlete account until Strava approves broader access. Confirm current capacity in the Strava dashboard before offering the connection to other users.

## Design

The Edge Function authenticates every action with `supabase.auth.getUser(bearerToken)`. Gateway `verify_jwt=false` is intentional: user authentication is performed in the handler, compatible with current Supabase signing keys. There is no unauthenticated OAuth callback endpoint. The browser returns the OAuth code/state while signed into Workout Studio; a single-use 10-minute state binds it to the user.

The two integration tables have RLS enabled and all grants revoked from anon/authenticated/public. Only server service_role can access tokens and posting records. The no-policy advisor notices are intentional default-deny behavior. The frontend only receives connection status and activity IDs.

A per-user atomic lease serializes OAuth exchange, refresh, disconnect and posting. Refresh-token rotations are saved before uploading. A unique `(user_id, session_id)` record prevents repeated uploads. Ambiguous network/server failures remain blocked to avoid duplicates; support should verify the athlete's feed before manually reconciling that record. Do not blindly retry unknown/sending records.

The app sends a structured JSON upload for matched exercises in WeightTraining/Workout sessions, so Strava can generate its workout log and muscle map. Sessions without matched exercises use a FIT activity when heart-rate samples are shared, or a manual activity otherwise. No GPS route is sent. It requests `activity:write`, generates descriptions and structured sets from checked rows only, and automatically sends newly completed workouts when enabled. Manual sharing retains field review/editing. With heart-rate sharing enabled, recorded timestamped samples are uploaded for Strava charts and averages/peaks are included in the description. No temperature is uploaded. Strava account settings determine activity visibility. Disconnect revokes the grant and removes local server tokens; it does not delete posted activities or the minimal duplicate-protection records.

## Validation

Run `pnpm test` and `pnpm build`. Deploy the migration with the Supabase migration tool, then deploy `supabase/functions/strava/index.ts` with its `payload.ts`, `strength.ts`, and `upload.ts` dependencies. Test unauthenticated requests (401), invalid origin (403), denied client table access, and signed-in connection status. OAuth exchange and actual posting require the owner's credentials and explicit athlete consent.

References: https://developers.strava.com/docs/authentication/ and https://developers.strava.com/docs/reference/#api-Activities-createActivity

## Deployment verification, 5 October 2026

- GitHub Pages homepage publication: `f072e36c46b8dd75700214e1281ae5cedd258f7c`.
- App entry page publication: `1c4c8e21f4d6e6f1785ddf024251450949f7b482`.
- GitHub connector could not write and local Git had no saved credentials. Publication used the owner's existing GitHub browser session. The deployed app entry points to hash-named `workoutstudio-index-*` assets at the site root; regular builds can use the standard `/workoutstudio/assets/` structure instead.
- 14 automated tests passed; production build succeeded. Live homepage and app returned HTTP 200; app console had no errors. User credential sign-in and Strava authorization/posting still require the owner's participation.
- Strava Edge Function returned 401 without valid user authentication and 403 for a foreign Origin. Public-key table reads were denied (401).
- Database advisors reported intentional default-deny RLS notices on the two integration tables, plus pre-existing warnings for `rls_auto_enable()` grants and disabled leaked-password protection. No existing auth protection or unrelated database object was changed. Advisor references: https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy and https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection

## Automatic upload queue

A completion creates a per-account job when automatic sharing is enabled, even if connection status has not loaded. Disconnected jobs wait and resume when connected. Jobs are included in the existing cloud-synced session record. The app attempts it immediately and retries online while open, with bounded backoff (five attempts). Before every POST it reconciles server status. Posted and ambiguous results block duplicates. Older history and sample sessions are never queued automatically. Leaving the app closed can delay an upload; this is not a server background queue. Disabling automatic sharing cancels unsent jobs; uploads already accepted by Strava continue to be reconciled. Settings are per installation.

## Structured strength uploads — 6 October 2026

Completed, matched exercises are uploaded through `/api/v3/uploads` with `data_type=json`, documented by Strava at https://developers.strava.com/docs/uploads/. Workout Studio sends exercise identifiers, per-set repetitions/weight or duration, start time, UTC offset and elapsed time. It does not send its body-map image, arbitrary muscle tags, fabricated per-set timestamps or raw heart-rate/temperature streams. Strava generates its own muscle map; its rendering may differ.

Built-in strength exercises have mappings in `supabase/functions/strava/strength.ts`. Custom activities can select **Strava exercise match** in the activity editor; this is snapshotted when starting a new session. Unknown movements remain description-only and are listed in the sharing panel. Strava may not draw a map for unmapped/general movements. An existing posted activity is never automatically re-uploaded.

The server stores Strava's `id_str` as text in `workoutstudio_strava_posts.upload_id`, then polls the existing upload using the authenticated `reconcile` action. A sending record with an ID is never reposted. Polling continues while the app is open, even if automatic sharing is switched off after submission. Unknown outcomes remain blocked. If Strava confirms that it rejected the JSON file (HTTP 400/403/415/422, excluding duplicate errors), the server attempts a manual summary. It never falls back after an uncertain response, timeout, rate limit or authentication failure. Actual JSON acceptance and muscle-map rendering require validation on the next real completed workout.

## Mixed sessions and older browser tabs — 6 October 2026

Sessions with any completed strength exercise use WeightTraining even when they also include stretches. The server can recover recognized sets from older clients' exact generated descriptions. Unknown movements are never inferred from muscle tags. Existing posted activities are not reposted. Upload IDs are retained even when Strava completes processing immediately. Built-in strength identifiers were rechecked against the current Strava documentation; Book Opener now matches THORACIC_ROTATION. Thoracic Extension has no exact mapping in the current list and remains description-only unless the user selects an appropriate equivalent.

## iPhone reconnect, history and administration — 7 October 2026

Build 6 adds a native ASWebAuthenticationSession plugin. The registered callback is `workoutstudio://www.sportzlabs.com/strava/callback`; both native code and the server validate the exact destination and OAuth state. The Strava client callback domain remains `www.sportzlabs.com`. Website popup callbacks validate origin, popup identity and state; token exchange always uses the original signed-in user. The public cloud site origin is allowed by both Edge Functions.

`catalog.ts` records the current 656 Strava movement codes in 34 categories and all 56 sport types. Measurement defaults are Workout Studio suggestions and can be changed for custom exercises. Existing historical logs retain their original interpretation. New logs snapshot identifiers, categories, metric mode, explicit kg/km/seconds units, UTC offset, prior-session/set provenance and checked-set completion times. A new session uses completed values from the same workout first, then the most recent compatible exercise; it retains the planned set count and fills additional rows from the last completed set. Samples, other users and future/unfinished sessions are excluded. No completion flags/timestamps are copied.

Admin Usage consumes the existing usage report, now including Strava connection and upload outcomes, queue/retry states, discarded workouts, custom exercise saves and reuse of previous values. Client events are persisted in a per-user outbox. `sportzlabs_record_usage_once` and the service-only RLS-protected receipt table deduplicate retries. Workout contents and sensor samples stay in the authenticated workout store; they are not sent to aggregate usage reporting. This prepares detailed records for future analytics without building new workout analysis screens.

Validation: 60 automated tests pass. Browser flow verified 12 reps at 47.5 kg copied into a new unchecked session. Session layout checked at 320/375/390/430 CSS pixels with 16px input text. The Swift plugin compiled in a signed iPhone release archive; build 6 uploaded to Apple. A physical-iPhone OAuth and real Strava post still need validation after installing the new build. No synthetic workout was sent to the owner's Strava account. The existing failed activity was preserved for retry from its history screen.


## Rejection diagnostics — 8 October 2026

Strava Edge Function version 10 retains bounded provider error, message, status and field/code diagnostics on each server-only post row. Structured-file and summary errors are separate, so a successful fallback does not hide the original file rejection. Request payloads, credentials and headers are excluded. Existing RLS and denied client grants remain in force. Schema addition: `supabase/strava-upload-diagnostics.sql`, applied as `strava_upload_rejection_diagnostics`.

The initial rejection reason was not retained by earlier versions. Root cause remains unconfirmed pending a real retry; matching the documented JSON schema is not proof of Strava acceptance. HTTP-success responses with a terminal processing error use the summary fallback. Asynchronous rejections retain their upload ID so the next share sends a summary without resubmitting the rejected file. Duplicate and unknown outcomes remain blocked. 67 automated tests pass.


## Session feedback release — 19 October 2026

The report now starts with https://sportzlabs.com. Heart-rate sharing sends elapsed-second and bpm arrays in the documented JSON `streams` format. FIT fallbacks include timestamped `record` messages with `heart_rate`; workouts without mapped strength sets use FIT directly. Readings are sorted, deduplicated to one real observation per second, and restricted to the completed session. Only integer 1–254 bpm readings are exported (the FIT field range); no gaps are filled, and sensor names, exercise assignment and temperature are excluded. The existing per-installation opt-in remains off by default.

Heart-rate files that are definitively rejected remain failed/retryable instead of silently posting a chartless summary. Duplicate protection and ambiguous-outcome blocking remain unchanged. Already posted activities are not automatically replaced or reposted. Actual chart rendering still needs confirmation on a real athlete upload; isolated tests do not post activities.

Strava format reference: https://developers.strava.com/docs/uploads/ (JSON Streams and FIT Record sections). No database migration, record transformation or authentication/configuration change is required. The prior Edge Function source is retained in `artifacts/session-feedback/backend-before-v13/`.
