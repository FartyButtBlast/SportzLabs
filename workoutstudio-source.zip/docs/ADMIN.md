# SportzLabs administration

Entry: https://www.sportzlabs.com/admin/ (the apex domain redirects to www).

The admin site uses the existing Supabase project `npllwuavofpfudchotma`. The platform owner is `derek@sportzlabs.com`. The server requires a verified, non-anonymous Supabase email identity; typing that email or changing user metadata never grants access. The owner may sign in with an email link even without a password. The email flow permits first-time registration only for the default owner in this UI. Additional administrator UUIDs can be provisioned by a trusted database operator in `sportzlabs_admins`; no client may edit that table. The owner email rule does not depend on that table and cannot be removed from this UI.

## Capabilities

- Application registry: name, HTTPS address, description and live/planned status. Adding an app registers its details; it does not deploy code or automatically instrument it.
- Users: every shared Supabase Auth account, paginated 50 at a time. Search currently filters the displayed page. No account deletion, passwords or private workout data are exposed.
- Access: server-managed capability catalogue, configurable tiers, and standalone add-ons. The seeded Free tier retains current core workouts, activity library, workout history, Bluetooth sensor, and Strava features. Admins can assign a tier and add-ons to each user from the Users section. Users do not yet see this in account settings, app features are not yet gated by entitlements, and no payment or checkout processing is included. New capabilities can be added to the catalogue and assigned to tiers/add-ons without changing the entitlement schema.
- Exercises: add or update central exercises, instructions, body tags, target values and Strava mappings. New/changed values overlay built-in IDs. Workout Studio refreshes on opening/focus and caches the catalogue for offline use. Existing saved session snapshots and existing template targets are preserved. Existing native app installations need an updated build to receive this client feature.
- Integrations: owner-only settings for Strava and a registry for future providers. Non-Strava entries require an implemented connector; registering credentials alone does not enable an integration.
- Usage: authenticated Workout Studio page navigation, editor/device openings, and workout starts/completions. UTC daily aggregates and a rolling 30-day report. No historical events, health readings, workout contents or query strings are collected. Offline events can be missed. Records are linked to account UUIDs; this is not anonymous analytics. Counts are capped at 10,000 per user/event/day.
- Audit list: last 20 catalogue, app and integration changes, without secrets.

## Credentials and Strava

`platform-admin` and `strava` use server-only Supabase service credentials. Admin tables have RLS and all client grants revoked. Only explicitly authenticated Edge Function handlers access them. Secrets are not returned to clients or logged. They are stored in the server-only integration table, using the project's underlying storage protection, not application-level encryption. Blank secret fields preserve the prior saved value. Until a complete central credential pair is saved, Strava continues using existing `STRAVA_CLIENT_ID` and `STRAVA_CLIENT_SECRET` environment secrets. Disabling Strava stops new connections and uploads; existing users may disconnect, and accepted uploads can still be reconciled.

Avoid changing Strava application identity without planning reconnection for existing users. Each athlete still authorises their own Strava account. Adding configuration does not grant administrator access to athlete accounts.

## Build and deployment

Run `pnpm test`, `pnpm build`, and `pnpm build:admin`. Outputs are `dist/` (Workout Studio) and `dist-admin/` (admin). `scripts/build-site.mjs` now expects both builds. The live site is GitHub Pages, not a separate ChatGPT Sites deployment. Preserve the live site's existing pages when copying builds. Admin entry points are noindex.

The initial server schema is recorded in `supabase/admin-schema.sql` and applied remotely as `sportzlabs_platform_administration`. Do not reapply this non-idempotent initialization. New access tables are added by `supabase/migrations/202610090001_subscription_access_admin.sql`; apply this migration before deploying the updated admin site or Edge Function. Deploy the `platform-admin` function with `policy.ts`, and `strava` with its existing dependencies. Both have gateway JWT verification disabled because their handlers validate bearer tokens with `auth.getUser`, then enforce their own authorization. Admin handlers require confirmed email. The new capability, tier, add-on, and per-user access records remain server-only and have no direct client grants.

Exact redirect URLs configured: `https://www.sportzlabs.com/admin/`, `https://sportzlabs.com/admin/`, and `http://127.0.0.1:5173/admin.html`. Existing Workout Studio URLs are preserved. Custom SMTP was already enabled through Resend. Real mailbox receipt and owner sign-in require the owner to complete the email flow.

A future `admin.sportzlabs.com` deployment needs hosting/DNS setup, a matching build base, exact Supabase redirect allowlisting and Edge Function CORS entries. No DNS changes are part of this release.

## Verification

54 automated tests pass, including owner verification, metadata spoofing, exercise validation, event allowlists and URL validation. Both production builds and TypeScript checks pass. Live API returns 401 for absent/invalid sessions, 403 for an unapproved origin, and denies direct public-key reads of integration secrets. Database grants deny authenticated clients the tables and usage-report function. Existing security advisor warnings for `rls_auto_enable()` and leaked-password protection predate this work. The new server-only tables intentionally have no client RLS policies ([advisor explanation](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy)).

Passwordless flow follows [Supabase email sign-in](https://supabase.com/docs/guides/auth/auth-email-passwordless). Email delivery and authenticated administrator end-to-end changes remain dependent on the owner's sign-in; automated validation does not assert those occurred.

## Publication, 7 October 2026

The built admin application and updated Workout Studio are published through the existing GitHub browser session. Admin entry commit: `0f4ed63e7e735791f03f1695fa3595ed43310c2c`. The live `/admin/` and `/workoutstudio/` pages return HTTP 200 and reference `admin-CNS2fpxk.js` and `index-C8aokoob.js` respectively. The live admin login has no browser console errors. The local isolated UI fixture verified a saved exercise description and search; it never contacted live services. A transactional service-role database test verified the usage counter and report, then rolled back all test events.

The refreshed source archive remains local: automatic approval review rejected publicly uploading source/tests/documentation. The public source archive was not replaced. The existing dirty `artifacts/sportzlabs-site` checkout was not changed by this release; `artifacts/admin-deployment` contains an unpushed local build commit, while publication used browser uploads with root-level hash-named assets.

The application directory includes the verified live AFL Performance app at `https://aflperformance.sportzlabs.com/`. Its registry entry does not imply its separate runtime/authentication is integrated; usage reporting currently covers Workout Studio.
