# Heart rate on iPhone and Android

The shared app now has native iOS and Android projects plus a Web Bluetooth fallback. Native projects are prepared, not signed, distributed or verified with physical sensors. A successful web build or `cap sync` does not prove a native device build.

## Using a sensor

1. Start a workout, wear/wake the Wahoo Bluetooth chest strap, and select **Connect heart rate** in the live sensor panel. Pair inside Workout Studio, not the phone's Bluetooth settings. Close another app if it has occupied the sensor's available connections.
2. For a Garmin fēnix, enable **Broadcast Heart Rate** on the watch. Its particular model/firmware must support Bluetooth heart-rate broadcasting; ANT+ alone is insufficient. A Garmin Connect pairing does not expose a live heart-rate feed to this app.
3. Choose **Track this exercise** on the current exercise, or choose the exercise in the sensor panel. Select **Rest / unassigned** between exercises. This is explicit selection, not automatic exercise recognition.
4. Keep the app visible and the screen awake. Screen lock, backgrounding and disconnects may interrupt recording. Stale values are marked and missing readings are never invented.
5. Finish the workout. Recorded samples are saved with timestamps and exercise IDs. History shows sampled average and peak heart rate for each exercise and rest.

Heart-rate observations are stored at most once every five seconds, plus the first observation after an exercise change. The live readout updates as notifications arrive. Summary averages are sample averages, not time-weighted clinical measurements. Only one heart-rate source is selected at a time.

## Platform support

- **Android Chrome:** Bluetooth can work directly on the HTTPS website with a compatible BLE sensor.
- **iPhone:** Use the installed native app. Safari or adding the website to the Home Screen does not provide this Bluetooth interface.
- **Native Android:** Uses the same screen and Capacitor BLE bridge. Nearby-device permission is required; older Android versions may request location permission for BLE scans. The app does not use sensor scans to derive location.
- **Garmin temperature:** No live Garmin watch-temperature integration is implemented. Heart-rate broadcasting does not include temperature. A separate device exposing the standard Bluetooth Health Thermometer service can be selected in the optional temperature section. Environmental, wrist/skin and core temperature are not interchangeable. No temperature is sent to Strava.

Workouts, sensor observations and upload jobs stay in this browser/app's local storage, per account. They do not sync between phones or between the browser and native app. Sign-in identity and the Strava connection are shared through Supabase. Clearing app data removes locally stored sessions and pending jobs.

## Native build and installation

Prerequisites: Node 22+, pnpm, Xcode with iOS SDK on macOS for iPhone, Android Studio/SDK and the JDK required by the generated Android Gradle project. Open each native project to resolve SDK dependencies. This machine does not currently have the full IDEs installed in their usual Applications locations.

1. Set the **public** Supabase build configuration in `.env.local` using `.env.example`. Never include service-role keys or Strava secrets in a mobile bundle.
2. `pnpm install --frozen-lockfile`
3. `pnpm native:sync` builds the native web bundle and updates both native projects.
4. iPhone: `pnpm native:ios`; select an Apple development team in Xcode, connect a physical iPhone, choose it as the target, then build/run. BLE is unavailable in the iOS simulator. TestFlight distribution requires the owner's Apple Developer setup and signing.
5. Android: `pnpm native:android`; select a physical Android device and build/run. Release distribution requires the owner's signing key and Play Console/distribution setup. Keep signing credentials outside source control.
6. Sign in to the same Workout Studio account. For Strava, use the native app's **Open the website to connect Strava** link, sign in there with the same account, authorize, then return to the app. Use Account to confirm Connected before completing a workout. Email verification/password recovery also use the production website.

The app ID is `com.sportzlabs.workoutstudio`. iOS Bluetooth purpose text and Android scan permission declarations are included. Android application backup is disabled. There is no background BLE service or background upload guarantee in this first version.

## Device acceptance checklist

On both physical phones: authorize Bluetooth, select the Wahoo strap, confirm plausible changing readings, switch exercises/rest, interrupt/reconnect the sensor, lock/resume, finish and reload history. Check denied permissions, cancelled selection, Bluetooth disabled and storage failure. Repeat Garmin broadcast testing on the exact fēnix model before advertising it as verified.

For Strava, use a consenting owner's real completed activity; confirm one post on completion, correct checked sets, optional HR description, offline resume while open, disabled sharing and no duplicate after repeated finish/reload. No real athlete activity was uploaded during automated tests.

References:
- https://github.com/capacitor-community/bluetooth-le
- https://developer.chrome.com/docs/capabilities/bluetooth
- https://support.wahoofitness.com/hc/en-us/articles/115000320290-Wahoo-TICKR-Product-Instructions
- https://www8.garmin.com/manuals/webhelp/GUID-EECCAC99-90D6-4AB1-9A3A-EC433D3365E2/EN-GB/GUID-4CDC9B32-5295-4495-9610-9EEC02FA1DDB.html
