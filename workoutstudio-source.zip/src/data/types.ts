import type { UploadState } from "../services/stravaSync";
export const TAGS = [
  "chest",
  "back",
  "shoulders",
  "biceps",
  "triceps",
  "abs",
  "glutes",
  "quads",
  "hamstrings",
  "calves",
  "cardio",
] as const;
export type Tag = (typeof TAGS)[number];
export type ActivityType = "strength" | "cardio" | "stretching";
export interface Targets {
  sets: number;
  reps: number;
  weight: number;
  time: number;
  distance: number;
}
export type MetricMode = "reps_weight" | "time_weight" | "time_distance" | "time_reps";
export interface Activity {
  metricMode?: MetricMode;
  stravaSportType?: string;
  stravaCategory?: string;
  description?: string;
  stravaExerciseType?: string;
  id: string;
  userId: string | null;
  name: string;
  type: ActivityType;
  tags: Tag[];
  defaults: Targets;
}
export interface TemplateActivity {
  id: string;
  activityId: string;
  targets: Targets;
  progression?: { minReps: number; maxReps: number; increment: number };
  useTargetsNextSession?: boolean;
  progressionPreviousTargets?: Targets;
}
export interface Template {
  id: string;
  userId: string;
  name: string;
  description: string;
  activities: TemplateActivity[];
  createdAt: string;
}
export interface SetRow {
  id: string;
  reps: number;
  weight: number;
  time: number;
  distance: number;
  done: boolean;
  completedAt?: string;
  previousSetId?: string;
}
export interface ActivityLog {
  metricMode?: MetricMode;
  stravaSportType?: string;
  stravaCategory?: string;
  previousSessionId?: string;
  stravaExerciseType?: string;
  id: string;
  activityId: string;
  name: string;
  type: ActivityType;
  tags: Tag[];
  planned: Targets;
  rows: SetRow[];
}
export interface Session {
  addedDuringSession?: boolean;
  schemaVersion?: 2;
  units?: {weight: "kg"; distance: "km"; time: "s"};
  utcOffsetSeconds?: number;
  id: string;
  userId: string;
  templateId: string;
  name: string;
  startedAt: string;
  completedAt: string | null;
  activities: ActivityLog[];
  sample?: boolean;
  sensorSamples?: SensorSample[];
  trackingExerciseId?: string | null;
  stravaUpload?: UploadState;
}
export interface UserData {
  version: 1;
  templates: Template[];
  customActivities: Activity[];
  sessions: Session[];
  activeSession: Session | null;
}
export interface Profile {
  id: string;
  name: string;
  email: string;
  verified: boolean;
}
export const uid = () => crypto.randomUUID();
export const labels: Record<ActivityType, string> = {
  strength: "Weight lifting",
  cardio: "Cardio",
  stretching: "Stretching",
};

export interface SensorSample {
  at: number;
  exerciseId: string | null;
  heartRate?: number;
  temperatureC?: number;
  temperatureLocation?: string;
  source: string;
}
