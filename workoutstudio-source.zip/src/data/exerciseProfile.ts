import type {Activity, ActivityLog, ActivityType, MetricMode, Tag} from './types';
import {exerciseCatalog, sportTypes} from '../../supabase/functions/strava/catalog';
import {exerciseCode} from '../../supabase/functions/strava/strength';
export const metricLabels:Record<MetricMode,string>={reps_weight:'Repetitions + weight',time_weight:'Time + weight',time_distance:'Time + distance',time_reps:'Time + repetitions'};
// Strava accepts optional repetitions, kilograms and seconds. These are editable
// Workout Studio input defaults, not an assertion that Strava mandates a metric.
export function suggestedMetrics(code:string,category:string):MetricMode {
 if(category==='Cardio')return 'time_distance';
 if(category==='Warm Up')return 'time_reps';
 if(category==='Carry'||/HOLD|PLANK_GENERIC|^SIDE_PLANK$|WALL_SIT|DEAD_HANG/.test(code))return 'time_weight';
 return 'reps_weight';
}
export const metricKeys=(mode:MetricMode):['reps'|'time','weight'|'distance'|'reps']=>mode==='reps_weight'?['reps','weight']:mode==='time_weight'?['time','weight']:mode==='time_distance'?['time','distance']:['time','reps'];
export const metricMode=(a:Pick<ActivityLog,'type'|'metricMode'>):MetricMode=>a.metricMode||(a.type==='strength'?'reps_weight':a.type==='cardio'?'time_distance':'time_reps');
const sportByName:Record<string,string>={'Stationary Bike':'Ride','Rowing':'Rowing','Treadmill Run':'Run','Outdoor Run':'Run','Walking':'Walk','Elliptical':'Elliptical','Stair Climber':'StairStepper','Swimming':'Swim','Assault Bike':'Workout','Jump Rope':'Workout'};
export function exerciseProfile(a:Activity):Activity {
 const code=a.stravaExerciseType|| (a.type==='cardio'&&['Swimming','Walking','Stationary Bike','Elliptical'].includes(a.name)?'CUSTOM':exerciseCode(a.name));
 const entry=exerciseCatalog.find(e=>e.code===code);
 const suggested=a.type==='cardio'?'time_distance':entry?suggestedMetrics(entry.code,entry.category):metricMode(a);
 return {...a,defaults:suggested==='time_weight'&&!a.metricMode?{...a.defaults,time:a.defaults.time||30,weight:0}:a.defaults,stravaExerciseType:code,stravaCategory:a.stravaCategory||entry?.category,
 stravaSportType:a.stravaSportType||sportByName[a.name]||(a.type==='strength'?'WeightTraining':'Workout'),
 metricMode:a.metricMode||suggested};
}
export function categoryTags(category:string):Tag[]{
 if(['Bench Press','Flye','Push Up'].includes(category))return ['chest','triceps'];
 if(['Row','Pull Up'].includes(category))return ['back','biceps'];
 if(['Squat','Lunge','Quad Extension'].includes(category))return ['quads','glutes'];
 if(['Deadlift','Leg Curl','Hip Swing'].includes(category))return ['hamstrings','glutes'];
 if(category==='Curl')return ['biceps'];
 if(category==='Triceps Extension')return ['triceps'];
 if(/Shoulder|Lateral|Shrug/.test(category))return ['shoulders'];
 if(/Hip/.test(category))return ['glutes'];
 if(/Calf|Lower Leg/.test(category))return ['calves'];
 if(['Core','Plank','Sit Up','Chop','Leg Raise'].includes(category))return ['abs'];
 return ['cardio'];
}
export function catalogActivities(existing:Activity[]):Activity[]{
 const known=new Set(existing.map(a=>exerciseCode(a.name,a.stravaExerciseType)).filter(Boolean));
 return exerciseCatalog.filter(e=>!known.has(e.code)).map(e=>{
  const type:ActivityType=e.category==='Cardio'?'cardio':e.category==='Warm Up'?'stretching':'strength';
  const mode=suggestedMetrics(e.code,e.category);
  return {id:`strava-${e.code.toLowerCase()}`,userId:null,name:e.name.replace(/ Generic$/,''),type,tags:categoryTags(e.category),stravaExerciseType:e.code,stravaCategory:e.category,stravaSportType:type==='strength'?'WeightTraining':'Workout',metricMode:mode,defaults:{sets:type==='cardio'?1:3,reps:mode==='reps_weight'?10:0,weight:0,time:mode==='reps_weight'?0:30,distance:0}};
 });
}
export function sportActivities(existing:Activity[]):Activity[]{
 const names=new Set(existing.map(a=>a.name.toLowerCase()));
 return sportTypes.map(code=>({code,name:code.replace(/([a-z])([A-Z])/g,'$1 $2')})).filter(e=>!names.has(e.name.toLowerCase())).map(e=>({id:`sport-${e.code.toLowerCase()}`,userId:null,name:e.name,type:'cardio',tags:['cardio'],stravaExerciseType:'CUSTOM',stravaSportType:e.code,metricMode:'time_distance',defaults:{sets:1,reps:0,weight:0,time:1200,distance:0}}));
}
