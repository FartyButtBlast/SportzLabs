import type { SensorSample } from '../data/types';
export function parseHeartRate(value:DataView):number|null {
 if(value.byteLength<2)return null;
 const flags=value.getUint8(0);
 if((flags&4)&&!(flags&2))return null; // Supported sensor contact, but no skin contact.
 if((flags&1)&&value.byteLength<3)return null;
 const bpm=(flags&1)?value.getUint16(1,true):value.getUint8(1);
 return bpm>0&&bpm<=300?bpm:null;
}
const locations:Record<number,string>={1:'Armpit',2:'Body (general)',3:'Ear',4:'Finger',5:'Gastrointestinal tract',6:'Mouth',7:'Rectum',8:'Toe',9:'Ear drum'};
export function parseTemperature(value:DataView):{celsius:number;location:string}|null{
 if(value.byteLength<5)return null;
 const flags=value.getUint8(0), offset=5+((flags&2)?7:0);
 if(value.byteLength<offset+((flags&4)?1:0))return null;
 const raw=value.getUint8(1)|(value.getUint8(2)<<8)|(value.getUint8(3)<<16);
 if([0x7ffffe,0x7fffff,0x800000,0x800001,0x800002].includes(raw))return null;
 const mantissa=raw&0x800000?raw-0x1000000:raw;
 let celsius=mantissa*10**value.getInt8(4);
 if(flags&1)celsius=(celsius-32)*5/9;
 if(!Number.isFinite(celsius)||celsius < -50||celsius > 100)return null;
 return {celsius:Math.round(celsius*100)/100,location:(flags&4)?locations[value.getUint8(offset)]||'Unspecified':'Unspecified'};
}
export function sensorSummary(samples:SensorSample[],exerciseId?:string|null){
 const selected=exerciseId===undefined?samples:samples.filter(s=>s.exerciseId===exerciseId);
 const hr=selected.flatMap(s=>s.heartRate===undefined?[]:[s.heartRate]);
 const temp=selected.flatMap(s=>s.temperatureC===undefined?[]:[s.temperatureC]);
 return {count:hr.length,average:hr.length?Math.round(hr.reduce((a,b)=>a+b,0)/hr.length):null,max:hr.length?Math.max(...hr):null,min:hr.length?Math.min(...hr):null,temperatureAverage:temp.length?Math.round(temp.reduce((a,b)=>a+b,0)/temp.length*10)/10:null,temperatureCount:temp.length};
}
export function appendSensorSample(samples:SensorSample[],sample:SensorSample){
 const kind=sample.heartRate===undefined?'temperatureC':'heartRate';
 const last=[...samples].reverse().find(s=>s[kind]!==undefined);
 // Keep one observation every 5 seconds, plus the first observation after an exercise switch.
 if(last&&last.exerciseId===sample.exerciseId&&sample.at-last.at<5000)return samples;
 if(samples.length>=21600)throw new Error('Sensor recording limit reached. Existing readings are saved; finish this session before recording more.');
 return [...samples,sample];
}
