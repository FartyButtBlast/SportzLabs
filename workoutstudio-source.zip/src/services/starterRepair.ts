import { seedData } from "../data/seed";
import type { Template, UserData } from "../data/types";

const shape = (t: Template) => JSON.stringify([t.name, t.description,
  t.activities.map(a => [a.activityId, a.targets.sets, a.targets.reps, a.targets.weight, a.targets.time, a.targets.distance])]);

/** Old installations generated complete starter batches on every first sign-in.
 * Only remove unchanged, complete batches created together; edited workouts and
 * individually duplicated templates are deliberately left alone. */
export function repairStarterBatches(data: UserData): UserData {
  const defaults = seedData("repair").templates.map(shape);
  const batches: Template[][] = [];
  for (const template of data.templates) {
    if (!defaults.includes(shape(template))) continue;
    let batch = batches.find(b => b[0].userId === template.userId &&
      Math.abs(Date.parse(b[0].createdAt) - Date.parse(template.createdAt)) <= 100 &&
      !b.some(t => shape(t) === shape(template)));
    if (!batch) batches.push(batch = []);
    batch.push(template);
  }
  const complete = batches.filter(b => b.length === defaults.length)
    .sort((a, b) => a[0].createdAt.localeCompare(b[0].createdAt));
  const canonical = new Map<string, Template[]>();
  const replacements = new Map<string, string>();
  for (const batch of complete) {
    const first = canonical.get(batch[0].userId);
    if (!first) { canonical.set(batch[0].userId, batch); continue; }
    for (const t of batch) replacements.set(t.id, first.find(k => shape(k) === shape(t))!.id);
  }
  if (!replacements.size) return data;
  return { ...data,
    templates: data.templates.filter(t => !replacements.has(t.id)),
    sessions: data.sessions.map(s => ({ ...s, templateId: replacements.get(s.templateId) || s.templateId })),
    activeSession: data.activeSession ? { ...data.activeSession,
      templateId: replacements.get(data.activeSession.templateId) || data.activeSession.templateId } : null,
  };
}
