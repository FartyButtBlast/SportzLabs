import { useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { BleClient } from '@capacitor-community/bluetooth-le';
import type { SensorSample } from '../data/types';
import { parseHeartRate, parseTemperature } from './sensors';
const UUID=(short:string)=>`0000${short}-0000-1000-8000-00805f9b34fb`;
const HR=UUID('180d'), HR_VALUE=UUID('2a37'), HT=UUID('1809'), TEMP=UUID('2a1c');
type Kind='heartRate'|'temperature';
export type SensorConnection={status:'idle'|'connecting'|'connected'|'disconnected';name:string;error?:string};
export function useSensors(sessionId:string|undefined,onSample:(sample:Omit<SensorSample,'exerciseId'>)=>boolean){
 const supported=Capacitor.isNativePlatform()||Boolean((navigator as Navigator&{bluetooth?:unknown}).bluetooth)&&window.isSecureContext;
 const [heart,setHeart]=useState<SensorConnection>({status:'idle',name:''});
 const [temperature,setTemperature]=useState<SensorConnection>({status:'idle',name:''});
 const [latest,setLatest]=useState<{hr?:{value:number;at:number};temp?:{value:number;at:number;location:string}}>({});
 const devices=useRef<Partial<Record<Kind,{id:string;service:string;characteristic:string}>>>({});
 const pending=useRef(new Set<Kind>());
 const generation=useRef(0);
 const sink=useRef(onSample);sink.current=onSample;
 const active=useRef(sessionId);active.current=sessionId;
 const disconnect=async(kind:Kind)=>{
  const d=devices.current[kind];delete devices.current[kind];
  if(d){try{await BleClient.stopNotifications(d.id,d.service,d.characteristic);}catch{}try{await BleClient.disconnect(d.id);}catch{}}
  (kind==='heartRate'?setHeart:setTemperature)({status:'idle',name:''});
  setLatest(v=>({...v,[kind==='heartRate'?'hr':'temp']:undefined}));
 };
 useEffect(()=>{
  generation.current++;setLatest({});
  return()=>{generation.current++;for(const kind of ['heartRate','temperature'] as Kind[])void disconnect(kind);};
 },[sessionId]);
 async function connect(kind:Kind){
  if(!supported||!active.current||pending.current.has(kind))return;
  pending.current.add(kind);
  const thisGeneration=generation.current;
  const state=kind==='heartRate'?setHeart:setTemperature;
  let id:string|undefined;
  try{
   state({status:'connecting',name:''});
   await BleClient.initialize({androidNeverForLocation:true});
   const service=kind==='heartRate'?HR:HT, characteristic=kind==='heartRate'?HR_VALUE:TEMP;
   const device=await BleClient.requestDevice({services:[service]});id=device.deviceId;
   if(thisGeneration!==generation.current||!active.current)return;
   if(Object.values(devices.current).some(d=>d?.id===id))throw new Error('This sensor is already connected. Use a separate temperature sensor.');
   const name=device.name|| (kind==='heartRate'?'Heart-rate sensor':'Temperature sensor');
   await BleClient.connect(id,()=>{
    if(thisGeneration===generation.current){delete devices.current[kind];state({status:'disconnected',name,error:'Connection lost. Move closer and reconnect. Gaps will not be filled with estimated readings.'});setLatest(v=>({...v,[kind==='heartRate'?'hr':'temp']:undefined}));}
   });
   if(thisGeneration!==generation.current){await BleClient.disconnect(id);return;}
   devices.current[kind]={id,service,characteristic};
   await BleClient.startNotifications(id,service,characteristic,(value:DataView)=>{
    if(thisGeneration!==generation.current||!active.current)return;
    const at=Date.now();
    if(kind==='heartRate'){
     const bpm=parseHeartRate(value);if(bpm===null){setLatest(v=>({...v,hr:undefined}));return;}
     setLatest(v=>({...v,hr:{value:bpm,at}}));
     if(!sink.current({at,heartRate:bpm,source:name})){state({status:'connected',name,error:'Reading live, but could not save sensor data. Free browser storage or finish your session.'});}
    }else{
     const t=parseTemperature(value);if(!t)return;
     setLatest(v=>({...v,temp:{value:t.celsius,at,location:t.location}}));
     if(!sink.current({at,temperatureC:t.celsius,temperatureLocation:t.location,source:name})){state({status:'connected',name,error:'Reading live, but could not save sensor data.'});}
    }
   });
   if(thisGeneration!==generation.current){await disconnect(kind);return;}
   state({status:'connected',name});
  }catch(e){
   if(id&&devices.current[kind]?.id===id)await disconnect(kind);
   if(thisGeneration===generation.current)state({status:'idle',name:'',error:(e as Error).name==='NotFoundError'?'No sensor selected. Wake the sensor, enable Bluetooth broadcasting, and try again.':`Could not connect: ${(e as Error).message}`});
  }finally{pending.current.delete(kind);}
 }
 return {supported,heart,temperature,latest,connect,disconnect};
}
export type SensorController=ReturnType<typeof useSensors>;
