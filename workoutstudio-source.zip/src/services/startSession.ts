import {uid, type Activity, type Session, type Template} from '../data/types';
import {exerciseProfile,metricMode} from '../data/exerciseProfile';
export function startSession(template:Template,activities:Activity[],history:Session[],userId:string,startedAt=new Date().toISOString()):Session {
 const previous=history.filter(s=>s.userId===userId&&!s.sample&&s.completedAt&&Date.parse(s.completedAt)<Date.parse(startedAt)).sort((a,b)=>Date.parse(b.completedAt!)-Date.parse(a.completedAt!));
 return {id:uid(),userId,templateId:template.id,name:template.name,startedAt,completedAt:null,schemaVersion:2,units:{weight:'kg',distance:'km',time:'s'},utcOffsetSeconds:-new Date(startedAt).getTimezoneOffset()*60,
 activities:template.activities.map(ta=>{
  const found=activities.find(a=>a.id===ta.activityId);if(!found)throw new Error('Exercise is unavailable. Refresh your library.');
  const a=exerciseProfile(found);
  const matches=(s:Session)=>s.activities.find(log=>log.activityId===a.id&&metricMode(log)===a.metricMode&&log.rows.some(r=>r.done));
  const source=previous.find(s=>s.templateId===template.id&&matches(s))||previous.find(matches);
  const old=source&&matches(source);
  const rows=ta.useTargetsNextSession?undefined:old?.rows.filter(r=>r.done);
  return {id:uid(),activityId:a.id,name:a.name,type:a.type,tags:[...a.tags],stravaExerciseType:a.stravaExerciseType,stravaCategory:a.stravaCategory,stravaSportType:a.stravaSportType,metricMode:a.metricMode,previousSessionId:source?.id,planned:{...ta.targets},
   rows:rows?.length?Array.from({length:Math.min(30,Math.max(ta.targets.sets,rows.length))},(_,i)=>{const r=rows[i]||rows[rows.length-1];return {id:uid(),previousSetId:r.id,reps:r.reps,weight:r.weight,time:r.time,distance:r.distance,done:false};}):Array.from({length:Math.max(1,Math.min(30,ta.targets.sets))},()=>({id:uid(),reps:ta.targets.reps,weight:ta.targets.weight,time:ta.targets.time,distance:ta.targets.distance,done:false}))};
 })};
}
