import { supabaseClient } from './auth';
import { sensorSummary } from './sensors';
import { Session } from '../data/types';
import type { ShareInput } from '../../supabase/functions/strava/payload';
export interface StravaStatus { configured:boolean; connected:boolean; post?:{status:string;activity_id:number|null}|null }
export async function stravaRequest<T = Record<string, unknown>>(body:Record<string,unknown>,expectedUserId?:string):Promise<T> {
 if(!supabaseClient) throw new Error('Sign in with your online account to use Strava.');
 const session = (await supabaseClient.auth.getSession()).data.session;
 if(expectedUserId && session?.user.id !== expectedUserId) throw new Error('Sign in to the account that completed this workout.');
 const {data,error} = await supabaseClient.functions.invoke('strava',{body,headers:session?{Authorization:`Bearer ${session.access_token}`}:{}});
 if(error) {
  let message = 'Could not reach Strava integration. Please try again.';
  if(error.context instanceof Response) {try {message = (await error.context.json()).error || message;} catch { /* Non-JSON gateway response */ }}
  throw new Error(message);
 }
 if(data?.error) throw new Error(data.error);
 return data as T;
}
export function shareDraft(session:Session,includeHeartRate=false):ShareInput {
 if(!session.completedAt || session.sample) throw new Error('Only your own completed workouts can be shared.');
 const done = session.activities.filter(a=>a.rows.some(r=>r.done));
 if(!done.length) throw new Error('Complete at least one set before sharing.');
 let description = done.map(a => `${a.name}\n` + a.rows.filter(r=>r.done).map((r,i)=>`  ${i+1}. ${a.type === 'strength' ? `${r.reps} reps × ${r.weight} kg` : a.type === 'cardio' ? `${r.time}s · ${r.distance} km` : `${r.time}s × ${r.reps}`}`).join('\n')).join('\n\n');
 if(includeHeartRate && session.sensorSamples?.length){
  const summary=sensorSummary(session.sensorSamples);
  if(summary.average!==null) description+=`\n\nHeart rate: ${summary.average} bpm sampled average · ${summary.max} bpm peak.\n`+done.map(a=>{const v=sensorSummary(session.sensorSamples!,a.id);return v.average===null?'':`${a.name}: ${v.average} bpm average, ${v.max} bpm peak`;}).filter(Boolean).join('\n');
 }
 const start = new Date(session.startedAt);
 const offset = -start.getTimezoneOffset();
 const localDate = new Date(start.getTime()+offset*60000).toISOString().slice(0,19);
 const zone = `${offset>=0?'+':'-'}${String(Math.floor(Math.abs(offset)/60)).padStart(2,'0')}:${String(Math.abs(offset)%60).padStart(2,'0')}`;
 return {sessionId:session.id,name:session.name.slice(0,100),sportType:done.every(a=>a.type==='strength')?'WeightTraining':'Workout',startedAt:localDate+zone,elapsedTime:Math.max(1,Math.round((Date.parse(session.completedAt)-start.getTime())/1000)),description:(description+'\n\nLogged with Workout Studio · sportzlabs.com').slice(0,4000)};
}
let callbackPromise:Promise<unknown>|undefined;
export function completeStravaCallback() {
 const q = new URLSearchParams(window.location.search);
 if(!q.has('state') || (!q.has('code') && !q.has('error'))) return null;
 if(!callbackPromise) {
  callbackPromise = q.has('error') ? Promise.reject(new Error('Strava connection was cancelled. Your workout is still saved.')) : stravaRequest({action:'exchange',state:q.get('state'),code:q.get('code'),scope:q.get('scope')});
  callbackPromise = callbackPromise.finally(()=>{
   const url = new URL(window.location.href);
   ['code','state','scope','error','error_description'].forEach(k=>url.searchParams.delete(k));
   window.history.replaceState({},'',url);
  });
 }
 return callbackPromise;
}
