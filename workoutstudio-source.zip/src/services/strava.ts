import {metricMode,metricKeys,exerciseProfile} from '../data/exerciseProfile';
import {strengthSports} from '../../supabase/functions/strava/catalog';
import {exerciseCode, type StrengthSet} from '../../supabase/functions/strava/strength';
import { supabaseClient } from './auth';
import { sensorSummary } from './sensors';
import { Session } from '../data/types';
import type { ShareInput } from '../../supabase/functions/strava/payload';
export interface StravaStatus { configured:boolean; connected:boolean; post?:{status:string;activity_id:number|null;upload_id?:string|null}|null }
export async function stravaRequest<T = Record<string, unknown>>(body:Record<string,unknown>,expectedUserId?:string):Promise<T> {
 if(!supabaseClient) throw new Error('Sign in with your online account to use Strava.');
 const session = (await supabaseClient.auth.getSession()).data.session;
 if(expectedUserId && session?.user.id !== expectedUserId) throw new Error('Sign in to the account that completed this workout.');
 const {data,error} = await supabaseClient.functions.invoke('strava',{body,headers:session?{Authorization:`Bearer ${session.access_token}`}:{}});
 if(error) {
  let message = 'Could not reach Strava integration. Please try again.';
  if(error.context instanceof Response) {try {message = (await error.context.json()).error || message;} catch { /* Non-JSON gateway response */ }}
  throw new Error(message);
 }
 if(data?.error) throw new Error(data.error);
 return data as T;
}
export function strengthCoverage(session:Session){
 const done=session.activities.filter(a=>a.rows.some(r=>r.done));
 return {mapped:done.filter(a=>exerciseCode(a.name,a.stravaExerciseType)),unmapped:done.filter(a=>!exerciseCode(a.name,a.stravaExerciseType))};
}
export function shareDraft(session:Session,includeHeartRate=false):ShareInput {
 if(!session.completedAt || session.sample) throw new Error('Only your own completed workouts can be shared.');
 const done = session.activities.filter(a=>a.rows.some(r=>r.done));
 if(!done.length) throw new Error('Complete at least one set before sharing.');
 let description = done.map(a => `${a.name}\n` + a.rows.filter(r=>r.done).map((r,i)=>`  ${i+1}. ${metricMode(a)==='reps_weight' ? `${r.reps} reps × ${r.weight} kg` : metricMode(a)==='time_weight'?`${r.time}s · ${r.weight} kg`:metricMode(a)==='time_distance' ? `${r.time}s · ${r.distance} km` : `${r.time}s × ${r.reps}`}`).join('\n')).join('\n\n');
 if(includeHeartRate && session.sensorSamples?.length){
  const summary=sensorSummary(session.sensorSamples);
  if(summary.average!==null) description+=`\n\nHeart rate: ${summary.average} bpm sampled average · ${summary.max} bpm peak.\n`+done.map(a=>{const v=sensorSummary(session.sensorSamples!,a.id);return v.average===null?'':`${a.name}: ${v.average} bpm average, ${v.max} bpm peak`;}).filter(Boolean).join('\n');
 }
 const start = new Date(session.startedAt);
 const heartRateBySecond = new Map<number,number>();
 if(includeHeartRate) for(const sample of [...(session.sensorSamples || [])].sort((a,b)=>a.at-b.at)) {
  if(!Number.isFinite(sample.at) || sample.at < start.getTime() || sample.at > Date.parse(session.completedAt) || !Number.isInteger(sample.heartRate) || sample.heartRate! < 1 || sample.heartRate! > 254) continue;
  heartRateBySecond.set(Math.floor((sample.at-start.getTime())/1000),sample.heartRate!);
 }
 const streams = heartRateBySecond.size ? {time:[...heartRateBySecond.keys()],heartrate:[...heartRateBySecond.values()]} : undefined;
 const offset = session.utcOffsetSeconds!==undefined?session.utcOffsetSeconds/60:-start.getTimezoneOffset();
 const sets:StrengthSet[]=done.flatMap(a=>{
  const code=exerciseCode(a.name,a.stravaExerciseType);if(!code)return [];
  return a.rows.filter(r=>r.done&&(metricMode(a)==='reps_weight'?r.reps>0:r.time>0)).map(r=>({exercise_type:code,...(metricMode(a)==='reps_weight'?{repetitions:r.reps,weight:r.weight}:{duration:Math.round(r.time),...(metricKeys(metricMode(a))[1]==='weight'?{weight:r.weight}:metricKeys(metricMode(a))[1]==='reps'&&r.reps>0?{repetitions:r.reps}:{})})}));
 });
 const sports=new Set(done.map(a=>a.stravaSportType||exerciseProfile({...a,userId:session.userId,defaults:a.planned}).stravaSportType));
 const sportType=sports.size===1?[...sports][0]!:done.some(a=>a.type==='strength')?'WeightTraining':'Workout';
 const distance=Math.round(done.flatMap(a=>metricMode(a)==='time_distance'?a.rows.filter(r=>r.done):[]).reduce((n,r)=>n+r.distance*1000,0));
 const localDate = new Date(start.getTime()+offset*60000).toISOString().slice(0,19);
 const zone = `${offset>=0?'+':'-'}${String(Math.floor(Math.abs(offset)/60)).padStart(2,'0')}:${String(Math.abs(offset)%60).padStart(2,'0')}`;
 return {...(streams?{streams}:{}),...(sets.length&&strengthSports.includes(sportType)?{strength:{utcOffset:offset*60,sets}}:{}),sessionId:session.id,name:session.name.slice(0,100),sportType,...(distance>0?{distance}:{}),startedAt:localDate+zone,elapsedTime:Math.max(1,Math.round((Date.parse(session.completedAt)-start.getTime())/1000)),description:('https://sportzlabs.com · Logged with Workout Studio\n\n'+description).slice(0,4000)};
}
let callbackPromise:Promise<unknown>|undefined;
export function completeStravaCallback() {
 const q = new URLSearchParams(window.location.search);
 if(!q.has('state') || (!q.has('code') && !q.has('error'))) return null;
 if(window.opener){
  for(const origin of ['https://www.sportzlabs.com','https://sportzlabs.com','https://workout-studio.derekenderby.chatgpt.site','http://localhost:5173'])window.opener.postMessage({type:'workoutstudio-strava-callback',url:window.location.href},origin);
  return Promise.resolve();
 }

 if(!callbackPromise) {
  callbackPromise = q.has('error') ? Promise.reject(new Error('Strava connection was cancelled. Your workout is still saved.')) : stravaRequest({action:'exchange',state:q.get('state'),code:q.get('code'),scope:q.get('scope')});
  callbackPromise = callbackPromise.finally(()=>{
   const url = new URL(window.location.href);
   ['code','state','scope','error','error_description'].forEach(k=>url.searchParams.delete(k));
   window.history.replaceState({},'',url);
  });
 }
 return callbackPromise;
}
