export {};

declare global {
  interface Window {
    __WORKOUTSTUDIO_CONFIG__?: Record<string, string | undefined>;
  }
}
