import { repairStarterBatches } from "./starterRepair";
import type { UserData } from "../data/types";
import { auth, supabaseClient } from "./auth";

export const CLOUD_SYNC_CHANGED = "workoutstudio:cloud-sync-changed";
export type CloudSyncStatus = "disabled" | "syncing" | "synced" | "offline" | "error";
const runtimeEnv = (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env;
const apiUrl = (runtimeEnv?.VITE_CLOUDFLARE_API_URL || (typeof window !== "undefined" ? window.__WORKOUTSTUDIO_CONFIG__?.VITE_CLOUDFLARE_API_URL : ""))?.trim().replace(/\/$/, "");
const enabled = auth.mode === "supabase" && Boolean(apiUrl) && Boolean(supabaseClient);
const revisions = new Map<string, number>();
const knownUsers = new Set<string>();
const queues = new Map<string, Promise<void>>();
const timers = new Map<string, ReturnType<typeof setTimeout>>();
const states = new Map<string, CloudSyncStatus>();
const initializing = new Map<string, Promise<UserData>>();

function setStatus(userId: string, status: CloudSyncStatus, detail = "") {
  states.set(userId, status);
  window.dispatchEvent(new CustomEvent(CLOUD_SYNC_CHANGED, { detail: { userId, status, message: detail } }));
}

export function cloudWorkoutSyncEnabled() { return enabled; }
export function cloudWorkoutSyncStatus(userId: string): CloudSyncStatus {
  return states.get(userId) || (enabled ? "syncing" : "disabled");
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  if (!supabaseClient || !apiUrl) throw new Error("Cloud workout sync is not configured.");
  const { data, error } = await supabaseClient.auth.getSession();
  if (error || !data.session?.access_token) throw new Error("Sign in again to sync your workouts.");
  const response = await fetch(`${apiUrl}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${data.session.access_token}`,
      ...init?.headers,
    },
  });
  if (response.status === 409) {
    const conflict = await response.json() as T;
    return { ...conflict as object, conflict: true } as T;
  }
  if (!response.ok) {
    const message = await response.json().catch(() => ({})) as { error?: string };
    throw new Error(message.error || `Workout sync failed (${response.status}).`);
  }
  return response.json() as Promise<T>;
}

type CloudSnapshot = { data: UserData | null; revision: number; modifiedAt: number };
async function readCloud(): Promise<CloudSnapshot> {
  return request<CloudSnapshot>("/v1/workouts");
}
async function writeCloud(data: UserData, expectedRevision: number, modifiedAt: number) {
  return request<CloudSnapshot & { conflict?: boolean }>("/v1/workouts", {
    method: "PUT",
    body: JSON.stringify({ data, expectedRevision, modifiedAt }),
  });
}

function byId<T extends { id: string }>(preferred: T[], other: T[]): T[] {
  const result = new Map(preferred.map((item) => [item.id, item]));
  for (const item of other) if (!result.has(item.id)) result.set(item.id, item);
  return [...result.values()];
}

/** Merge separate devices without replacing an existing cloud record with a stale local copy. */
export function mergeWorkoutData(cloud: UserData, local: UserData, localIsNewer = false): UserData {
  const first = localIsNewer ? local : cloud;
  const second = localIsNewer ? cloud : local;
  return {
    ...first,
    templates: byId(first.templates, second.templates),
    customActivities: byId(first.customActivities, second.customActivities),
    sessions: byId(first.sessions, second.sessions),
    activeSession: first.activeSession || second.activeSession,
  };
}

/** A generated fallback is not saved user data and must never be imported into an existing account. */
export function initialWorkoutData(cloud: UserData | null, stored: UserData | null, fallback: UserData, localIsNewer = false): UserData {
  return repairStarterBatches(cloud ? (stored ? mergeWorkoutData(cloud, stored, localIsNewer) : cloud) : (stored || fallback));
}

function readLocal(userId: string): UserData | null {
  try {
    const raw = localStorage.getItem(`workoutstudio:data:${userId}`);
    if (!raw) return null;
    const value = JSON.parse(raw) as UserData;
    return value.version === 1 ? value : null;
  } catch {
    return null;
  }
}

/** Locate an old device-only account using its exact verified email, without deleting its local copy. */
export function readLegacyWorkoutForEmail(
  email: string,
  storage: Pick<Storage, "getItem">,
): { data: UserData; modifiedAt: number } | null {
  const normalizedEmail = email.trim().toLowerCase();
  if (!normalizedEmail) return null;
  try {
    const accounts = JSON.parse(storage.getItem("workoutstudio:accounts") || "[]") as Array<{ id?: string; email?: string }>;
    const matchingIds = accounts
      .filter((account) => account.id && account.email?.trim().toLowerCase() === normalizedEmail)
      .map((account) => account.id as string);
    let result: { data: UserData; modifiedAt: number } | null = null;
    for (const id of matchingIds) {
      const value = JSON.parse(storage.getItem(`workoutstudio:data:${id}`) || "null") as UserData | null;
      if (!value || value.version !== 1 || !Array.isArray(value.templates) || !Array.isArray(value.sessions)) continue;
      const modifiedAt = Number(storage.getItem(`workoutstudio:modified:${id}`) || 0) || 0;
      result = result
        ? { data: mergeWorkoutData(result.data, value, modifiedAt > result.modifiedAt), modifiedAt: Math.max(modifiedAt, result.modifiedAt) }
        : { data: value, modifiedAt };
    }
    return result;
  } catch {
    return null;
  }
}

export function initializeCloudWorkoutSync(userId: string, localData: UserData, email = ""): Promise<UserData> {
  const pending = initializing.get(userId);
  if (pending) return pending;
  const task = initialize(userId, localData, email).finally(() => initializing.delete(userId));
  initializing.set(userId, task);
  return task;
}

async function initialize(userId: string, localData: UserData, email: string): Promise<UserData> {
  if (!enabled) return localData;
  knownUsers.add(userId);
  setStatus(userId, "syncing");
  try {
    const cloud = await readCloud();
    revisions.set(userId, cloud.revision);
    const storedLocal = readLocal(userId);
    const migrationKey = `workoutstudio:legacy-imported:${userId}`;
    const legacy = localStorage.getItem(migrationKey) ? null : readLegacyWorkoutForEmail(email, localStorage);
    const baseline = localStorage.getItem(`workoutstudio:synced-data:${userId}`);
    let local = cloud.data && baseline === JSON.stringify(storedLocal) ? null : storedLocal;

    let localModifiedAt = Number(localStorage.getItem(`workoutstudio:modified:${userId}`) || 0) || 0;
    if (legacy) {
      local = local ? mergeWorkoutData(local, legacy.data, legacy.modifiedAt > localModifiedAt) : legacy.data;
      localModifiedAt = Math.max(localModifiedAt, legacy.modifiedAt);
    }
    const localIsNewer = localModifiedAt > cloud.modifiedAt;
    const merged = initialWorkoutData(cloud.data, local, localData, localIsNewer);
    // Retain originals before the automatic repair changes either saved copy.
    const backupKey = `workoutstudio:backup:starter-repair-v1:${userId}`;
    if (!localStorage.getItem(backupKey) && (
      (cloud.data && repairStarterBatches(cloud.data) !== cloud.data) ||
      (local && repairStarterBatches(local) !== local))) {
      localStorage.setItem(backupKey, JSON.stringify({ cloud: cloud.data, local, savedAt: Date.now() }));
    }
    let modifiedAt = Math.max(localModifiedAt, cloud.modifiedAt);
    if (JSON.stringify(merged) !== JSON.stringify(cloud.data)) {
      const saved = await writeCloud(merged, cloud.revision, localIsNewer ? localModifiedAt : Date.now());
      if (saved.conflict) throw new Error("Workout data changed during first sync. Please try again.");
      revisions.set(userId, saved.revision);
      modifiedAt = saved.modifiedAt;
    }
    localStorage.setItem(`workoutstudio:data:${userId}`, JSON.stringify(merged));
    localStorage.setItem(`workoutstudio:modified:${userId}`, String(modifiedAt));
    localStorage.setItem(`workoutstudio:synced-data:${userId}`, JSON.stringify(merged));
    if (legacy) localStorage.setItem(migrationKey, "1");
    setStatus(userId, "synced");
    return merged;
  } catch (error) {
    setStatus(userId, navigator.onLine ? "error" : "offline", (error as Error).message);
    return localData;
  }
}

async function flush(userId: string, data: UserData) {
  if (!enabled) return;
  const previous = queues.get(userId) || Promise.resolve();
  const next = previous.catch(() => {}).then(async () => {
    if (!navigator.onLine) {
      setStatus(userId, "offline", "Saved on this device. It will sync when you are online.");
      return;
    }
    setStatus(userId, "syncing");
    let revision = revisions.get(userId) ?? 0;
    let candidate = data;
    let candidateModifiedAt = Number(localStorage.getItem(`workoutstudio:modified:${userId}`) || Date.now());
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const saved = await writeCloud(candidate, revision, candidateModifiedAt);
        if (saved.conflict) {
          const latest = await readCloud();
          revision = latest.revision;
          const localIsNewer = candidateModifiedAt > latest.modifiedAt;
          candidate = latest.data ? mergeWorkoutData(latest.data, candidate, localIsNewer) : candidate;
          candidateModifiedAt = Math.max(candidateModifiedAt, latest.modifiedAt);
          continue;
        }
        revisions.set(userId, saved.revision);
        localStorage.setItem(`workoutstudio:synced-data:${userId}`, JSON.stringify(candidate));
        // Do not overwrite an edit made while this request was in flight.
        if (JSON.stringify(readLocal(userId)) === JSON.stringify(data)) {
          localStorage.setItem(`workoutstudio:data:${userId}`, JSON.stringify(candidate));
          localStorage.setItem(`workoutstudio:modified:${userId}`, String(saved.modifiedAt));
          window.dispatchEvent(new Event("workoutstudio:data-changed"));
        }
        setStatus(userId, "synced");
        return;
      } catch (error) { throw error; }
    }
    throw new Error("Your workouts changed on another device. Keep this app online and try again.");
  }).catch((error) => {
    setStatus(userId, navigator.onLine ? "error" : "offline", (error as Error).message);
  });
  queues.set(userId, next);
  await next;
}

export function enqueueCloudWorkoutSync(userId: string, data: UserData) {
  if (!enabled) return;
  knownUsers.add(userId);
  const old = timers.get(userId);
  if (old) clearTimeout(old);
  timers.set(userId, setTimeout(() => { void flush(userId, data); }, 500));
}

export function syncCloudWorkoutsNow(userId: string, data: UserData) {
  if (enabled) return flush(userId, data);
  return Promise.resolve();
}

if (typeof window !== "undefined") window.addEventListener("online", () => {
  if (!enabled) return;
  for (const userId of knownUsers) {
    const data = readLocal(userId);
    if (data) void flush(userId, data);
  }
});
