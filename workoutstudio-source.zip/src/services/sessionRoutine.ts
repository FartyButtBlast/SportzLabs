import { uid, type Activity, type Session, type UserData } from '../data/types';
import { startSession } from './startSession';

export function addSessionExercise(session: Session, activity: Activity, history: Session[]): Session {
  if (session.completedAt) throw new Error('This session is already complete.');
  const extra = startSession({id: session.templateId, userId: session.userId, name: session.name, description: '', createdAt: session.startedAt,
    activities: [{id: uid(), activityId: activity.id, targets: {...activity.defaults}}]}, [activity], history, session.userId, session.startedAt);
  return {...session, addedDuringSession: true, activities: [...session.activities, ...extra.activities]};
}

// Create a separate routine; never overwrite the source template or logged work.
export function saveSessionRoutine(data: UserData, session: Session, library: Activity[], name: string): UserData {
  if (!name.trim() || !session.activities.length) throw new Error('Give your routine a name and at least one exercise.');
  const customActivities = [...data.customActivities];
  const available = [...library, ...customActivities];
  const activities = session.activities.map(log => {
    let activity = available.find(a => a.id === log.activityId && (!a.userId || a.userId === session.userId));
    if (!activity) {
      activity = {id: uid(), userId: session.userId, name: log.name, type: log.type, tags: [...log.tags], defaults: {...log.planned},
        metricMode: log.metricMode, stravaExerciseType: log.stravaExerciseType, stravaCategory: log.stravaCategory, stravaSportType: log.stravaSportType};
      customActivities.push(activity);
      available.push(activity);
    }
    const row = log.rows.find(r => r.done) || log.rows[0] || log.planned;
    return {id: uid(), activityId: activity.id, targets: {sets: Math.max(1, Math.min(30, log.rows.length)), reps: row.reps, weight: row.weight, time: row.time, distance: row.distance}};
  });
  return {...data, customActivities, templates: [...data.templates, {id: uid(), userId: session.userId, name: name.trim().slice(0,60),
    description: 'Saved from a workout session', createdAt: new Date().toISOString(), activities}]};
}
