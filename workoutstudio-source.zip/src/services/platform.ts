import {supabaseClient} from './auth';
import {library} from '../data/seed';
import type {Activity} from '../data/types';
export async function platformRequest<T=any>(action:string,values:Record<string,unknown>={}):Promise<T>{
 if(!supabaseClient)throw new Error('Secure sign-in has not been configured.');
 const {data,error}=await supabaseClient.functions.invoke('platform-admin',{body:{action,...values}});
 if(error){let message=error.message;try{message=(await error.context.json()).error||message;}catch{}throw new Error(message);}
 if(data?.error)throw new Error(data.error);return data;
}
export function mergeCatalog(overrides:Activity[]):Activity[]{const byId=new Map(library.map(a=>[a.id,a]));for(const a of overrides)byId.set(a.id,a);return [...byId.values()];}
export function cachedCatalog():Activity[]{try{const a=JSON.parse(localStorage.getItem('sportzlabs-catalog-v1')||'[]');if(Array.isArray(a)&&a.every(x=>x&&typeof x.id==='string'&&typeof x.name==='string'&&Array.isArray(x.tags)&&x.defaults))return mergeCatalog(a);}catch{}return library;}
export async function loadCatalog(){const r=await platformRequest<{exercises:Activity[]}>('catalog');try{localStorage.setItem('sportzlabs-catalog-v1',JSON.stringify(r.exercises));}catch{}return mergeCatalog(r.exercises);}
type UsageEvent={event:string;eventId:string;occurredAt:string};
const recent=new Map<string,number>();
const flushing=new Set<string>();
const usageKey=(id:string)=>`workoutstudio:usage-outbox:${id}`;
export function trackUsage(event:string,eventId:string=crypto.randomUUID(),expectedUserId?:string){
 if(!supabaseClient)return;
 const now=Date.now();if(now-(recent.get(event)||0)<1500)return;recent.set(event,now);
 void supabaseClient.auth.getSession().then(({data})=>{
  const userId=data.session?.user.id;if(!userId||(expectedUserId&&expectedUserId!==userId))return;
  const key=usageKey(userId),queue:UsageEvent[]=JSON.parse(localStorage.getItem(key)||'[]');
  queue.push({event,eventId,occurredAt:new Date(now).toISOString()});localStorage.setItem(key,JSON.stringify(queue));
  void flushUsage();
 }).catch(()=>{});
}
export async function flushUsage(){
 if(!supabaseClient||!navigator.onLine)return;
 const userId=(await supabaseClient.auth.getSession()).data.session?.user.id;if(!userId||flushing.has(userId))return;
 flushing.add(userId);
 try{
  const key=usageKey(userId);
  for(const event of JSON.parse(localStorage.getItem(key)||'[]') as UsageEvent[]){
   if((await supabaseClient.auth.getSession()).data.session?.user.id!==userId)return;
   await platformRequest('track',{app:'workoutstudio',...event});
   const current:UsageEvent[]=JSON.parse(localStorage.getItem(key)||'[]');
   localStorage.setItem(key,JSON.stringify(current.filter(e=>e.eventId!==event.eventId)));
  }
 }catch{/* Retain unsent events; the server deduplicates uncertain responses. */}finally{flushing.delete(userId);}
}
if(typeof window!=='undefined'){
 window.addEventListener('online',()=>{void flushUsage().catch(()=>{});});
 window.addEventListener('focus',()=>{void flushUsage().catch(()=>{});});
}
