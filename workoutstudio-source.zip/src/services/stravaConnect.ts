import {Capacitor,registerPlugin} from '@capacitor/core';
import {stravaRequest} from './strava';
import {nativeRedirect} from '../../supabase/functions/strava/oauth';
const NativeAuth=registerPlugin<{authorize(options:{url:string}):Promise<{url:string}>}>('StravaAuth');
export async function connectStrava(userId:string){
 if(Capacitor.isNativePlatform()){
  const result=await stravaRequest<{url:string}>({action:'connect',redirectUri:nativeRedirect},userId);
  const callback=await NativeAuth.authorize({url:result.url});
  const url=new URL(callback.url);
  if(url.origin!=='null'||`${url.protocol}//${url.host}${url.pathname}`!==nativeRedirect)throw new Error('Unexpected Strava callback.');
  if(url.searchParams.has('error'))throw new Error('Strava connection cancelled. Your workouts are saved.');
  await stravaRequest({action:'exchange',state:url.searchParams.get('state'),code:url.searchParams.get('code'),scope:url.searchParams.get('scope')},userId);
  return;
 }
 // A common callback domain works for both public web addresses without a
 // second Workout Studio login. The receiver validates origin and popup identity.
 const popup=window.open('about:blank','workoutstudio-strava','popup,width=520,height=720');
 if(!popup)throw new Error('Allow the Strava sign-in window, then try again.');
 try{
  const result=await stravaRequest<{url:string}>({action:'connect',redirectUri:'https://www.sportzlabs.com/workoutstudio/'},userId);
  const expectedState=new URL(result.url).searchParams.get('state');
  await new Promise<void>((resolve,reject)=>{
   const cleanup=()=>{window.removeEventListener('message',receive);clearInterval(timer);clearTimeout(expiry);popup.close();};
   const receive=(event:MessageEvent)=>{
    if(event.origin!=='https://www.sportzlabs.com'||event.source!==popup||event.data?.type!=='workoutstudio-strava-callback')return;
    let url:URL;try{url=new URL(event.data.url);}catch{return;}
    if(url.origin!==event.origin||url.pathname!=='/workoutstudio/'||url.searchParams.get('state')!==expectedState)return;
    cleanup();
    if(url.searchParams.has('error')){reject(new Error('Strava connection cancelled. Your workouts are saved.'));return;}
    stravaRequest({action:'exchange',state:expectedState,code:url.searchParams.get('code'),scope:url.searchParams.get('scope')},userId).then(()=>resolve(),reject);
   };
   window.addEventListener('message',receive);
   const timer=setInterval(()=>{if(popup.closed){cleanup();reject(new Error('Strava sign-in window closed. You can try again.'));}},500);
   const expiry=setTimeout(()=>{cleanup();reject(new Error('Strava sign-in expired. Please try again.'));},600000);
   popup.location.href=result.url;
  });
 }catch(error){popup.close();throw error;}
}
