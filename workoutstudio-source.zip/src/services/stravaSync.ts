import type { Session } from '../data/types';
import { repository } from './repository';
import { shareDraft, stravaRequest, type StravaStatus } from './strava';
export type UploadState = { state:'pending'|'posted'|'failed'|'unknown'|'skipped'; attempts:number; nextAt?:number; message?:string; activityId?:number; includeHeartRate?:boolean };
export type SharingPreferences = { autoUpload:boolean; includeHeartRate:boolean };
export const DATA_CHANGED = 'workoutstudio:data-changed';
export const STRAVA_CHANGED = 'workoutstudio:strava-changed';
export function sharingPreferences(userId:string):SharingPreferences {
 try { const v=JSON.parse(localStorage.getItem(`workoutstudio:sharing:${userId}`)||'{}'); return {autoUpload:v.autoUpload !== false,includeHeartRate:v.includeHeartRate===true}; }catch{return {autoUpload:true,includeHeartRate:false};}
}
export function saveSharingPreferences(userId:string,p:SharingPreferences){localStorage.setItem(`workoutstudio:sharing:${userId}`,JSON.stringify(p));window.dispatchEvent(new Event(STRAVA_CHANGED));}
export function prepareCompletedSession(session:Session,connected:boolean,p:SharingPreferences):Session {
 return {...session,stravaUpload:connected&&p.autoUpload&&!session.sample?{state:'pending',attempts:0,includeHeartRate:p.includeHeartRate}:undefined};
}
function update(userId:string,id:string,patch:UploadState){
 const current=repository.load(userId);
 if(!current.sessions.some(s=>s.id===id)) return;
 repository.save(userId,{...current,sessions:current.sessions.map(s=>s.id===id?{...s,stravaUpload:patch}:s)});
 window.dispatchEvent(new Event(DATA_CHANGED));
}
const running=new Map<string,Promise<void>>();
export function syncCompletedSession(userId:string,id:string):Promise<void>{
 const key=`${userId}:${id}`;
 if(running.has(key))return running.get(key)!;
 const p=performSync(userId,id).finally(()=>{running.delete(key);window.dispatchEvent(new Event(STRAVA_CHANGED));});running.set(key,p);return p;
}
export type SyncDependencies = {
 load: (userId:string)=>{sessions:Session[]};
 update: typeof update;
 preferences: typeof sharingPreferences;
 request: typeof stravaRequest;
 online: ()=>boolean;
};
export async function performSync(userId:string,id:string,deps:SyncDependencies={load:repository.load,update,preferences:sharingPreferences,request:stravaRequest,online:()=>navigator.onLine}){
 const {update,preferences,request}=deps;
 const session=deps.load(userId).sessions.find(s=>s.id===id);
 const job=session?.stravaUpload;
 if(!session||!session.completedAt||session.sample||job?.state!=='pending'||(job.nextAt||0)>Date.now())return;
 if(!preferences(userId).autoUpload){update(userId,id,{...job,state:'skipped',message:'Automatic sharing was switched off. You can share this workout manually.'});return;}
 if(!deps.online())return;
 let shareAttempted=false;
 try{
  const status=await request<StravaStatus>({action:'status',sessionId:id},userId);
  if(status.post?.status==='posted'){update(userId,id,{...job,state:'posted',activityId:status.post.activity_id!});return;}
  if(status.post&&['sending','unknown'].includes(status.post.status)){update(userId,id,{...job,state:'unknown',message:'Strava may have received this workout. Check your feed; reposting is blocked to prevent duplicates.'});return;}
  if(!status.configured||!status.connected){update(userId,id,{...job,state:'skipped',message:'Strava is not connected. Reconnect to share this workout manually.'});return;}
  // Build immediately before sending, respecting a revoked sensor-sharing preference.
  const draft=shareDraft(session,job.includeHeartRate===true&&preferences(userId).includeHeartRate);
  shareAttempted=true;
  const result=await request<{activityId:number}>({action:'share',workout:draft},userId);
  update(userId,id,{...job,state:'posted',activityId:result.activityId});
 }catch(e){
  const attempts=job.attempts+1;
  // A lost response after POST must first be reconciled with the server on retry.
  // The server's unique session record prevents duplicates even after a reload.
  update(userId,id,{...job,state:attempts>=5?'failed':'pending',attempts,nextAt:Date.now()+Math.min(300000,15000*2**attempts),message:shareAttempted?'Upload not confirmed yet. We will check Strava’s result before retrying.':(e as Error).message});
 }
}
export function retryUpload(userId:string,session:Session){update(userId,session.id,{state:'pending',attempts:0,includeHeartRate:sharingPreferences(userId).includeHeartRate});return syncCompletedSession(userId,session.id);}
