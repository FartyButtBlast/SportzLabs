import {trackUsage} from './platform';
import type { Session } from '../data/types';
import { repository } from './repository';
import { shareDraft, stravaRequest, type StravaStatus } from './strava';
export type UploadState = { state:'pending'|'waiting'|'posted'|'failed'|'unknown'|'skipped'; attempts:number; nextAt?:number; message?:string; activityId?:number; includeHeartRate?:boolean; manualRetry?:boolean };
export type SharingPreferences = { autoUpload:boolean; includeHeartRate:boolean };
export const DATA_CHANGED = 'workoutstudio:data-changed';
export const STRAVA_CHANGED = 'workoutstudio:strava-changed';
export function sharingPreferences(userId:string):SharingPreferences {
 try { const v=JSON.parse(localStorage.getItem(`workoutstudio:sharing:${userId}`)||'{}'); return {autoUpload:v.autoUpload !== false,includeHeartRate:v.includeHeartRate===true}; }catch{return {autoUpload:true,includeHeartRate:false};}
}
export function saveSharingPreferences(userId:string,p:SharingPreferences){localStorage.setItem(`workoutstudio:sharing:${userId}`,JSON.stringify(p));window.dispatchEvent(new Event(STRAVA_CHANGED));}
export function prepareCompletedSession(session:Session,_connected:boolean,p:SharingPreferences):Session {
 return {...session,stravaUpload:Boolean(session.completedAt)&&p.autoUpload&&!session.sample?{state:'pending',attempts:0,includeHeartRate:p.includeHeartRate}:undefined};
}
function update(userId:string,id:string,patch:UploadState){
 const current=repository.load(userId);
 if(!current.sessions.some(s=>s.id===id)) return;
 const before=current.sessions.find(s=>s.id===id)?.stravaUpload?.state;
 if(before!==patch.state&&['failed','unknown','waiting'].includes(patch.state))trackUsage('strava:upload-'+patch.state,id+':strava-'+patch.state,userId);
 repository.save(userId,{...current,sessions:current.sessions.map(s=>s.id===id?{...s,stravaUpload:patch}:s)});
 window.dispatchEvent(new Event(DATA_CHANGED));
}
const running=new Map<string,Promise<void>>();
export function syncCompletedSession(userId:string,id:string):Promise<void>{
 const key=`${userId}:${id}`;
 if(running.has(key))return running.get(key)!;
 const p=performSync(userId,id).finally(()=>{running.delete(key);});running.set(key,p);return p;
}
export type SyncDependencies = {
 load: (userId:string)=>{sessions:Session[]};
 update: typeof update;
 preferences: typeof sharingPreferences;
 request: typeof stravaRequest;
 online: ()=>boolean;
};
export async function performSync(userId:string,id:string,deps:SyncDependencies={load:repository.load,update,preferences:sharingPreferences,request:stravaRequest,online:()=>navigator.onLine}){
 const {update,preferences,request}=deps;
 const session=deps.load(userId).sessions.find(s=>s.id===id);
 const job=session?.stravaUpload;
 if(!session||!session.completedAt||session.sample||!job||!['pending','waiting'].includes(job.state)||(job.nextAt||0)>Date.now())return;
  if(!deps.online())return;
 let shareAttempted=false;
 try{
  const status=await request<StravaStatus>({action:'status',sessionId:id},userId);
  if(status.post?.status==='posted'){update(userId,id,{...job,state:'posted',activityId:status.post.activity_id!});return;}
  if(status.post&&['sending','unknown'].includes(status.post.status)&&! (status.post.status==='sending'&&status.post.upload_id)){update(userId,id,{...job,state:'unknown',message:'Strava may have received this workout. Check your feed; reposting is blocked to prevent duplicates.'});return;}
  if(!status.configured||!status.connected){update(userId,id,{...job,state:'waiting',nextAt:Date.now()+30000,message:'Waiting for Strava. Connect in Account settings to resume automatic sharing.'});return;}
  if(status.post?.status==='sending'&&status.post.upload_id){
   const result=await request<{activityId?:number;processing?:boolean}>({action:'reconcile',sessionId:id},userId);
   update(userId,id,result.processing?{...job,state:'pending',attempts:0,nextAt:Date.now()+2000,message:'Strava is processing your workout…'}:{...job,state:'posted',activityId:result.activityId});return;
  }
  if(!preferences(userId).autoUpload&&!job.manualRetry){update(userId,id,{...job,state:'skipped',message:'Automatic sharing was switched off. This workout was not sent.'});return;}
  // Build immediately before sending, respecting a revoked sensor-sharing preference.
  const draft=shareDraft(session,job.includeHeartRate===true&&preferences(userId).includeHeartRate);
  shareAttempted=true;
  const result=await request<{activityId?:number;processing?:boolean}>({action:'share',workout:draft},userId);
  update(userId,id,result.processing?{...job,state:'pending',attempts:0,nextAt:Date.now()+2000,message:'Strava is processing your workout…'}:{...job,state:'posted',activityId:result.activityId});
 }catch(e){
  const attempts=job.attempts+1;
  // A lost response after POST must first be reconciled with the server on retry.
  // The server's unique session record prevents duplicates even after a reload.
  update(userId,id,{...job,state:attempts>=5?'failed':'pending',attempts,nextAt:Date.now()+Math.min(300000,15000*2**attempts),message:(e as Error).message+(shareAttempted?' We check the previous result before retrying.':'')});
 }
}
export function retryUpload(userId:string,session:Session){trackUsage('strava:upload-retried',crypto.randomUUID(),userId);update(userId,session.id,{state:'pending',attempts:0,manualRetry:true,includeHeartRate:sharingPreferences(userId).includeHeartRate});return syncCompletedSession(userId,session.id);}
