import {useCallback,useEffect,useRef,useState} from 'react';
import {supabaseClient} from './auth';
import type {Session} from '../data/types';
export const PROGRESSION='workouts.progression';
export const INSIGHTS='workouts.insights.advanced';
export function proHistory(sessions:Session[],userId:string){
 return sessions.filter(s=>s.userId===userId&&!s.sample&&s.completedAt).sort((a,b)=>Date.parse(b.completedAt!)-Date.parse(a.completedAt!)).slice(0,1000).map(s=>({id:s.id,userId:s.userId,templateId:s.templateId,completedAt:s.completedAt,activities:s.activities.map(a=>({activityId:a.activityId,name:a.name,type:a.type,metricMode:a.metricMode,tags:a.tags,rows:a.rows.map(r=>({done:r.done,reps:r.reps,weight:r.weight,time:r.time,distance:r.distance}))}))}));
}
export function useProAccess(userId:string){
 const [keys,setKeys]=useState<string[]>([]);
 const epoch=useRef(0),mounted=useRef(false),checkId=useRef(0),currentKeys=useRef<string[]>([]);
 const hide=useCallback(()=>{epoch.current++;currentKeys.current=[];setKeys([]);},[]);
 const applyKeys=useCallback((next:string[])=>{if(currentKeys.current.some(k=>!next.includes(k)))epoch.current++;currentKeys.current=next;setKeys(next);},[]);
 const invoke=useCallback(async(action:string,values:Record<string,unknown>={})=>{
  if(!supabaseClient||!navigator.onLine)throw new Error('Connect to verify your access.');
  const {data:session}=await supabaseClient.auth.getSession();
  if(session.session?.user.id!==userId)throw new Error('Sign in again to continue.');
  const {data,error}=await supabaseClient.functions.invoke('workout-pro',{body:{...values,action}});
  if(error){const status=error.context?.status;const failure=new Error('Unable to load this feature. Please try again.') as Error&{status?:number};failure.status=status;
   try{failure.message=(await error.context.json()).error||failure.message;}catch{/* network failure */}throw failure;
  }
  if(!data||!Array.isArray(data.capabilities))throw new Error('Unable to verify access.');
  return data;
 },[userId]);
 const refresh=useCallback(async()=>{
  const id=++checkId.current,version=epoch.current;
  if(!navigator.onLine||document.visibilityState==='hidden'){hide();return;}
  try{const data=await invoke('access');if(mounted.current&&id===checkId.current&&version===epoch.current)applyKeys(data.capabilities);}
  catch{if(mounted.current&&id===checkId.current)hide();}
 },[invoke,hide,applyKeys]);
 useEffect(()=>{
  mounted.current=true;hide();void refresh();
  const recheck=()=>{hide();void refresh();};
  const interval=window.setInterval(()=>void refresh(),30000);
  window.addEventListener('focus',recheck);window.addEventListener('online',recheck);window.addEventListener('offline',hide);document.addEventListener('visibilitychange',recheck);
  return()=>{mounted.current=false;epoch.current++;checkId.current++;clearInterval(interval);window.removeEventListener('focus',recheck);window.removeEventListener('online',recheck);window.removeEventListener('offline',hide);document.removeEventListener('visibilitychange',recheck);};
 },[refresh,hide]);
 const request=useCallback(async<T,>(action:'progression'|'insights',values:Record<string,unknown>):Promise<T>=>{
  const version=epoch.current;
  try{
   const data=await invoke(action,values);
   if(!mounted.current||version!==epoch.current)throw new Error('Access changed. Please try again.');
   const required=action==='progression'?PROGRESSION:INSIGHTS;
   if(!data.capabilities.includes(required)){hide();throw new Error('Access changed.');}
   applyKeys(data.capabilities);return data.result as T;
  }catch(error){if(mounted.current&&version===epoch.current&&(error as {status?:number}).status!==400)hide();throw error;}
 },[invoke,hide,applyKeys]);
 return {progression:keys.includes(PROGRESSION),insights:keys.includes(INSIGHTS),request};
}
export type ProRequest=ReturnType<typeof useProAccess>['request'];
