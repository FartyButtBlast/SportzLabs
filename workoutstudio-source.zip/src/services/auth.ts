import { Capacitor } from "@capacitor/core";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { auth as local } from "./localAuth";
import { readAuthConfig } from "./authConfig";
import { createSupabaseAuth } from "./supabaseAuth";
import { AuthEvent, AuthService } from "./authTypes";
import { Profile } from "../data/types";
const listeners = new Set<(event: AuthEvent, user: Profile | null) => void>();
const emit = (event: AuthEvent, user: Profile | null) =>
  listeners.forEach((listener) => listener(event, user));
const localAdapter: AuthService = {
  mode: "local",
  current: async () => local.current(),
  subscribe(listener) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },
  async register(name, email, password) {
    return local.register(name, email, password);
  },
  async login(email, password) {
    const p = await local.login(email, password);
    if (p.verified) emit("SIGNED_IN", p);
    return p;
  },
  async verify(id) {
    const p = local.verify(id);
    emit("SIGNED_IN", p);
    return p;
  },
  async resendVerification() {
    throw new Error("Local accounts use simulated verification.");
  },
  async reset(email, password) {
    if (!password) throw new Error("Enter a new password.");
    await local.reset(email, password);
  },
  async updatePassword() {
    throw new Error("Use the local password reset form.");
  },
  async demo() {
    const p = local.demo();
    emit("SIGNED_IN", p);
    return p;
  },
  async logout() {
    local.logout();
    emit("SIGNED_OUT", null);
  },
};
export let supabaseClient: SupabaseClient | null = null;
let selected: AuthService = localAdapter;
export let authConfigurationError = "";
try {
  const config = readAuthConfig(import.meta.env || {});
  if (config.mode === "supabase") {
    const client = createClient(config.url, config.key, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        flowType: "implicit",
      },
    });
    supabaseClient = client;
    selected = createSupabaseAuth(
      client,
      () =>
        Capacitor.isNativePlatform() ? "https://www.sportzlabs.com/workoutstudio/" : new URL(import.meta.env.BASE_URL || "./", window.location.href).href,
    );
  }
} catch (error) {
  authConfigurationError = (error as Error).message;
}
export const auth = selected;
