import { useEffect, useState } from 'react';
import { auth } from './auth';
import { repository } from './repository';
import { stravaRequest, type StravaStatus } from './strava';
import { DATA_CHANGED, STRAVA_CHANGED, syncCompletedSession } from './stravaSync';
export function useStravaSync(userId:string){
 const [connected,setConnected]=useState(()=>{try{return localStorage.getItem(`workoutstudio:strava-connected:${userId}`)==='true';}catch{return false;}});
 useEffect(()=>{
  if(auth.mode!=='supabase')return;
  let alive=true;
  const status=()=>{void stravaRequest<StravaStatus>({action:'status'},userId).then(s=>{if(alive){setConnected(s.connected&&s.configured);try{localStorage.setItem(`workoutstudio:strava-connected:${userId}`,String(s.connected&&s.configured));}catch{}}}).catch(()=>{});};
  const flush=()=>{if(!alive)return;try{for(const s of repository.load(userId).sessions){if(s.stravaUpload?.state==='pending')void syncCompletedSession(userId,s.id).catch(()=>{});}}catch{/* Existing storage error is shown by Studio. */}};
  const changed=()=>{status();flush();};
  status();flush();
  const timer=setInterval(flush,30000);
  window.addEventListener('online',changed);window.addEventListener('focus',changed);window.addEventListener(DATA_CHANGED,flush);window.addEventListener(STRAVA_CHANGED,status);
  return()=>{alive=false;clearInterval(timer);window.removeEventListener('online',changed);window.removeEventListener('focus',changed);window.removeEventListener(DATA_CHANGED,flush);window.removeEventListener(STRAVA_CHANGED,status);};
 },[userId]);
 return connected;
}
