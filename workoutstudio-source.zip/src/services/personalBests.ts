import {metricMode} from '../data/exerciseProfile';
import type {ActivityLog, Session} from '../data/types';

export type LocalPBKind='weight'|'reps'|'volume'|'estimatedMax'|'duration'|'distance';
export interface LocalPB {kind:LocalPBKind;label:string;value:number;unit:'kg'|'reps'|'kg·reps'|'s'|'km'}
const excluded=/assisted|assistance|band|push[ -]?up|pull[ -]?up|chin[ -]?up|dip\b|bodyweight|body weight|olympic|snatch|clean\b|jerk\b|jump|swing|throw|plyo/i;
const add=(out:Map<LocalPBKind,number>,kind:LocalPBKind,value:number)=>{if(Number.isFinite(value)&&value>0)out.set(kind,Math.max(out.get(kind)||0,value));};
function values(a:ActivityLog){
 const rows=a.rows.filter(r=>r.done),out=new Map<LocalPBKind,number>(); if(!rows.length)return out;
 const mode=metricMode(a);
 if(a.type==='strength'&&mode==='reps_weight'){
  add(out,'weight',Math.max(...rows.map(r=>r.weight))); add(out,'reps',Math.max(...rows.map(r=>r.reps)));
  add(out,'volume',rows.reduce((n,r)=>n+r.weight*r.reps,0));
  const estimates=rows.filter(r=>r.weight>0&&r.reps>=1&&r.reps<=10&&!excluded.test(a.name)).map(r=>r.reps===1?r.weight:r.weight*(1+r.reps/30));
  if(estimates.length)add(out,'estimatedMax',Math.max(...estimates));
 }else{
  if(rows.some(r=>r.time>0))add(out,'duration',rows.reduce((n,r)=>n+r.time,0));
  if(rows.some(r=>r.distance>0))add(out,'distance',rows.reduce((n,r)=>n+r.distance,0));
  if(rows.some(r=>r.reps>0))add(out,'reps',rows.reduce((n,r)=>n+r.reps,0));
 }
 return out;
}
const labels:Record<LocalPBKind,{label:string;unit:LocalPB['unit']}>={weight:{label:'Best weight',unit:'kg'},reps:{label:'Most reps',unit:'reps'},volume:{label:'Best volume',unit:'kg·reps'},estimatedMax:{label:'Best estimated 1RM',unit:'kg'},duration:{label:'Longest duration',unit:'s'},distance:{label:'Furthest distance',unit:'km'}};
export function exerciseRecord(history: Session[], session: Session, activity: ActivityLog) {
 const mode = metricMode(activity);
 const primary = mode === 'reps_weight' || mode === 'time_weight' ? 'weight' : mode === 'time_distance' ? 'distance' : 'time';
 const secondary = mode === 'reps_weight' || mode === 'time_reps' ? 'reps' : 'time';
 const rows = history.filter(s => s.id !== session.id && s.userId === session.userId && !s.sample && s.completedAt && Date.parse(s.completedAt) < Date.parse(session.startedAt))
  .flatMap(s => s.activities.filter(a => a.activityId === activity.activityId && metricMode(a) === mode).flatMap(a => a.rows))
  .filter(r => r.done && Number.isFinite(r[primary]) && Number.isFinite(r[secondary]) && (r[primary] > 0 || r[secondary] > 0));
 return rows.sort((a,b) => b[primary] - a[primary] || b[secondary] - a[secondary])[0];
}
export function personalBestsForActivity(history:Session[],session:Session,activity:ActivityLog){
 const current=values(activity),before=new Map<LocalPBKind,number>(),at=Date.parse(session.completedAt||'');
 for(const old of history)if(old.id!==session.id&&!old.sample&&old.completedAt&&Date.parse(old.completedAt)<at)
  for(const a of old.activities.filter(a=>a.activityId===activity.activityId))for(const [kind,value] of values(a))before.set(kind,Math.max(before.get(kind)||0,value));
 return [...current].filter(([kind,value])=>!before.has(kind)||value>before.get(kind)!+0.000001).map(([kind,value])=>({kind,label:labels[kind].label,value:Math.round(value*10)/10,unit:labels[kind].unit}));
}
export function personalBestCountForSession(history:Session[],session:Session){
 return session.activities.reduce((count,activity)=>count+(personalBestsForActivity(history,session,activity).length?1:0),0);
}
