import {exerciseGroups} from '../supabase/functions/strava/catalog';
import {startSession} from './services/startSession';
import {addSessionExercise, saveSessionRoutine} from './services/sessionRoutine';
import {useProAccess} from './services/useProAccess';
import {personalBestsForActivity,personalBestCountForSession} from './services/personalBests';
import ProProgression from './components/ProProgression';
import ProInsights from './components/ProInsights';
import {metricMode,exerciseProfile} from './data/exerciseProfile';
import ExerciseOrder, { moveExercise } from "./components/ExerciseOrder";
import { formatTime } from "./components/NumberFields";
import HeartRateDevice from "./components/HeartRateDevice";
import { useEffect, useRef, useState } from "react";
import {
  Plus,
  Home,
  Dumbbell,
  Timer,
  Library,
  Play,
  ChevronRight,
  Activity as Pulse,
  Flame,
  ArrowLeft,
  Search,
  Pencil,
  Check,
  TrendingUp,
  TrendingDown,
  Minus,
  LogOut,
  CheckCircle2,
} from "lucide-react";
import { SensorSummary } from "./components/SensorPanel";
import { useSensors } from "./services/useSensors";
import { appendSensorSample } from "./services/sensors";
import { useStravaSync } from "./services/useStravaSync";
import {
  DATA_CHANGED,
  prepareCompletedSession,
  syncCompletedSession,
  sharingPreferences,
} from "./services/stravaSync";
import StravaPanel, { StravaCallback } from "./components/StravaPanel";
import BodyMap from "./components/BodyMap";
import SwipeRow from "./components/SwipeRow";
import Modal from "./components/Modal";
import AuthScreen from "./components/AuthScreen";
import {
  ActivityForm,
  ActivityPicker,
  ActivityIcon,
  TargetFields,
  LibraryItem,
} from "./components/ActivityForms";
import SessionView, { performance } from "./components/SessionView";
import {
  Activity,
  Profile,
  Session,
  Template,
  UserData,
  uid,
  labels,
} from "./data/types";
import { library } from "./data/seed";
import {cachedCatalog,loadCatalog,trackUsage} from "./services/platform";
import {
  completedRows,
  volume,
  intensity,
  duration,
  previousLog,
  trend,
} from "./data/metrics";
import { auth, authConfigurationError } from "./services/auth";
import { useAuthSession } from "./services/useAuthSession";
import PasswordRecovery from "./components/PasswordRecovery";
import { repository } from "./services/repository";
import {
  CLOUD_SYNC_CHANGED,
  cloudWorkoutSyncEnabled,
  cloudWorkoutSyncStatus,
  initializeCloudWorkoutSync,
  syncCloudWorkoutsNow,
  type CloudSyncStatus,
} from "./services/workoutCloudSync";
import { useWorkoutTools } from "./services/webmcp";

type Tab = "Home" | "Workouts" | "Session" | "Library";
type DialogState =
  | { kind: "workout"; template?: Template }
  | { kind: "picker"; sessionId?: string }
  | { kind: "routine"; sessionId: string }
  | {
      kind: "activity";
      activity?: Activity;
      initialName?: string;
      addToWorkout?: boolean;
      sessionId?: string;
    }
  | { kind: "account" }
  | { kind: "devices" }
  | {
      kind: "confirm";
      title: string;
      message: string;
      action: () => void;
      button?: string;
    }
  | null;

function AppSplash() {
  return (
    <main className="loading-splash" role="status" aria-label="Loading Workout Studio">
      <div className="splash-brand" aria-hidden="true">
        <svg viewBox="0 0 48 48" fill="none">
          <path d="M10 14 34 38M5 19l10-10M9 23l10-10M29 43l10-10M33 47l10-10" />
        </svg>
        <span className="splash-wordmark"><strong>Workout</strong>Studio</span>
      </div>
      <div className="splash-copy">
        <p className="splash-kicker">A little stronger. Every day.</p>
        <h1>Make every<br />rep count.</h1>
        <p className="splash-tagline">Your workouts, your progress,<br />your own pace.</p>
      </div>
      <div className="splash-bars" aria-hidden="true">
        <i /><i /><i /><i /><i /><i /><i />
      </div>
      <span className="sr-only">Restoring your session and workouts…</span>
    </main>
  );
}
const dateLabel = (date: string) =>
  new Date(date).toLocaleDateString("en-AU", {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
const timeLabel = (date: string) =>
  new Date(date).toLocaleTimeString("en-AU", {
    hour: "numeric",
    minute: "2-digit",
  });
export default function App() {
  const session = useAuthSession();
  const [logoutError, setLogoutError] = useState("");
  if(window.opener && new URLSearchParams(window.location.search).has("state") && /[?&](code|error)=/.test(window.location.search))return <StravaCallback />;
  if (authConfigurationError)
    return (
      <main className="recovery-layout">
        <section className="panel">
          <h2>Sign-in configuration needs attention</h2>
          <p className="error" role="alert">
            {authConfigurationError}
          </p>
          <p className="muted">
            Check the Supabase configuration and restart the app.
          </p>
        </section>
      </main>
    );
  if (session.loading) return <AppSplash />;
  if (session.recovery && session.user)
    return (
      <PasswordRecovery
        onDone={session.clearRecovery}
        onCancel={session.logout}
      />
    );
  return session.user ? (
    <>
      {logoutError && (
        <div className="notice" role="alert">
          {logoutError}
        </div>
      )}
      <StravaCallback />
      <Studio
        key={session.user.id}
        user={session.user}
        onLogout={() => {
          setLogoutError("");
          void session
            .logout()
            .catch((e) => setLogoutError((e as Error).message));
        }}
      />
    </>
  ) : (
    <AuthScreen
      onLogin={session.setUser}
      initialMode={session.recovery ? "reset" : "login"}
      initialError={
        session.error ||
        (session.recovery
          ? "Your reset link is invalid or expired. Request a new link below."
          : "")
      }
    />
  );
}
function Studio({ user, onLogout }: { user: Profile; onLogout: () => void }) {
  const pro = useProAccess(user.id);
  const [loadError, setLoadError] = useState("");
  const [syncReady, setSyncReady] = useState(!cloudWorkoutSyncEnabled());
  const [cloudStatus, setCloudStatus] = useState<CloudSyncStatus>(() => cloudWorkoutSyncStatus(user.id));
  const [data, setData] = useState<UserData | null>(() => {
    try {
      return repository.load(user.id);
    } catch {
      return null;
    }
  });
  const [catalog,setCatalog] = useState(cachedCatalog);
  useEffect(()=>{ let active=true; const refresh=()=>{void loadCatalog().then(c=>{if(active)setCatalog(c);}).catch(()=>{});}; refresh(); window.addEventListener("focus",refresh); return()=>{active=false;window.removeEventListener("focus",refresh);}; },[user.id]);
  const [tab, setTab] = useState<Tab>("Home");
  useEffect(()=>{trackUsage("page:"+tab);},[tab]);
  const [editing, setEditing] = useState<string | null>(null);
  const [detail, setDetail] = useState<string | null>(null);
  const [justCompleted, setJustCompleted] = useState<string | null>(null);
  const [dialog, setDialog] = useState<DialogState>(null);
  useEffect(()=>{if(dialog && ["account","devices","workout","activity","picker"].includes(dialog.kind))trackUsage("feature:"+dialog.kind);},[dialog?.kind]);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [categoryFilter,setCategoryFilter]=useState("all");
  const [notice, setNotice] = useState("");
  const [passkeyMessage, setPasskeyMessage] = useState("");
  const [passkeyError, setPasskeyError] = useState("");
  const [passkeyBusy, setPasskeyBusy] = useState(false);
  const dataRef = useRef(data);
  dataRef.current = data;
  useEffect(() => {
    if (!cloudWorkoutSyncEnabled()) return;
    let active = true;
    const changed = (event: Event) => {
      const detail = (event as CustomEvent<{ userId: string; status: CloudSyncStatus }>).detail;
      if (detail?.userId === user.id) setCloudStatus(detail.status);
    };
    window.addEventListener(CLOUD_SYNC_CHANGED, changed);
    void (async () => {
      const local = repository.load(user.id);
      const hydrated = await initializeCloudWorkoutSync(user.id, local, user.email);
      if (!active) return;
      dataRef.current = hydrated;
      setData(hydrated);
      setSyncReady(true);
      setCloudStatus(cloudWorkoutSyncStatus(user.id));
    })().catch((error) => {
      if (!active) return;
      setNotice((error as Error).message);
      setSyncReady(true);
    });
    return () => {
      active = false;
      window.removeEventListener(CLOUD_SYNC_CHANGED, changed);
    };
  }, [user.id]);
  const stravaConnected = useStravaSync(user.id);
  const sensors = useSensors(user.id, (sample) => {
    const latest = dataRef.current;
    const active = latest?.activeSession;
    if (!latest || !active) return true;
    try {
      const samples = appendSensorSample(active.sensorSamples || [], {
        ...sample,
        exerciseId: active.trackingExerciseId || null,
      });
      if (samples === active.sensorSamples) return true;
      return save({
        ...latest,
        activeSession: { ...active, sensorSamples: samples },
      });
    } catch (e) {
      setNotice((e as Error).message);
      return false;
    }
  });
  useEffect(() => {
    const reload = () => {
      try {
        const latest = repository.load(user.id);
        dataRef.current = latest;
        setData(latest);
      } catch {
        setNotice("Could not reload saved workouts.");
      }
    };
    window.addEventListener(DATA_CHANGED, reload);
    return () => window.removeEventListener(DATA_CHANGED, reload);
  }, [user.id]);
  function trackExercise(id: string | null) {
    const latest = dataRef.current;
    if (latest?.activeSession)
      save({
        ...latest,
        activeSession: { ...latest.activeSession, trackingExerciseId: id },
      });
  }
  useWorkoutTools(data);
  function save(next: UserData) {
    if (!syncReady) return false;
    try {
      repository.save(user.id, next);
      dataRef.current = next;
      setData(next);
      return true;
    } catch {
      setNotice(
        "Could not save. Your browser storage may be full or unavailable. Free space before continuing.",
      );
      return false;
    }
  }
  if (!syncReady)
    return <AppSplash />;
  if (!data)
    return (
      <div className="auth-form panel">
        <h2>Couldn’t open your saved data</h2>
        <p className="muted">
          Your existing data has been preserved. Check that browser storage is
          available, then reload.
        </p>
        <button
          className="primary"
          onClick={() => {
            try {
              setData(repository.load(user.id));
            } catch (e) {
              setLoadError((e as Error).message);
            }
          }}
        >
          Try again
        </button>
        <p className="error">{loadError}</p>
        <button className="text-button" onClick={onLogout}>
          Sign out
        </button>
      </div>
    );
  const current = data;
  const activities = [...catalog, ...data.customActivities].map(exerciseProfile);
  const template = data.templates.find((t) => t.id === editing);
  const sessionDetail = data.sessions.find((s) => s.id === detail);
  const sorted = [...data.sessions].sort(
    (a, b) => +new Date(b.completedAt!) - +new Date(a.completedAt!),
  );
  const now = new Date();
  const monday = new Date(now);
  monday.setHours(0, 0, 0, 0);
  monday.setDate(now.getDate() - ((now.getDay() + 6) % 7));
  const week = sorted.filter((s) => +new Date(s.completedAt!) >= +monday);
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(d.getDate() + i);
    return d;
  });
  function go(next: Tab) {
    setTab(next);
    setDetail(null);
    if (next !== "Workouts") setEditing(null);
    setQuery("");
    window.scrollTo(0, 0);
  }
  function confirm(
    title: string,
    message: string,
    action: () => void,
    button = "Delete",
  ) {
    setDialog({ kind: "confirm", title, message, action, button });
  }
  function removeTemplate(t: Template) {
    confirm(
      "Delete workout?",
      `“${t.name}” will be removed. Completed sessions will stay in your history.`,
      () =>
        save({
          ...current,
          templates: current.templates.filter((x) => x.id !== t.id),
        }),
    );
  }
  function removeCustom(a: Activity) {
    const used = current.templates.some((t) =>
      t.activities.some((x) => x.activityId === a.id),
    );
    confirm(
      "Delete custom activity?",
      `“${a.name}” will be removed from your library${used ? " and workout templates" : ""}. Saved session history will be preserved.`,
      () =>
        save({
          ...current,
          customActivities: current.customActivities.filter(
            (x) => x.id !== a.id,
          ),
          templates: current.templates.map((t) => ({
            ...t,
            activities: t.activities.filter((x) => x.activityId !== a.id),
          })),
        }),
    );
  }
  function updateTemplate(next: Template) {
    return save({
      ...current,
      templates: current.templates.map((t) => (t.id === next.id ? next : t)),
    });
  }
  function addActivity(a: Activity) {
    if (dialog?.kind === 'picker' && dialog.sessionId) {
      const latest = dataRef.current;
      if (latest?.activeSession?.id === dialog.sessionId && save({...latest, activeSession: addSessionExercise(latest.activeSession, a, latest.sessions)})) setDialog(null);
      return;
    }
    if (!template) return;
    if (
      updateTemplate({
        ...template,
        activities: [
          ...template.activities,
          { id: uid(), activityId: a.id, targets: { ...a.defaults } },
        ],
      })
    )
      setDialog(null);
  }
  function start(t: Template) {
    if (current.activeSession) {
      setNotice(
        "You already have a session in progress. Finish or discard it before starting another.",
      );
      go("Session");
      return;
    }
    if (!t.activities.length) {
      setNotice("Add at least one activity before starting.");
      return;
    }
    if(t.activities.some(ta=>!activities.some(a=>a.id===ta.activityId))){setNotice("Some exercises are not available yet. Reconnect to refresh the exercise catalogue before starting this workout.");return;}
    const s = startSession(t, activities, current.sessions, user.id);
    if (save({ ...current, activeSession: s, templates:current.templates.map(saved=>saved.id===t.id?{...saved,activities:saved.activities.map(a=>({...a,useTargetsNextSession:false,progressionPreviousTargets:undefined}))}:saved) })) {trackUsage("workout:started",s.id+":started",user.id);if(s.activities.some(a=>a.previousSessionId))trackUsage("workout:previous-values-used",s.id+":previous-values",user.id);go("Session");}
  }
  function finish() {
    const s = current.activeSession;
    if (!s) return;
    const incomplete = s.activities.reduce(
      (n, a) => n + a.rows.filter((r) => !r.done).length,
      0,
    );
    confirm(
      "Finish your workout?",
      `${completedRows(s).length} completed sets will be saved.${incomplete ? ` ${incomplete} unchecked sets will be recorded as skipped.` : ""}${stravaConnected && sharingPreferences(user.id).autoUpload ? " This workout will upload to Strava automatically when saved." : ""}`,
      () => {
        const latest = dataRef.current;
        if (!latest?.activeSession || latest.activeSession.id !== s.id) return;
        const done = prepareCompletedSession(
          {
            ...latest.activeSession,
            trackingExerciseId: null,
            completedAt: new Date().toISOString(),
          },
          stravaConnected,
          sharingPreferences(user.id),
        );
        if (
          save({
            ...latest,
            sessions: [done, ...latest.sessions],
            activeSession: null,
          })
        ) {
          go("Home");
          setDetail(done.id);
          setJustCompleted(done.id);
          trackUsage("workout:completed",done.id+":completed",user.id);
          if(done.stravaUpload){
            trackUsage("strava:upload-queued",done.id+":strava-queued",user.id);
            void syncCompletedSession(user.id,done.id).catch(()=>{});
          }
          window.dispatchEvent(new Event(DATA_CHANGED));
        }
      },
      "Save workout",
    );
  }
  const plusLabel = "Create workout";
  function plus() {
    go("Workouts");
    setDialog({ kind: "workout" });
  }
  const workoutList = (select = false) => (
    <div className="workout-list">
      {data.templates.map((t, index) => {
        const content = (
          <button
            className="workout-card"
            onClick={() => (select ? start(t) : setEditing(t.id))}
          >
            <div className={`workout-marker marker-${index % 4}`}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <Dumbbell size={26} />
            </div>
            <div>
              <h3>{t.name}</h3>
              <p className="muted small">
                {t.description || "Your training, your way"}
              </p>
              <span className="workout-meta">
                {t.activities.length} activities ·{" "}
                {t.activities.reduce((n, a) => n + a.targets.sets, 0)} sets
              </span>
            </div>
            {select ? <Play size={21} /> : <ChevronRight size={20} />}
          </button>
        );
        return select ? (
          <div key={t.id}>{content}</div>
        ) : (
          <SwipeRow
            key={t.id}
            label={t.name}
            onDelete={() => removeTemplate(t)}
          >
            {content}
          </SwipeRow>
        );
      })}
      {!data.templates.length && (
        <Empty
          title="Your routine starts here"
          text="Use the + in the header to create your first workout."
        />
      )}
    </div>
  );
  return (
    <div className="app-shell">
      <header>
        <button
          className="icon-button"
          aria-label={plusLabel}
          title={plusLabel}
          onClick={plus}
        >
          <Plus />
        </button>
        <a
          className="brand"
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            go("Home");
          }}
        >
          Workout<span>Studio</span>
          <i />
        </a>
        <button
          className="avatar"
          aria-label="Account settings"
          onClick={() => setDialog({ kind: "account" })}
        >
          {user.name[0]?.toUpperCase() || "U"}
        </button>
      </header>
      <main>
        {notice && (
          <div className="notice" role="alert">
            <span>{notice}</span>
            <button aria-label="Dismiss message" onClick={() => setNotice("")}>
              ×
            </button>
          </div>
        )}
        {tab === "Home" && !sessionDetail && (
          <>
            <div className="page-intro">
              <div>
                <p className="eyebrow">YOUR TRAINING, IN FOCUS</p>
                <h1>Every session counts.</h1>
                <p className="muted">
                  Hello, {user.name.split(" ")[0]}. Keep showing up.
                </p>
              </div>
              <span className="date-chip">
                {now
                  .toLocaleDateString("en-AU", {
                    month: "long",
                    year: "numeric",
                  })
                  .toUpperCase()}
              </span>
            </div>
            <div className="dashboard-grid">
              <section className="hero-card">
                <div className="hero-top">
                  <span className="pill">
                    <Flame size={15} />
                    {data.activeSession
                      ? "SESSION IN PROGRESS"
                      : "READY WHEN YOU ARE"}
                  </span>
                  <Dumbbell size={28} />
                </div>
                <h2>
                  {data.activeSession ? (
                    <>
                      Pick up where <br />
                      you left off.
                    </>
                  ) : (
                    <>
                      Your next <br />
                      stronger self.
                    </>
                  )}
                </h2>
                <p>
                  {data.activeSession
                    ? data.activeSession.name
                    : "One workout. One set. One step forward."}
                </p>
                <button className="primary" onClick={() => go("Session")}>
                  <Play size={18} fill="currentColor" />
                  {data.activeSession ? "Resume workout" : "Start a workout"}
                </button>
                <div className="hero-stripes" />
              </section>
              <section className="overview panel">
                <div className="section-title">
                  <h3>This week</h3>
                  <Pulse size={20} />
                </div>
                <div className="stat-grid">
                  <div>
                    <strong>{week.length}</strong>
                    <span>sessions</span>
                  </div>
                  <div>
                    <strong>
                      {week.reduce((n, s) => n + duration(s), 0)}
                      <span>m</span>
                    </strong>
                    <span>time invested</span>
                  </div>
                </div>
                <div className="week-strip">
                  {days.map((d, i) => {
                    const done = week.some(
                      (s) =>
                        new Date(s.completedAt!).toDateString() ===
                        d.toDateString(),
                    );
                    return (
                      <div key={i} className={done ? "trained" : ""}>
                        <span>{"MTWTFSS"[i]}</span>
                        <i title={dateLabel(d.toISOString())}>
                          {done ? "✓" : "·"}
                        </i>
                      </div>
                    );
                  })}
                </div>
                <p className="muted small">Make space for a little progress.</p>
              </section>
            </div>
            {pro.insights && <ProInsights sessions={data.sessions} userId={user.id} request={pro.request}/>}
            <div className="section-title history-title">
              <div>
                <p className="eyebrow">THE WORK YOU PUT IN</p>
                <h2>Recent sessions</h2>
              </div>
              <span className="count">{sorted.length} sessions</span>
            </div>
            {user.id === "demo" && (
              <p className="demo-inline">
                Demo workspace · Example sessions are labeled below.
              </p>
            )}
            <div className="history-list">
              {sorted.map((s) => {
                const personalBestCount = pro.insights && !s.sample ? personalBestCountForSession(current.sessions, s) : 0;
                return (
                <SwipeRow
                  key={s.id}
                  label={`${s.name} session`}
                  onDelete={() =>
                    confirm(
                      "Delete completed session?",
                      `This removes “${s.name}” from history and future comparisons.`,
                      () =>
                        save({
                          ...current,
                          sessions: current.sessions.filter(
                            (x) => x.id !== s.id,
                          ),
                        }),
                    )
                  }
                >
                  <button
                    className="session-card"
                    onClick={() => {
                      setDetail(s.id);
                      window.scrollTo(0, 0);
                    }}
                  >
                    <div className="session-icon">
                      <Dumbbell />
                    </div>
                    <div className="session-copy">
                      <span className="small muted">
                        {dateLabel(s.completedAt!)} ·{" "}
                        {timeLabel(s.completedAt!)}
                        {s.sample ? " · Example" : ""}
                      </span>
                      <h3>{s.name}</h3>
                      <div className="session-metrics">
                        <span>
                          <Timer size={14} />
                          {duration(s)} min
                        </span>
                        <span>{completedRows(s).length} sets</span>
                        <span>{volume(s).toLocaleString()} kg</span>
                        {personalBestCount>0&&<span className="session-pb-count">🏅 {personalBestCount} PB{personalBestCount===1?'':'s'}</span>}
                      </div>
                    </div>
                    <BodyMap values={intensity(s)} />
                    <ChevronRight size={18} />
                  </button>
                </SwipeRow>
                );
              })}
            </div>
            {!sorted.length && (
              <Empty
                title="Your story is just getting started"
                text="Complete your first workout to see your progress here."
              />
            )}
            <div className="training-note">
              <TrendingUp size={18} />
              <p>Progress is built one session at a time.</p>
            </div>
          </>
        )}
        {tab === "Home" && sessionDetail && (
          <>
            <button
              className="back-button"
              onClick={() => {
                setDetail(null);
                setJustCompleted(null);
              }}
            >
              <ArrowLeft size={18} />
              All sessions
            </button>
            {justCompleted === sessionDetail.id && (
              <div className="completion-banner">
                <CheckCircle2 size={24} />
                <div>
                  <b>Workout complete. Well done.</b>
                  <p>Your work is saved. Take a moment to recover.</p>
                </div>
              </div>
            )}
            <div className="page-intro">
              <div>
                <p className="eyebrow">
                  {dateLabel(sessionDetail.completedAt!)} ·{" "}
                  {timeLabel(sessionDetail.completedAt!)}
                </p>
                <h1>{sessionDetail.name}</h1>
              </div>
            </div>
            {sessionDetail.addedDuringSession && <div className="session-routine"><p>Keep this workout for next time.</p><button className="secondary" onClick={() => setDialog({kind: 'routine', sessionId: sessionDetail.id})}>Save as new routine</button></div>}
            <div className="detail-summary panel">
              <div>
                <h3>Your session, at a glance</h3>
                <div className="detail-stats">
                  <div>
                    <strong>
                      {duration(sessionDetail)}
                      <small>min</small>
                    </strong>
                    <span>Duration</span>
                  </div>
                  <div>
                    <strong>{completedRows(sessionDetail).length}</strong>
                    <span>Done sets</span>
                  </div>
                  <div>
                    <strong>
                      {volume(sessionDetail).toLocaleString()}
                      <small>kg</small>
                    </strong>
                    <span>Lifted</span>
                  </div>
                </div>
                <p className="small muted">
                  Completed work only · Relative intensity
                </p>
                <div className="intensity-legend">
                  <i />
                  Light
                  <i />
                  Moderate
                  <i />
                  High
                </div>
              </div>
              <BodyMap values={intensity(sessionDetail)} large />
            </div>
            <StravaPanel
              key={sessionDetail.id}
              session={sessionDetail}
              userId={user.id}
            />
            <SensorSummary session={sessionDetail} />
            <div className="worked-tags">
              {Object.keys(intensity(sessionDetail)).map((tag) => (
                <span key={tag}>{tag}</span>
              ))}
            </div>
            <div className="section-title history-title">
              <h2>Exercise breakdown</h2>
            </div>
            <p className="small muted comparison-note">
              Compared with the previous completed session for each exercise.
              Strength uses total volume; cardio uses seconds + kilometres × 60;
              stretching uses seconds × count. This is a training estimate.
            </p>
            <div className="history-list">
              {sessionDetail.activities.map((a) => {
                const t = trend(
                  a,
                  previousLog(
                    current.sessions,
                    a.activityId,
                    sessionDetail.startedAt,
                    sessionDetail.id,
                  ),
                );
                const personalBests = pro.insights ? personalBestsForActivity(current.sessions, sessionDetail, a) : [];
                return (
                  <section className="detail-exercise panel" key={a.id}>
                    <div className="section-title">
                      <h3>{a.name}{personalBests.length>0&&<span className="pb-medal" title="Personal best achieved">🏅 PB</span>}</h3>
                      <span className={`trend ${t.direction}`}>
                        {t.direction === "up" ? (
                          <TrendingUp size={15} />
                        ) : t.direction === "down" ? (
                          <TrendingDown size={15} />
                        ) : (
                          <Minus size={15} />
                        )}{" "}
                        {t.label}
                      </span>
                    </div>
                    {personalBests.length>0&&<p className="pb-callout">Personal best{personalBests.length>1?'s':''}: {personalBests.map(pb=>`${pb.label} ${pb.value} ${pb.unit}`).join(' · ')}</p>}
                    <p className="planned">
                      Planned: {a.planned.sets} sets ·{" "}
                      {a.type === "strength"
                        ? `${a.planned.reps} reps × ${a.planned.weight} kg`
                        : a.type === "cardio"
                          ? `${formatTime(a.planned.time)} · ${a.planned.distance} km`
                          : `${formatTime(a.planned.time)} × ${a.planned.reps}`}
                    </p>
                    {a.rows.map((r, i) => (
                      <div
                        className={`completed-row ${r.done ? "" : "skipped"}`}
                        key={r.id}
                      >
                        <span className="row-check">
                          {r.done ? <Check size={16} /> : <Minus size={16} />}
                        </span>
                        <span>
                          {a.type === "cardio" ? "Round" : "Set"} {i + 1}
                        </span>
                        <b>{performance(a, r)}</b>
                        <small>{r.done ? "Done" : "Skipped"}</small>
                      </div>
                    ))}
                  </section>
                );
              })}
            </div>
          </>
        )}
        {tab === "Workouts" && !template && (
          <>
            <div className="page-intro">
              <div>
                <p className="eyebrow">A PLAN TO BUILD ON</p>
                <h1>Your workouts</h1>
                <p className="muted">
                  A little structure. A lot of possibility.
                </p>
              </div>
              <span className="date-chip">
                {data.templates.length} TEMPLATES
              </span>
            </div>
            {workoutList()}
            <p className="hint">
              Use + to create a workout. Swipe left for options.
            </p>
          </>
        )}
        {tab === "Workouts" && template && (
          <>
            <button className="back-button" onClick={() => setEditing(null)}>
              <ArrowLeft size={18} />
              All workouts
            </button>
            <div className="page-intro">
              <div>
                <p className="eyebrow">WORKOUT TEMPLATE</p>
                <h1>{template.name}</h1>
                <p className="muted">{template.description}</p>
              </div>
              <button
                className="icon-button"
                aria-label="Edit workout details"
                onClick={() => setDialog({ kind: "workout", template })}
              >
                <Pencil size={18} />
              </button>
            </div>
            <button
              className="primary full start-template"
              disabled={!template.activities.length}
              onClick={() => start(template)}
            >
              <Play size={18} />
              Start this workout
            </button>
            {pro.progression && <ProProgression key={template.id} template={template} activities={activities} sessions={data.sessions} userId={user.id} request={pro.request} onSave={next=>{const latest=dataRef.current;if(!latest||latest.templates.find(t=>t.id===template.id)!==template)return false;return save({...latest,templates:latest.templates.map(t=>t.id===next.id?next:t)});}}/>}
            <div className="section-title history-title">
              <h2>The lineup</h2>
              <span className="count">
                {template.activities.length} activities
              </span>
            </div>
            <div className="history-list">
              {template.activities.map((ta, i) => {
                const a = activities.find((x) => x.id === ta.activityId);
                if (!a) return null;
                return (
                  <SwipeRow
                    key={ta.id}
                    reorderItem
                    label={a.name}
                    onDelete={() =>
                      confirm(
                        "Remove activity?",
                        `Remove “${a.name}” from this workout?`,
                        () =>
                          updateTemplate({
                            ...template,
                            activities: template.activities.filter(
                              (x) => x.id !== ta.id,
                            ),
                          }),
                      )
                    }
                  >
                    <section className="template-activity">
                      <div className="log-heading">
                        <ExerciseOrder
                          name={a.name}
                          index={i}
                          total={template.activities.length}
                          onMove={(to) =>
                            updateTemplate({
                              ...template,
                              activities: moveExercise(
                                template.activities,
                                i,
                                to,
                              ),
                            })
                          }
                        />
                        <span className={`activity-icon ${a.type}`}>
                          <ActivityIcon type={a.type} />
                        </span>
                        <div>
                          <span className="eyebrow">
                            {i + 1} · {labels[a.type]}
                          </span>
                          <h3>{a.name}</h3>
                        </div>
                      </div>
                      <TargetFields
                        mode={metricMode(a)}
                        type={a.type}
                        value={ta.targets}
                        onChange={(targets) => {
                          const clean = {
                            ...targets,
                            sets: Math.min(
                              30,
                              Math.max(1, Math.floor(targets.sets)),
                            ),
                            reps: Math.max(0, targets.reps),
                            weight: Math.max(0, targets.weight),
                            time: Math.max(0, targets.time),
                            distance: Math.max(0, targets.distance),
                          };
                          updateTemplate({
                            ...template,
                            activities: template.activities.map((x) =>
                              x.id === ta.id ? { ...x, targets: clean } : x,
                            ),
                          });
                        }}
                      />
                    </section>
                  </SwipeRow>
                );
              })}
            </div>
            <button
              className="add-exercise-row"
              onClick={() => setDialog({ kind: "picker" })}
            >
              <Plus size={22} /> Add exercise
            </button>
            {!template.activities.length && (
              <Empty
                title="Make it your own"
                text="Use Add exercise below to choose an activity from the library."
              />
            )}
            <p className="hint">
              Drag the grip to reorder. Changes save automatically.
            </p>
          </>
        )}
        {tab === "Session" &&
          (data.activeSession ? (
            <SessionView
              session={data.activeSession}
              history={data.sessions}
              sensor={sensors}
              onDevices={() => setDialog({ kind: "devices" })}
              onTrack={trackExercise}
              onAddExercise={() => setDialog({kind: 'picker', sessionId: data.activeSession!.id})}
              onSaveRoutine={() => setDialog({kind: 'routine', sessionId: data.activeSession!.id})}
              onChange={(s) => {
                const latest = dataRef.current;
                if (latest?.activeSession?.id === s.id)
                  save({
                    ...latest,
                    activeSession: {
                      ...s,
                      sensorSamples: latest.activeSession.sensorSamples,
                      trackingExerciseId:
                        latest.activeSession.trackingExerciseId,
                    },
                  });
              }}
              onFinish={finish}
              onDiscard={() =>
                confirm(
                  "Discard this session?",
                  "Your current timer and unsaved performance will be removed.",
                  () => {if(save({ ...current, activeSession: null }))trackUsage("workout:discarded");},
                  "Discard",
                )
              }
            />
          ) : (
            <>
              <div className="page-intro">
                <div>
                  <p className="eyebrow">TIME FOR YOU</p>
                  <h1>Let’s get moving.</h1>
                  <p className="muted">
                    Choose a workout to start your session.
                  </p>
                </div>
              </div>
              {workoutList(true)}
            </>
          ))}
        {tab === "Library" && (
          <>
            <div className="page-intro">
              <div>
                <p className="eyebrow">FIND YOUR NEXT MOVEMENT</p>
                <h1>Activity library</h1>
                <p className="muted">
                  Good training starts with the right moves.
                </p>
              </div>
            </div>
            <div className="search-field">
              <Search size={18} />
              <input
                aria-label="Search activities"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search activities or body areas…"
              />
            </div>
            <button
              className="text-button"
              onClick={() =>
                setDialog({ kind: "activity", initialName: query.trim() })
              }
            >
              <Plus size={18} /> Create custom activity
            </button>
            <div className="library-filters">
              <div className="segmented">
                {["all", "custom"].map((f) => (
                  <button
                    aria-pressed={filter === f}
                    className={filter === f ? "selected" : ""}
                    key={f}
                    onClick={() => setFilter(f)}
                  >
                    {f === "all" ? "All activities" : "Custom"}
                  </button>
                ))}
              </div>
              <select
                aria-label="Filter activity type"
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
              >
                <option value="all">All types</option>
                {Object.entries(labels).map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
            <label>Strava exercise category<select value={categoryFilter} onChange={e=>setCategoryFilter(e.target.value)}><option value="all">All categories</option>{Object.keys(exerciseGroups).map(c=><option key={c}>{c}</option>)}</select></label>
            <div className="library-list">
              {activities
                .filter(
                  (a) =>
                    (filter === "all" || a.userId) &&
                    (typeFilter === "all" || a.type === typeFilter) &&
                    (categoryFilter==='all'||a.stravaCategory===categoryFilter) &&
                    `${a.name} ${a.stravaCategory||""} ${a.stravaSportType||""} ${a.tags.join(" ")}`
                      .toLowerCase()
                      .includes(query.toLowerCase()),
                )
                .map((a) =>
                  a.userId ? (
                    <SwipeRow
                      key={a.id}
                      label={a.name}
                      onDelete={() => removeCustom(a)}
                    >
                      <LibraryItem
                        activity={a}
                        onEdit={() =>
                          setDialog({ kind: "activity", activity: a })
                        }
                      />
                    </SwipeRow>
                  ) : (
                    <LibraryItem key={a.id} activity={a} onEdit={() => {}} />
                  ),
                )}
              {!activities.some(
                (a) =>
                  (filter === "all" || a.userId) &&
                  (typeFilter === "all" || a.type === typeFilter) &&
                    (categoryFilter==='all'||a.stravaCategory===categoryFilter) &&
                  `${a.name} ${a.stravaCategory||""} ${a.stravaSportType||""} ${a.tags.join(" ")}`
                    .toLowerCase()
                    .includes(query.toLowerCase()),
              ) && (
                <Empty
                  title="No activities here yet"
                  text="Try another search, or choose Create custom activity."
                />
              )}
            </div>
          </>
        )}
      </main>
      <nav aria-label="Main navigation">
        {[
          { name: "Home", Icon: Home },
          { name: "Workouts", Icon: Dumbbell },
          { name: "Session", Icon: Timer },
          { name: "Library", Icon: Library },
        ].map(({ name, Icon }) => (
          <button
            aria-current={tab === name ? "page" : undefined}
            className={tab === name ? "active" : ""}
            onClick={() => go(name as Tab)}
            key={name}
          >
            <span className="nav-icon">
              <Icon size={21} />
              {name === "Session" && data.activeSession && <i />}
            </span>
            <span>{name}</span>
          </button>
        ))}
      </nav>
      {dialog && (
        <Modal
          title={
            dialog.kind === "workout"
              ? dialog.template
                ? "Edit workout"
                : "Create workout"
              : dialog.kind === 'routine'
                ? 'Save as new routine'
              : dialog.kind === "picker"
                ? "Add an activity"
                : dialog.kind === "activity"
                  ? dialog.activity
                    ? "Edit activity"
                    : "Create an activity"
                  : dialog.kind === "account"
                    ? "Your account"
                    : dialog.kind === "devices"
                      ? "Heart-rate device"
                      : dialog.title
          }
          onClose={() => setDialog(null)}
        >
          {dialog.kind === 'routine' && <form onSubmit={e => {
            e.preventDefault();
            const latest = dataRef.current;
            const session = latest?.activeSession?.id === dialog.sessionId ? latest.activeSession : latest?.sessions.find(s => s.id === dialog.sessionId);
            const name = String(new FormData(e.currentTarget).get('name') || '').trim();
            if (!latest || !session || !name) return;
            if (save(saveSessionRoutine(latest, session, activities, name))) {setDialog(null); setNotice('New routine saved in Workouts.');}
          }}>
            <p className="muted">Save the exercise order and set counts. Targets use the first completed set of each exercise, or its first set if none are complete. Your original routine stays saved.</p>
            <label>Routine name<input name="name" required autoFocus maxLength={60} defaultValue={(data.activeSession?.id === dialog.sessionId ? data.activeSession : data.sessions.find(s => s.id === dialog.sessionId))?.name.slice(0,52) + ' (copy)'} /></label>
            <button className="primary full">Save routine</button>
          </form>}
          {dialog.kind === "workout" && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const f = new FormData(e.currentTarget);
                const name = String(f.get("name")).trim();
                if (!name) return;
                const t: Template = {
                  id: dialog.template?.id || uid(),
                  userId: user.id,
                  name,
                  description: String(f.get("description")).trim(),
                  createdAt:
                    dialog.template?.createdAt || new Date().toISOString(),
                  activities: dialog.template?.activities || [],
                };
                if (
                  save({
                    ...current,
                    templates: dialog.template
                      ? current.templates.map((x) => (x.id === t.id ? t : x))
                      : [...current.templates, t],
                  })
                ) {
                  setEditing(t.id);
                  setDialog(null);
                }
              }}
            >
              <label>
                Workout name
                <input
                  name="name"
                  autoFocus
                  required
                  maxLength={60}
                  defaultValue={dialog.template?.name}
                  placeholder="e.g. Upper body"
                />
              </label>
              <label>
                Goal or description
                <textarea
                  name="description"
                  maxLength={240}
                  defaultValue={dialog.template?.description}
                  placeholder="What are you working toward?"
                  rows={3}
                />
              </label>
              <button className="primary full">
                {dialog.template ? "Save changes" : "Create workout"}
              </button>
            </form>
          )}
          {dialog.kind === "picker" && (
            <ActivityPicker
              activities={activities}
              onChoose={addActivity}
              onCustom={(initialName) =>
                setDialog({ kind: "activity", initialName, addToWorkout: !dialog.sessionId, sessionId: dialog.sessionId })
              }
            />
          )}
          {dialog.kind === "activity" && (
            <ActivityForm
              userId={user.id}
              activity={dialog.activity}
              initialName={dialog.initialName}
              activities={activities}
              onSave={(a) => {
                const latest = dataRef.current;
                if (!latest) return;
                const next = {
                  ...latest,
                  customActivities: dialog.activity
                    ? latest.customActivities.map((x) =>
                        x.id === a.id ? a : x,
                      )
                    : [...latest.customActivities, a],
                };
                if (dialog.sessionId && latest.activeSession?.id === dialog.sessionId) next.activeSession = addSessionExercise(latest.activeSession, a, latest.sessions);
                if (dialog.addToWorkout && template)
                  next.templates = current.templates.map((t) =>
                    t.id === template.id
                      ? {
                          ...t,
                          activities: [
                            ...t.activities,
                            {
                              id: uid(),
                              activityId: a.id,
                              targets: { ...a.defaults },
                            },
                          ],
                        }
                      : t,
                  );
                if (save(next)) {trackUsage("exercise:custom-saved");setDialog(null);}
              }}
            />
          )}
          {dialog.kind === "confirm" && (
            <>
              <p className="muted confirm-message">{dialog.message}</p>
              <div className="dialog-actions">
                <button className="secondary" onClick={() => setDialog(null)}>
                  Cancel
                </button>
                <button
                  className={
                    dialog.button === "Save workout"
                      ? "primary"
                      : "danger-button"
                  }
                  onClick={() => {
                    dialog.action();
                    setDialog(null);
                  }}
                >
                  {dialog.button || "Delete"}
                </button>
              </div>
            </>
          )}
          {dialog.kind === "devices" && (
            <HeartRateDevice
              sensor={sensors}
              recording={Boolean(data.activeSession)}
            />
          )}
          {dialog.kind === "account" && (
            <>
              <div className="account-profile">
                <span className="avatar">{user.name[0]}</span>
                <div>
                  <h3>{user.name}</h3>
                  <p className="muted">{user.email}</p>
                </div>
              </div>
              <p className="muted account-copy">
                {auth.mode === "supabase"
                  ? cloudWorkoutSyncEnabled()
                    ? "Your login is secured by Supabase. Your workouts sync through Cloudflare and stay available on this device for offline use."
                    : "Your login is secured by Supabase. Your workouts are currently saved in this browser and separated by account."
                  : "This is a local prototype. Your workouts are saved in this browser and separated by account. Email verification and password reset are simulated."}
              </p>
              <p className="small muted">
                {auth.mode === "supabase"
                  ? cloudWorkoutSyncEnabled()
                    ? cloudStatus === "synced"
                      ? "Workout data is up to date in Cloudflare. Changes on the web and your iPhone will sync to this account."
                      : cloudStatus === "syncing"
                        ? "Syncing your workouts with Cloudflare…"
                        : cloudStatus === "offline"
                          ? "Saved on this device. Cloud sync will resume when you are online."
                          : cloudStatus === "error"
                            ? "Cloud sync needs attention. Your current workouts remain saved on this device."
                            : "Your workouts are saved in this browser until Cloudflare sync is configured."
                    : "Cloud workout sync is not connected yet. Clearing browser data removes local workouts, but your Supabase account remains."
                    : "Use Supabase Auth and database storage before a public SaaS launch. Clearing browser data removes local accounts and workouts."}
              </p>
              {auth.mode === "supabase" && cloudWorkoutSyncEnabled() && cloudStatus === "error" && (
                <button className="text-button" onClick={() => { if (dataRef.current) void syncCloudWorkoutsNow(user.id, dataRef.current); }}>
                  Try cloud sync again
                </button>
              )}
              {auth.mode === "supabase" && auth.passkeyAvailable() && (
                <>
                  <button
                    className="secondary full"
                    disabled={passkeyBusy}
                    onClick={() => {
                      setPasskeyError("");
                      setPasskeyMessage("");
                      setPasskeyBusy(true);
                      void auth.registerPasskey().then(() => {
                        setPasskeyMessage("Passkey added. You can now use it to sign in on this device.");
                      }).catch((error) => {
                        setPasskeyError((error as Error).message);
                      }).finally(() => setPasskeyBusy(false));
                    }}
                  >
                    {passkeyBusy ? "Setting up passkey…" : "Add a passkey"}
                  </button>
                  {passkeyError && <p className="error" role="alert">{passkeyError}</p>}
                  {passkeyMessage && <p className="success" role="status">{passkeyMessage}</p>}
                </>
              )}
              <button
                className="secondary full"
                onClick={() => setDialog({ kind: "devices" })}
              >
                Connect / test heart-rate device
              </button>
              <StravaPanel userId={user.id} />
              <button className="secondary full signout" onClick={onLogout}>
                <LogOut size={18} />
                Sign out
              </button>
            </>
          )}
        </Modal>
      )}
    </div>
  );
}
function Empty({ title, text }: { title: string; text: string }) {
  return (
    <div className="empty">
      <Dumbbell size={30} />
      <h3>{title}</h3>
      <p className="muted">{text}</p>
    </div>
  );
}
