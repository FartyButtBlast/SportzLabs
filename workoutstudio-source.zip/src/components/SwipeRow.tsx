import { ReactNode, useEffect, useRef, useState } from "react";
import { Trash2 } from "lucide-react";
export default function SwipeRow({
  children,
  onDelete,
  label,
  reorderItem = false,
}: {
  children: ReactNode;
  onDelete: () => void;
  label: string;
  reorderItem?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [offset, setOffset] = useState<number | null>(null);
  const root = useRef<HTMLDivElement>(null);
  const start = useRef<{
    x: number;
    y: number;
    offset: number;
    swiping: boolean;
  } | null>(null);
  const suppressClick = useRef(false);
  useEffect(() => {
    if (!open) return;
    const close = (e: PointerEvent) => {
      if (!root.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, [open]);
  return (
    <div
      ref={root}
      data-reorder-item={reorderItem ? "" : undefined}
      className={`swipe-row ${open || offset !== null ? "revealed" : ""}`}
      onKeyDown={(e) => {
        if (e.key === "Escape") {
          setOpen(false);
          setOffset(null);
        }
      }}
    >
      <button
        type="button"
        className="swipe-delete"
        aria-label={`Delete ${label}`}
        tabIndex={open ? 0 : -1}
        onClick={onDelete}
      >
        <Trash2 size={19} />
        Delete
      </button>
      <div
        className={`swipe-content ${offset !== null ? "swiping" : ""}`}
        style={
          offset === null ? undefined : { transform: `translateX(${offset}px)` }
        }
        onPointerDown={(e) => {
          suppressClick.current = false;
          if (
            e.pointerType === "mouse" ||
            !e.isPrimary ||
            (e.target as Element).closest(
              "input,textarea,select,.drag-handle,.row-menu",
            )
          )
            return;
          start.current = {
            x: e.clientX,
            y: e.clientY,
            offset: open ? -90 : 0,
            swiping: false,
          };
        }}
        onPointerMove={(e) => {
          const s = start.current;
          if (!s) return;
          const dx = e.clientX - s.x,
            dy = e.clientY - s.y;
          if (!s.swiping) {
            if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) {
              start.current = null;
              return;
            }
            if (Math.abs(dx) < 10 || Math.abs(dx) < Math.abs(dy)) return;
            s.swiping = true;
            e.currentTarget.setPointerCapture(e.pointerId);
          }
          suppressClick.current = true;
          setOffset(Math.max(-90, Math.min(0, s.offset + dx)));
        }}
        onPointerUp={(e) => {
          const s = start.current;
          start.current = null;
          if (s?.swiping) {
            setOpen(s.offset + e.clientX - s.x < -40);
            setOffset(null);
          }
          if (e.currentTarget.hasPointerCapture(e.pointerId))
            e.currentTarget.releasePointerCapture(e.pointerId);
        }}
        onPointerCancel={() => {
          start.current = null;
          setOffset(null);
        }}
        onClickCapture={(e) => {
          if (suppressClick.current) {
            e.preventDefault();
            e.stopPropagation();
            suppressClick.current = false;
          }
        }}
      >
        {children}
        <button
          type="button"
          className="row-menu"
          aria-label={`${open ? "Hide" : "Show"} delete for ${label}`}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <Trash2 size={19} />
        </button>
      </div>
    </div>
  );
}
