import { useEffect,useState } from 'react';
import { Bluetooth, Heart, Thermometer } from 'lucide-react';
import type { SensorController } from '../services/useSensors';
import type { Session } from '../data/types';
import { sensorSummary } from '../services/sensors';
export default function SensorPanel({sensor,session,onTrack}:{sensor:SensorController;session:Session;onTrack:(id:string|null)=>void}){
 const [now,setNow]=useState(Date.now());
 useEffect(()=>{const t=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(t);},[]);
 const hr=sensor.latest.hr, temp=sensor.latest.temp;
 const current=session.activities.find(a=>a.id===session.trackingExerciseId);
 return <section className="sensor-panel panel" aria-label="Live workout sensors">
  <div className="section-title"><h3><Heart size={18}/> Live sensors</h3><span className="small muted">{current?current.name:'Rest / unassigned'}</span></div>
  <p className="small muted">Readings are saved with the exercise you select below. Switch to Rest between exercises. Keep the app open and the screen awake while recording.</p>
  {!sensor.supported?<p className="sensor-help">Bluetooth isn’t available in this browser. Use Chrome on Android or the installed Workout Studio iPhone/Android app. Adding this website to the iPhone Home Screen does not enable Bluetooth.</p>:null}
  <div className="sensor-readings"><div><Heart size={22}/><strong>{hr&&now-hr.at<15000?hr.value:'—'}<small>bpm</small></strong><span>{sensor.heart.status==='connected'?(hr&&now-hr.at<15000?sensor.heart.name:'Waiting for a fresh heart-rate reading'):sensor.heart.status==='connecting'?'Connecting…':'Heart rate not connected'}</span></div><div><Thermometer size={22}/><strong>{temp&&now-temp.at<60000?temp.value.toFixed(1):'—'}<small>°C</small></strong><span>{temp&&now-temp.at<60000?`Sensor temperature · ${temp.location}`:'No fresh temperature reading'}</span></div></div>
  <div className="sensor-buttons"><button type="button" className="secondary" disabled={!sensor.supported||sensor.heart.status==='connecting'} onClick={()=>{void(sensor.heart.status==='connected'?sensor.disconnect('heartRate'):sensor.connect('heartRate'));}}><Bluetooth size={16}/>{sensor.heart.status==='connected'?'Disconnect heart rate':'Connect heart-rate sensor'}</button><button type="button" className="secondary" disabled={!sensor.supported||sensor.temperature.status==='connecting'} onClick={()=>{void(sensor.temperature.status==='connected'?sensor.disconnect('temperature'):sensor.connect('temperature'));}}>{sensor.temperature.status==='connected'?'Disconnect temperature':'Connect temperature sensor'}</button></div>
  {sensor.heart.error&&<p role="alert" className="error">{sensor.heart.error}</p>}{sensor.temperature.error&&<p role="alert" className="error">{sensor.temperature.error}</p>}
  <label className="sensor-tracking">Record readings against<select value={session.trackingExerciseId||''} onChange={e=>onTrack(e.target.value||null)}><option value="">Rest / unassigned</option>{session.activities.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
  <details className="sensor-guidance"><summary>Wahoo, Garmin and temperature compatibility</summary><p>Wear and wake your Wahoo Bluetooth chest strap before connecting. A Garmin fēnix must support Bluetooth heart-rate broadcasting and have Broadcast Heart Rate enabled. ANT+ alone cannot connect to this app.</p><p>Temperature requires a separate Bluetooth Health Thermometer sensor. A watch’s ambient or wrist temperature is not a core body-temperature measurement. Garmin watch temperature and Apple Watch’s overnight readings are not currently imported.</p><p>Sensor data stays with this browser or installed app. Heart-rate summaries are only shared to Strava if you enable that option in your account. Temperature is not shared.</p></details>
 </section>;
}
export function SensorSummary({session}:{session:Session}){
 const samples=session.sensorSamples||[];
 if(!samples.length)return null;
 const total=sensorSummary(samples);
 return <section className="sensor-panel panel"><h3>Heart rate by exercise</h3><p className="small muted">Sampled averages and peaks for the exercise selected at the time. Rest and missing signal are not assigned to an exercise. Heart rate can lag behind effort.</p>
 {total.average!==null&&<div className="sensor-summary-total"><strong>{total.average} <small>bpm average</small></strong><strong>{total.max} <small>bpm peak</small></strong><span>{total.count} samples</span></div>}
 <div className="sensor-table-wrap"><table className="sensor-table"><thead><tr><th>Exercise</th><th>Avg bpm</th><th>Peak bpm</th><th>Samples</th></tr></thead><tbody>{[...session.activities.map(a=>({id:a.id,name:a.name})),{id:null,name:'Rest / unassigned'}].map(a=>{const stats=sensorSummary(samples,a.id);return <tr key={a.id||'rest'}><th>{a.name}</th><td>{stats.average??'—'}</td><td>{stats.max??'—'}</td><td>{stats.count}</td></tr>;})}</tbody></table></div>
 {total.temperatureCount>0&&<p className="small muted">Sensor temperature average: {total.temperatureAverage?.toFixed(1)} °C ({total.temperatureCount} samples). Measurement locations: {[...new Set(samples.filter(s=>s.temperatureC!==undefined).map(s=>s.temperatureLocation||'Unspecified'))].join(', ')}. This is the sensor’s reported temperature, not an estimate of core body temperature.</p>}
 </section>;
}
