import ExerciseOrder, { moveExercise } from "./ExerciseOrder";
import { NumberField, DurationFields, formatTime } from "./NumberFields";
import SensorPanel from "./SensorPanel";
import type { SensorController } from "../services/useSensors";
import { useEffect, useState } from "react";
import { Check, Plus, Timer, Flag, Trash2 } from "lucide-react";
import { Session, SetRow, ActivityLog, uid } from "../data/types";
import { completedRows, previousLog } from "../data/metrics";
import { ActivityIcon } from "./ActivityForms";
export function performance(a: ActivityLog, r: SetRow) {
  return a.type === "strength"
    ? `${r.reps} × ${r.weight} kg`
    : a.type === "cardio"
      ? `${formatTime(r.time)} · ${r.distance} km`
      : `${formatTime(r.time)} × ${r.reps}`;
}
export default function SessionView({
  session,
  history,
  onChange,
  onFinish,
  onDiscard,
  sensor,
  onTrack,
  onDevices,
}: {
  session: Session;
  history: Session[];
  onChange: (s: Session) => void;
  onFinish: () => void;
  onDiscard: () => void;
  sensor: SensorController;
  onDevices: () => void;
  onTrack: (id: string | null) => void;
}) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const elapsed = Math.max(
    0,
    Math.floor((now - +new Date(session.startedAt)) / 1000),
  );
  const done = completedRows(session).length;
  const total = session.activities.reduce((n, a) => n + a.rows.length, 0);
  function rowChange(logId: string, rowId: string, patch: Partial<SetRow>) {
    onChange({
      ...session,
      activities: session.activities.map((a) =>
        a.id === logId
          ? {
              ...a,
              rows: a.rows.map((r) =>
                r.id === rowId ? { ...r, ...patch } : r,
              ),
            }
          : a,
      ),
    });
  }
  return (
    <>
      <div className="page-intro">
        <div>
          <p className="eyebrow">YOU SHOWED UP. NOW MAKE IT COUNT.</p>
          <h1>{session.name}</h1>
        </div>
      </div>
      <div className="session-status">
        <div>
          <Timer size={19} />
          <strong>
            {String(Math.floor(elapsed / 3600)).padStart(2, "0")}:
            {String(Math.floor((elapsed % 3600) / 60)).padStart(2, "0")}:
            {String(elapsed % 60).padStart(2, "0")}
          </strong>
        </div>
        <span>
          {done} of {total} sets complete
        </span>
      </div>
      <div className="progress-track">
        <i style={{ width: `${total ? (done / total) * 100 : 0}%` }} />
      </div>
      <button type="button" className="secondary" onClick={onDevices}>
        Connect / test heart-rate device
      </button>
      <SensorPanel sensor={sensor} session={session} onTrack={onTrack} />
      <div className="session-exercises">
        {session.activities.map((a, i) => {
          const prev = previousLog(history, a.activityId, session.startedAt);
          const prevRows = prev?.rows.filter((r) => r.done) || [];
          return (
            <section
              className={`log-card ${a.type !== "strength" ? "timed-log" : ""}`}
              key={a.id}
              data-reorder-item
            >
              <div className="log-heading">
                <ExerciseOrder
                  name={a.name}
                  index={i}
                  total={session.activities.length}
                  onMove={(to) =>
                    onChange({
                      ...session,
                      activities: moveExercise(session.activities, i, to),
                    })
                  }
                />
                <span className={`activity-icon ${a.type}`}>
                  <ActivityIcon type={a.type} />
                </span>
                <div>
                  <p className="eyebrow">EXERCISE {i + 1}</p>
                  <h3>{a.name}</h3>
                </div>
                <span className="count">
                  {a.rows.filter((r) => r.done).length}/{a.rows.length}
                </span>
              </div>
              <button
                className={`track-exercise ${session.trackingExerciseId === a.id ? "tracking" : ""}`}
                aria-pressed={session.trackingExerciseId === a.id}
                onClick={() =>
                  onTrack(session.trackingExerciseId === a.id ? null : a.id)
                }
              >
                {session.trackingExerciseId === a.id
                  ? "● Tracking this exercise · tap for rest"
                  : "Track this exercise"}
              </button>
              <p className="planned">
                Planned: {a.planned.sets}{" "}
                {a.type === "cardio" ? "rounds" : "sets"} ·{" "}
                {a.type === "strength"
                  ? `${a.planned.reps} reps × ${a.planned.weight} kg`
                  : a.type === "cardio"
                    ? `${formatTime(a.planned.time)} · ${a.planned.distance} km`
                    : `${formatTime(a.planned.time)} × ${a.planned.reps} stretches`}
              </p>
              <div className="set-grid set-labels">
                <span>Done</span>
                <span>Last</span>
                <span>{a.type === "cardio" ? "Rnd" : "Set"}</span>
                <span>{a.type === "strength" ? "Reps" : "Min : sec"}</span>
                <span>
                  {a.type === "strength"
                    ? "Kg"
                    : a.type === "cardio"
                      ? "Km"
                      : "Count"}
                </span>
              </div>
              {a.rows.map((r, index) => (
                <div
                  className={`set-grid ${r.done ? "set-done" : ""}`}
                  key={r.id}
                >
                  <button
                    aria-label={`${r.done ? "Unmark" : "Complete"} ${a.name} set ${index + 1}`}
                    aria-pressed={r.done}
                    className="done-button"
                    onClick={() => rowChange(a.id, r.id, { done: !r.done })}
                  >
                    {r.done ? <Check size={18} /> : <span />}
                  </button>
                  <span className="last-value">
                    {prevRows[index] ? performance(a, prevRows[index]) : "—"}
                  </span>
                  <span className="set-number">{index + 1}</span>
                  {(a.type === "strength"
                    ? ["reps", "weight"]
                    : a.type === "cardio"
                      ? ["time", "distance"]
                      : ["time", "reps"]
                  ).map((key) =>
                    key === "time" ? (
                      <DurationFields
                        key={key}
                        label={`${a.name} set ${index + 1} time`}
                        value={r.time}
                        onChange={(time) => rowChange(a.id, r.id, { time })}
                      />
                    ) : (
                      <NumberField
                        key={key}
                        label={`${a.name} set ${index + 1} ${key}`}
                        value={r[key as "reps" | "weight" | "distance"]}
                        step={
                          key === "weight" ? 0.5 : key === "distance" ? 0.01 : 1
                        }
                        onChange={(n) => rowChange(a.id, r.id, { [key]: n })}
                      />
                    ),
                  )}
                </div>
              ))}
              <button
                className="text-button add-set"
                disabled={a.rows.length >= 30}
                onClick={() =>
                  onChange({
                    ...session,
                    activities: session.activities.map((log) =>
                      log.id === a.id
                        ? {
                            ...log,
                            rows: [
                              ...log.rows,
                              { ...log.rows.at(-1)!, id: uid(), done: false },
                            ],
                          }
                        : log,
                    ),
                  })
                }
              >
                <Plus size={16} />
                Add {a.type === "cardio" ? "round" : "set"}
              </button>
            </section>
          );
        })}
      </div>
      <div className="session-actions">
        <button className="primary full" disabled={!done} onClick={onFinish}>
          <Flag size={18} /> Finish workout
        </button>
        <p className="small muted centered">
          Only checked sets count toward your progress.
        </p>
        <button className="text-button danger" onClick={onDiscard}>
          <Trash2 size={16} /> Discard session
        </button>
      </div>
    </>
  );
}
