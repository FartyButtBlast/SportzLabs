import {useEffect,useRef,useState} from 'react';
import type {Activity,Session,Template} from '../data/types';
import {proHistory,type ProRequest} from '../services/useProAccess';
import type {Suggestion} from '../../supabase/functions/workout-pro/engine';
const supported=(a:Activity)=>a.type==='strength'&&(!a.metricMode||a.metricMode==='reps_weight')&&!/assisted|assistance|band|push[ -]?up|pull[ -]?up|chin[ -]?up|dip\b|bodyweight|body weight|olympic|snatch|clean\b|jerk\b|jump|swing|throw|plyo/i.test(a.name);
export default function ProProgression({template,activities,sessions,userId,request,onSave}:{template:Template;activities:Activity[];sessions:Session[];userId:string;request:ProRequest;onSave:(t:Template)=>boolean}){
 const choices=template.activities.filter(t=>{const a=activities.find(a=>a.id===t.activityId);return a&&supported(a);});
 const [selected,setSelected]=useState(choices[0]?.id||'');
 const ta=choices.find(t=>t.id===selected),exercise=activities.find(a=>a.id===ta?.activityId);
 const [min,setMin]=useState('8'),[max,setMax]=useState('12'),[increment,setIncrement]=useState('2.5'),[confirmed,setConfirmed]=useState(false);
 const [result,setResult]=useState<Suggestion|null>(null),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState('');
 const operation=useRef(0);
 useEffect(()=>{const rule=template.activities.find(t=>t.id===selected)?.progression;setMin(String(rule?.minReps??8));setMax(String(rule?.maxReps??12));setIncrement(String(rule?.increment??2.5));setConfirmed(!!rule);},[selected,template.id]);
 useEffect(()=>{operation.current++;setResult(null);setBusy(false);setError('');setMessage('');return()=>{operation.current++;};},[sessions,ta?.targets,selected,min,max,increment,confirmed,request]);
 const payload=()=>({history:proHistory(sessions,userId),templateId:template.id,exercise:exercise&&{id:exercise.id,name:exercise.name,type:exercise.type,metricMode:exercise.metricMode},target:ta?.targets,rule:{minReps:Number(min),maxReps:Number(max),increment:Number(increment)}});
 const calculate=async()=>{
  if(!ta||!confirmed)return;const id=++operation.current;setBusy(true);setError('');setMessage('');setResult(null);
  try{const next=await request<Suggestion>('progression',payload());if(id!==operation.current)return;
   if(!onSave({...template,activities:template.activities.map(t=>t.id===ta.id?{...t,progression:payload().rule}:t)}))throw new Error('Could not save these settings.');
   setResult(next);
  }catch(e){if(id===operation.current)setError((e as Error).message);}finally{if(id===operation.current)setBusy(false);}
 };
 const accept=async()=>{
  if(!ta||!result||result.kind!=='increase')return;const id=++operation.current;setBusy(true);setError('');
  try{const fresh=await request<Suggestion>('progression',payload());if(id!==operation.current)return;
   if(fresh.kind!=='increase'||fresh.weight!==result.weight||fresh.reps!==result.reps){setResult(fresh);throw new Error('The suggestion changed. Review it before accepting.');}
   if(!onSave({...template,activities:template.activities.map(t=>t.id===ta.id?{...t,targets:{...t.targets,weight:fresh.weight,reps:fresh.reps},useTargetsNextSession:true,progressionPreviousTargets:{...t.targets}}:t)}))throw new Error('Could not save the new target.');
   setResult(null);setMessage('Target saved for your next session. Current and completed sessions are unchanged.');
  }catch(e){if(id===operation.current)setError((e as Error).message);}finally{if(id===operation.current)setBusy(false);}
 };
 const undo=async()=>{
  if(!ta?.progressionPreviousTargets)return;const id=++operation.current;setBusy(true);setError('');
  try{await request<Suggestion>('progression',payload());if(id!==operation.current)return;
   if(!onSave({...template,activities:template.activities.map(t=>t.id===ta.id?{...t,targets:ta.progressionPreviousTargets!,useTargetsNextSession:false,progressionPreviousTargets:undefined}:t)}))throw new Error('Could not restore the target.');
  }catch(e){if(id===operation.current)setError((e as Error).message);}finally{if(id===operation.current)setBusy(false);}
 };
 return <section className="panel pro-panel" aria-labelledby="progression-heading">
  <p className="eyebrow">PRO · NEXT SESSION</p><h2 id="progression-heading">Progression suggestions</h2>
  <p className="muted">Choose a rep range and the smallest weight increase your equipment allows. We suggest an increase after two matching sessions reach the top of that range.</p>
  {!choices.length?<p>Add a conventional loaded repetition exercise to use suggestions. Bodyweight, assisted, timed and technical movements use manual targets.</p>:<>
   <form onSubmit={e=>{e.preventDefault();void calculate();}}>
    <label>Exercise<select value={selected} onChange={e=>setSelected(e.target.value)} disabled={busy}>{choices.map(t=><option key={t.id} value={t.id}>{activities.find(a=>a.id===t.activityId)?.name}</option>)}</select></label>
    <div className="pro-fields"><label>Minimum reps<input required type="number" min="1" max="30" step="1" value={min} disabled={busy} onChange={e=>setMin(e.target.value)}/></label><label>Maximum reps<input required type="number" min={Number(min)||1} max="30" step="1" value={max} disabled={busy} onChange={e=>setMax(e.target.value)}/></label><label>Increase (kg)<input required type="number" min="0.1" max="50" step="0.01" value={increment} disabled={busy} onChange={e=>setIncrement(e.target.value)}/></label></div>
    <label className="pro-confirm"><input type="checkbox" checked={confirmed} disabled={busy} onChange={e=>setConfirmed(e.target.checked)}/><span>This is an externally loaded exercise. Its logged sets are working sets performed with consistent technique and equipment; warm-ups are separate.</span></label>
    {ta&&<p className="small muted">Current target: {ta.targets.sets} sets × {ta.targets.reps} reps at {ta.targets.weight} kg.{ta.useTargetsNextSession?' Your accepted target will fill the next session.':''}</p>}
    {ta?.useTargetsNextSession&&ta.progressionPreviousTargets&&<button type="button" className="text-button" disabled={busy} onClick={()=>void undo()}>Undo accepted target</button>}
    <button className="secondary" disabled={busy||!confirmed||!ta}>{busy?'Checking…':'Save rule & check progress'}</button>
   </form>
   {result&&<div className="pro-suggestion" role="status"><h3>{result.kind==='increase'?`Next target: ${result.weight} kg · ${result.reps} reps`:result.kind==='review'?'Review your target':'Keep your current weight'}</h3><p>{result.reason}</p>{result.evidence.length>0&&<p className="small muted">Compared sessions: {result.evidence.map(d=>new Date(d).toLocaleDateString('en-AU')).join(' and ')}.</p>}{result.kind==='increase'&&<div className="pro-actions"><button className="primary" disabled={busy} onClick={()=>void accept()}>Accept next target</button><button className="secondary" disabled={busy} onClick={()=>{setResult(null);setMessage('Current target kept.');}}>Keep current target</button></div>}</div>}
   {message&&<p role="status">{message}</p>}{error&&<p className="error" role="alert">{error}</p>}
  </>}
  <details className="pro-method"><summary>How suggestions work</summary><p>This is Workout Studio’s configurable rep-range rule, informed by resistance-training research—not an individual coaching assessment. It checks the latest two sessions containing this exercise in this workout. Both must have exactly the planned working sets at the current weight. Increases above 10%, changed exercise details, and breaks over 28 days require manual review. These thresholds are product choices, not universal prescriptions. If you have pain, changed technique or need an easier session, keep or edit your targets manually.</p><p>History analysis uses your latest 1,000 completed, non-demo sessions. Suggestions require an internet connection.</p><p><a href="https://pubmed.ncbi.nlm.nih.gov/41843416/" target="_blank" rel="noreferrer">ACSM guidance (2026)</a> · <a href="https://pubmed.ncbi.nlm.nih.gov/36199287/" target="_blank" rel="noreferrer">Repetition and load progression study</a></p></details>
 </section>;
}
