import {useEffect,useState} from 'react';
import {Bluetooth,HeartPulse} from 'lucide-react';
import type {SensorController} from '../services/useSensors';
export default function HeartRateDevice({sensor,recording}:{sensor:SensorController;recording:boolean}){
 const [now,setNow]=useState(Date.now());
 useEffect(()=>{const timer=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(timer);},[]);
 const reading=sensor.latest.hr;
 const age=reading?Math.max(0,Math.floor((now-reading.at)/1000)):null;
 const fresh=reading && age!==null && age<15 && sensor.heart.status==='connected';
 const connected=sensor.heart.status==='connected',connecting=sensor.heart.status==='connecting';
 return <section className="device-test" aria-label="Heart-rate device test">
  <HeartPulse size={32}/><p>Connect a Bluetooth Low Energy heart-rate strap, armband or watch, then check its live reading here.</p>
  <div className="device-test-reading" aria-live="off"><strong>{fresh?reading.value:'—'}</strong><span>bpm</span></div>
  <p role="status" className="device-test-status">{!sensor.supported?'Bluetooth unavailable in this browser':connecting?'Searching / connecting…':connected?(fresh?'Live signal received':reading?'Signal stale — no fresh reading':'Connected — waiting for a heart-rate reading'):sensor.heart.status==='disconnected'?'Device disconnected':'No device connected'}</p>
  {sensor.heart.name&&<p className="small muted">{sensor.heart.name}{age!==null?` · Last reading ${age}s ago`:''}</p>}
  {!sensor.supported&&<p className="sensor-help">Use Chrome on Android or the installed Workout Studio mobile app. iPhone Safari and Home Screen web apps cannot access this Bluetooth interface. The native iPhone app requires installation.</p>}
  <div className="sensor-buttons"><button className="primary" disabled={!sensor.supported||connecting} onClick={()=>void(connected?sensor.disconnect('heartRate'):sensor.connect('heartRate'))}><Bluetooth size={18}/>{connecting?'Connecting…':connected?'Disconnect device':'Find and connect device'}</button></div>
  {sensor.heart.error&&<p className="error" role="alert">{sensor.heart.error}</p>}
  <p className="small muted">{recording?'A workout is active. When connected, readings are saved against its selected exercise or Rest.':'Test readings are not saved or uploaded. The connection stays available when you start a workout.'}</p>
  <h3>Before connecting</h3><ol><li>Wear and wake your sensor. Moisten chest-strap contacts if its instructions require it.</li><li>Enable Bluetooth. For a watch, enable heart-rate broadcasting.</li><li>Choose your sensor in the device picker and allow the requested permission.</li></ol>
  <p className="small muted">Any brand can connect if it broadcasts the standard Bluetooth Heart Rate service (0x180D). Bluetooth pairing alone is not enough: proprietary watch services, Bluetooth Classic and ANT+-only sensors are not supported.</p>
  <details><summary>Device missing or no reading?</summary><p>Keep the sensor nearby and check its battery. Disconnect it from another app if all Bluetooth connections are occupied. Pair inside Workout Studio. Make sure watch broadcasting is enabled. Keep the app visible and screen awake; screen lock or backgrounding may interrupt readings.</p></details>
 </section>;
}
