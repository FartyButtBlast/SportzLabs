import {Medal} from 'lucide-react';
export default function TrendMedal({description}:{description:string}){
 return <span className="trend-medal" title={description} aria-label={description}><Medal size={25} strokeWidth={2} aria-hidden="true"/><b>PB</b></span>;
}
