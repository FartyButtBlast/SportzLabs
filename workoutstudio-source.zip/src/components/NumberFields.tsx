import { useEffect, useState } from "react";

export function NumberField({value,onChange,min=0,max,step=1,label,required=false}: {value:number;onChange:(value:number)=>void;min?:number;max?:number;step?:number;label:string;required?:boolean}) {
  const [text,setText]=useState(String(value));
  useEffect(()=>setText(String(value)),[value]);
  const clamp=(n:number)=>Math.min(max ?? Infinity,Math.max(min,n));
  return <input aria-label={label} type="text" inputMode={step<1?'decimal':'numeric'} required={required} value={text}
    onFocus={e=>e.currentTarget.select()}
    onChange={e=>{
      const raw=e.target.value;
      if (!(step<1 ? /^\d*(\.\d*)?$/ : /^\d*$/).test(raw)) return;
      const next=raw.replace(/^0+(?=\d)/,'');
      setText(next);
      if(next!=='' && next!=='.') onChange(clamp(Number(next)));
    }}
    onBlur={()=>{const n=clamp(Number(text)||0);setText(String(n));onChange(n);}}
  />;
}
export const formatTime=(seconds:number)=>`${Math.floor(seconds/60)}m ${Math.floor(seconds%60)}s`;
export function DurationFields({value,onChange,label='Time'}:{value:number;onChange:(n:number)=>void;label?:string}) {
  return <span className="duration-fields" role="group" aria-label={label}>
    <label><NumberField label={`${label} minutes`} value={Math.floor(value/60)} onChange={n=>onChange(n*60+value%60)}/><small>min</small></label>
    <label><NumberField label={`${label} seconds`} value={value%60} max={59} onChange={n=>onChange(Math.floor(value/60)*60+n)}/><small>sec</small></label>
  </span>;
}
