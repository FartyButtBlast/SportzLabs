import { NumberField, DurationFields } from "./NumberFields";
import {exerciseCatalog, exerciseGroups, sportTypes, sportLabel} from '../../supabase/functions/strava/catalog';
import {metricMode,metricKeys,metricLabels,suggestedMetrics,exerciseProfile} from '../data/exerciseProfile';
import type {MetricMode} from '../data/types';
import { useState } from "react";
import {
  Search,
  Plus,
  Dumbbell,
  HeartPulse,
  StretchHorizontal,
  Pencil,
} from "lucide-react";
import {
  Activity,
  ActivityType,
  Tag,
  TAGS,
  Targets,
  labels,
  uid,
} from "../data/types";
import { defaultTargets } from "../data/seed";
export function ActivityIcon({ type }: { type: ActivityType }) {
  return type === "cardio" ? (
    <HeartPulse size={21} />
  ) : type === "stretching" ? (
    <StretchHorizontal size={21} />
  ) : (
    <Dumbbell size={21} />
  );
}
export function TargetFields({type,mode,value,onChange}:{type:ActivityType;mode?:MetricMode;value:Targets;onChange:(t:Targets)=>void}) {
 const keys=metricKeys(mode||metricMode({type}));
 const names={reps:'Reps',weight:'Weight (kg)',distance:'Distance (km)'};
 return <div className="target-fields"><label>{type==='cardio'?'Rounds':'Sets'}<NumberField label="Sets" value={value.sets} min={1} max={30} onChange={sets=>onChange({...value,sets})}/></label>
 {keys.map(key=>key==='time'?<div key={key} className="duration-target"><span>Time</span><DurationFields value={value.time} onChange={time=>onChange({...value,time})}/></div>:<label key={key}>{names[key]}<NumberField label={names[key]} value={value[key]} step={key==='weight'?0.5:key==='distance'?0.01:1} onChange={n=>onChange({...value,[key]:n})}/></label>)}
 </div>;
}
export function ActivityForm({
  activity,
  initialName = "",
  activities,
  userId,
  onSave,
}: {
  activity?: Activity;
  initialName?: string;
  activities: Activity[];
  userId: string;
  onSave: (a: Activity) => void;
}) {
  const initial=activity?exerciseProfile(activity):undefined;
  const [stravaExerciseType,setStravaExerciseType]=useState(initial?.stravaExerciseType||'');
  const [mode,setMode]=useState<MetricMode>(initial?.metricMode||'reps_weight');
  const [sport,setSport]=useState(initial?.stravaSportType||'WeightTraining');
  const [name, setName] = useState(activity?.name || initialName);
  const [type, setType] = useState<ActivityType>(activity?.type || "strength");
  const [tags, setTags] = useState<Tag[]>(activity?.tags || []);
  const [defaults, setDefaults] = useState<Targets>(
    activity?.defaults || defaultTargets("strength"),
  );
  const [error, setError] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) {
          setError("Enter an activity name.");
          return;
        }
        const cleanName=name.trim().replace(/\s+/g," ");
        if (activities.some(a=>a.id!==activity?.id && a.name.trim().replace(/\s+/g," ").toLocaleLowerCase()===cleanName.toLocaleLowerCase())) {
          setError("An activity with this name already exists. Choose it from the library or use a different name.");
          return;
        }
        if (!tags.length) {
          setError("Choose at least one body area.");
          return;
        }
        onSave({
          id: activity?.id || uid(),
          userId,
          name: cleanName,
          type,
          tags,
          defaults,
          stravaExerciseType: stravaExerciseType || undefined,
          metricMode: mode, stravaSportType: sport, stravaCategory:exerciseCatalog.find(e=>e.code===stravaExerciseType)?.category,
        });
      }}
    >
      <label>
        Activity name
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          maxLength={80}
          placeholder="e.g. Cable lateral raise"
        />
      </label>
      <label>
        Activity type
        <select
          value={type}
          onChange={(e) => {
            const t = e.target.value as ActivityType;
            setType(t);
            setMode(metricMode({type:t}));
            setSport(t==='strength'?'WeightTraining':'Workout');
            setDefaults(defaultTargets(t));
          }}
        >
          {Object.entries(labels).map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </select>
      </label>
      <label>Strava movement<select value={stravaExerciseType} onChange={e=>{const code=e.target.value;setStravaExerciseType(code);const match=exerciseCatalog.find(x=>x.code===code);if(match){const next=suggestedMetrics(code,match.category);setMode(next);setDefaults({...defaults,time:defaults.time||30});}}}><option value="">Match by exercise name</option><option value="CUSTOM">Custom / no matching movement</option>{Object.keys(exerciseGroups).map(category=><optgroup key={category} label={category}>{exerciseCatalog.filter(e=>e.category===category).map(e=><option key={e.code} value={e.code}>{e.name}</option>)}</optgroup>)}</select></label>
      <label>Strava activity type<select value={sport} onChange={e=>setSport(e.target.value)}>{sportTypes.map(s=><option key={s} value={s}>{sportLabel(s)}</option>)}</select></label>
      <label>Measurements<select value={mode} onChange={e=>setMode(e.target.value as MetricMode)}>{Object.entries(metricLabels).map(([v,label])=><option key={v} value={v}>{label}</option>)}</select></label>
      <p className="small muted">Choose the closest movement, or keep a custom exercise. Measurements remain in your workout history even when Strava cannot accept them as structured data.</p>
      <label>Body areas</label>
      <div className="tag-picker">
        {TAGS.map((t) => (
          <button
            type="button"
            key={t}
            aria-pressed={tags.includes(t)}
            className={tags.includes(t) ? "selected" : ""}
            onClick={() =>
              setTags(
                tags.includes(t) ? tags.filter((x) => x !== t) : [...tags, t],
              )
            }
          >
            {t}
          </button>
        ))}
      </div>
      <h3 className="form-section">Default targets</h3>
      <TargetFields type={type} mode={mode} value={defaults} onChange={setDefaults} />
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      <button className="primary full">
        {activity ? "Save activity" : "Create activity"}
      </button>
    </form>
  );
}
export function ActivityPicker({
  activities,
  onChoose,
  onCustom,
}: {
  activities: Activity[];
  onChoose: (a: Activity) => void;
  onCustom: (name: string) => void;
}) {
  const [search, setSearch] = useState("");
  return (
    <>
      <div className="search-field">
        <Search size={18} />
        <input
          aria-label="Find an activity"
          placeholder="Find an activity…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      <button className="secondary full custom-create" onClick={()=>onCustom(search.trim())}>
        <Plus size={18} /> Create custom activity
      </button>
      <div className="picker-list">
        {activities
          .filter((a) => a.name.toLowerCase().includes(search.toLowerCase()))
          .map((a) => (
            <button
              key={a.id}
              className="activity-item"
              onClick={() => onChoose(a)}
            >
              <span className={`activity-icon ${a.type}`}>
                <ActivityIcon type={a.type} />
              </span>
              <span>
                <b>{a.name}</b>
                <small>
                  {a.stravaCategory||labels[a.type]} · {a.tags.join(", ")}
                </small>
              </span>
              <Plus size={19} />
            </button>
          ))}
      </div>
    </>
  );
}
export function LibraryItem({
  activity,
  onEdit,
}: {
  activity: Activity;
  onEdit: () => void;
}) {
  return (
    <div className="activity-item">
      <span className={`activity-icon ${activity.type}`}>
        <ActivityIcon type={activity.type} />
      </span>
      <span>
        <b>{activity.name}</b>
        {activity.description && <small style={{whiteSpace:"pre-line"}}>{activity.description}</small>}
        <small>
          {activity.stravaCategory||labels[activity.type]} · {activity.tags.join(", ")}
        </small>
      </span>
      {activity.userId ? (
        <button
          className="icon-button edit-activity"
          aria-label={`Edit ${activity.name}`}
          onClick={onEdit}
        >
          <Pencil size={17} />
        </button>
      ) : (
        <span className="builtin">Built-in</span>
      )}
    </div>
  );
}
