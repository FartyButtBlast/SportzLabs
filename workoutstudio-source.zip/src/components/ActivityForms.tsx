import {exerciseMappings} from '../../supabase/functions/strava/strength';
import { useState } from "react";
import {
  Search,
  Plus,
  Dumbbell,
  HeartPulse,
  StretchHorizontal,
  Pencil,
} from "lucide-react";
import {
  Activity,
  ActivityType,
  Tag,
  TAGS,
  Targets,
  labels,
  uid,
} from "../data/types";
import { defaultTargets } from "../data/seed";
export function ActivityIcon({ type }: { type: ActivityType }) {
  return type === "cardio" ? (
    <HeartPulse size={21} />
  ) : type === "stretching" ? (
    <StretchHorizontal size={21} />
  ) : (
    <Dumbbell size={21} />
  );
}
export function TargetFields({
  type,
  value,
  onChange,
}: {
  type: ActivityType;
  value: Targets;
  onChange: (t: Targets) => void;
}) {
  const field = (key: keyof Targets, label: string, min = 0, step = 1) => (
    <label key={key}>
      {label}
      <input
        aria-label={label}
        type="number"
        inputMode={step < 1 ? "decimal" : "numeric"}
        min={min}
        max={key === "sets" ? 30 : undefined}
        step={step}
        required
        value={value[key]}
        onChange={(e) =>
          onChange({
            ...value,
            [key]: e.target.value === "" ? 0 : Number(e.target.value),
          })
        }
      />
    </label>
  );
  return (
    <div className="target-fields">
      {field("sets", type === "cardio" ? "Rounds" : "Sets", 1)}
      {type === "strength" ? (
        <>
          {field("reps", "Reps", 1)}
          {field("weight", "Weight (kg)", 0, 0.5)}
        </>
      ) : (
        <>
          {field("time", "Time (sec)", 1)}
          {type === "cardio"
            ? field("distance", "Distance (km)", 0, 0.01)
            : field("reps", "Stretch count", 1)}
        </>
      )}
    </div>
  );
}
export function ActivityForm({
  activity,
  userId,
  onSave,
}: {
  activity?: Activity;
  userId: string;
  onSave: (a: Activity) => void;
}) {
  const [stravaExerciseType,setStravaExerciseType]=useState(activity?.stravaExerciseType||'');
  const [name, setName] = useState(activity?.name || "");
  const [type, setType] = useState<ActivityType>(activity?.type || "strength");
  const [tags, setTags] = useState<Tag[]>(activity?.tags || []);
  const [defaults, setDefaults] = useState<Targets>(
    activity?.defaults || defaultTargets("strength"),
  );
  const [error, setError] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!name.trim()) {
          setError("Enter an activity name.");
          return;
        }
        if (!tags.length) {
          setError("Choose at least one body area.");
          return;
        }
        onSave({
          id: activity?.id || uid(),
          userId,
          name: name.trim(),
          type,
          tags,
          defaults,
          stravaExerciseType: stravaExerciseType || undefined,
        });
      }}
    >
      <label>
        Activity name
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          maxLength={80}
          placeholder="e.g. Cable lateral raise"
        />
      </label>
      <label>
        Activity type
        <select
          value={type}
          onChange={(e) => {
            const t = e.target.value as ActivityType;
            setType(t);
            setDefaults(defaultTargets(t));
          }}
        >
          {Object.entries(labels).map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </select>
      </label>
      <label>Strava exercise match (optional)<select value={stravaExerciseType} onChange={e=>setStravaExerciseType(e.target.value)}><option value="">Match by exercise name</option>{Object.entries(exerciseMappings).sort(([a],[b])=>a.localeCompare(b)).map(([name,code])=><option key={name} value={code}>{name}</option>)}</select></label>
      <p className="small muted">Choose the equivalent movement for a custom exercise so Strava can build its muscle map. Unmatched exercises remain in the description.</p>
      <label>Body areas</label>
      <div className="tag-picker">
        {TAGS.map((t) => (
          <button
            type="button"
            key={t}
            aria-pressed={tags.includes(t)}
            className={tags.includes(t) ? "selected" : ""}
            onClick={() =>
              setTags(
                tags.includes(t) ? tags.filter((x) => x !== t) : [...tags, t],
              )
            }
          >
            {t}
          </button>
        ))}
      </div>
      <h3 className="form-section">Default targets</h3>
      <TargetFields type={type} value={defaults} onChange={setDefaults} />
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      <button className="primary full">
        {activity ? "Save activity" : "Create activity"}
      </button>
    </form>
  );
}
export function ActivityPicker({
  activities,
  onChoose,
  onCustom,
}: {
  activities: Activity[];
  onChoose: (a: Activity) => void;
  onCustom: () => void;
}) {
  const [search, setSearch] = useState("");
  return (
    <>
      <div className="search-field">
        <Search size={18} />
        <input
          aria-label="Find an activity"
          placeholder="Find an activity…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      <button className="secondary full custom-create" onClick={onCustom}>
        <Plus size={18} /> Create custom activity
      </button>
      <div className="picker-list">
        {activities
          .filter((a) => a.name.toLowerCase().includes(search.toLowerCase()))
          .map((a) => (
            <button
              key={a.id}
              className="activity-item"
              onClick={() => onChoose(a)}
            >
              <span className={`activity-icon ${a.type}`}>
                <ActivityIcon type={a.type} />
              </span>
              <span>
                <b>{a.name}</b>
                <small>
                  {labels[a.type]} · {a.tags.join(", ")}
                </small>
              </span>
              <Plus size={19} />
            </button>
          ))}
      </div>
    </>
  );
}
export function LibraryItem({
  activity,
  onEdit,
}: {
  activity: Activity;
  onEdit: () => void;
}) {
  return (
    <div className="activity-item">
      <span className={`activity-icon ${activity.type}`}>
        <ActivityIcon type={activity.type} />
      </span>
      <span>
        <b>{activity.name}</b>
        <small>
          {labels[activity.type]} · {activity.tags.join(", ")}
        </small>
      </span>
      {activity.userId ? (
        <button
          className="icon-button edit-activity"
          aria-label={`Edit ${activity.name}`}
          onClick={onEdit}
        >
          <Pencil size={17} />
        </button>
      ) : (
        <span className="builtin">Built-in</span>
      )}
    </div>
  );
}
