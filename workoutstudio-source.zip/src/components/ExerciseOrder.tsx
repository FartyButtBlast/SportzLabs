import { useEffect, useId, useRef, useState } from "react";
import { GripVertical } from "lucide-react";

export function moveExercise<T>(items: T[], from: number, to: number): T[] {
  if (
    from < 0 ||
    to < 0 ||
    from >= items.length ||
    to >= items.length ||
    from === to
  )
    return items;
  const next = [...items];
  const [item] = next.splice(from, 1);
  next.splice(to, 0, item);
  return next;
}

export default function ExerciseOrder({
  name,
  index,
  total,
  onMove,
}: {
  name: string;
  index: number;
  total: number;
  onMove: (to: number) => void;
}) {
  const help = useId();
  const [message, setMessage] = useState("");
  const cleanup = useRef<(() => void) | null>(null);
  const latestMove = useRef(onMove);
  latestMove.current = onMove;
  useEffect(() => () => cleanup.current?.(), []);
  return (
    <>
      <button
        type="button"
        className="drag-handle"
        aria-label={`Reorder ${name}`}
        aria-describedby={help}
        title="Drag to reorder"
        onContextMenu={(e) => e.preventDefault()}
        disabled={total < 2}
        onKeyDown={(e) => {
          if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return;
          e.preventDefault();
          const to = Math.max(
            0,
            Math.min(total - 1, index + (e.key === "ArrowUp" ? -1 : 1)),
          );
          onMove(to);
          setMessage(`${name} moved to position ${to + 1} of ${total}.`);
        }}
        onPointerDown={(e) => {
          if (e.button !== 0 || !e.isPrimary) return;
          const handle = e.currentTarget;
          const card = handle.closest<HTMLElement>("[data-reorder-item]");
          if (!card?.parentElement) return;
          e.preventDefault();
          e.stopPropagation();
          cleanup.current?.();
          const rows = Array.from(card.parentElement.children).filter(
            (el): el is HTMLElement =>
              el instanceof HTMLElement && el.hasAttribute("data-reorder-item"),
          );
          const startY = e.clientY,
            startScroll = window.scrollY;
          let y = e.clientY,
            target = index,
            frame = 0,
            active = true;
          handle.setPointerCapture(e.pointerId);
          card.classList.add("reorder-dragging");
          document.body.classList.add("exercise-drag-active");
          function findTarget() {
            target = index;
            rows.forEach((row, j) => {
              if (row === card) return;
              const rect = row.getBoundingClientRect();
              const middle = rect.top + rect.height / 2;
              if (j < index && y < middle) target = Math.min(target, j);
              if (j > index && y > middle) target = Math.max(target, j);
            });
          }
          function paint() {
            if (!active) return;
            const top =
              (document.querySelector("header")?.getBoundingClientRect()
                .bottom ?? 0) + 55;
            const bottom = window.innerHeight - 145;
            const speed =
              y < top
                ? -Math.min(14, (top - y) / 5)
                : y > bottom
                  ? Math.min(14, (y - bottom) / 5)
                  : 0;
            if (speed) window.scrollBy(0, speed);
            card!.style.transform = `translateY(${y - startY + window.scrollY - startScroll}px)`;
            findTarget();
            rows.forEach((row, j) => {
              row.classList.toggle(
                "reorder-before",
                j === target && target < index,
              );
              row.classList.toggle(
                "reorder-after",
                j === target && target > index,
              );
            });
            frame = requestAnimationFrame(paint);
          }
          const move = (event: PointerEvent) => {
            if (event.pointerId === e.pointerId) y = event.clientY;
          };
          const finish = (commit: boolean) => {
            if (!active) return;
            active = false;
            cancelAnimationFrame(frame);
            card.style.removeProperty("transform");
            rows.forEach((row) =>
              row.classList.remove(
                "reorder-dragging",
                "reorder-before",
                "reorder-after",
              ),
            );
            document.body.classList.remove("exercise-drag-active");
            document.removeEventListener("pointermove", move);
            document.removeEventListener("pointerup", up);
            document.removeEventListener("pointercancel", cancel);
            handle.removeEventListener("lostpointercapture", cancel);
            document.removeEventListener("keydown", escape);
            window.removeEventListener("blur", cancel);
            if (handle.hasPointerCapture(e.pointerId))
              handle.releasePointerCapture(e.pointerId);
            cleanup.current = null;
            if (commit) {
              latestMove.current(target);
              setMessage(
                `${name} moved to position ${target + 1} of ${total}.`,
              );
            }
          };
          const up = (event: PointerEvent) => {
              if (event.pointerId !== e.pointerId) return;
              y = event.clientY;
              findTarget();
              finish(true);
            },
            cancel = () => finish(false);
          const escape = (event: KeyboardEvent) => {
            if (event.key === "Escape") finish(false);
          };
          document.addEventListener("pointermove", move);
          document.addEventListener("pointerup", up);
          document.addEventListener("pointercancel", cancel);
          handle.addEventListener("lostpointercapture", cancel);
          document.addEventListener("keydown", escape);
          window.addEventListener("blur", cancel);
          cleanup.current = cancel;
          frame = requestAnimationFrame(paint);
        }}
      >
        <GripVertical size={22} />
      </button>
      <span id={help} className="sr-only">
        Drag to a new position, or use the up and down arrow keys.
      </span>
      <span className="sr-only" role="status">
        {message}
      </span>
    </>
  );
}
