import {ArrowUp,ArrowDown} from 'lucide-react';
export function moveExercise<T>(items:T[],from:number,to:number):T[]{
 if(from<0||to<0||from>=items.length||to>=items.length||from===to)return items;
 const next=[...items];const [item]=next.splice(from,1);next.splice(to,0,item);return next;
}
export default function ExerciseOrder({name,index,total,onMove}:{name:string;index:number;total:number;onMove:(to:number)=>void}){
 return <div className="exercise-order" role="group" aria-label={`Reorder ${name}`}>
 <button type="button" className="icon-button" disabled={index===0} aria-label={`Move ${name} up`} onClick={()=>onMove(index-1)}><ArrowUp size={18}/></button>
 <button type="button" className="icon-button" disabled={index===total-1} aria-label={`Move ${name} down`} onClick={()=>onMove(index+1)}><ArrowDown size={18}/></button>
 </div>;
}
