import {TAGS} from '../data/types';
import BodyMap from './BodyMap';

const palette={none:'#e3e7e5',low:'#e7c35e',medium:'#69b7a3',high:'#216b51'};
export default function MuscleFocus({muscles}:{muscles:{name:string;sets:number}[]}){
 const groups=TAGS.filter(tag=>tag!=='cardio').map(name=>({name,sets:muscles.find(m=>m.name===name)?.sets||0}));
 const max=Math.max(1,...groups.map(m=>m.sets));
 const level=(sets:number)=>!sets?'none':sets/max>0.65?'high':sets/max>0.3?'medium':'low';
 const values=Object.fromEntries(groups.map(m=>[m.name,m.sets]));
 return <section className="muscle-focus" aria-labelledby="muscle-focus-heading">
  <h3 id="muscle-focus-heading">Muscle-group activity</h3>
  <p className="small muted">Your training focus in this period, measured by completed strength sets.</p>
  <div className="muscle-focus-layout">
   <figure className="muscle-focus-figure">
    <BodyMap values={values} palette={palette} large description={`Muscle focus, front and back: ${groups.map(m=>`${m.name} ${m.sets} sets`).join('; ')}`}/>
    <figcaption><span>Front</span><span>Back</span></figcaption>
    <div className="muscle-focus-key">{([{key:'none',label:'No sets'},{key:'low',label:'Lower focus'},{key:'medium',label:'Moderate'},{key:'high',label:'Higher focus'}] as const).map(item=><span key={item.key}><i style={{background:palette[item.key]}}/>{item.label}</span>)}</div>
   </figure>
   <div className="muscle-focus-totals">{[...groups].sort((a,b)=>b.sets-a.sets).map(m=><div key={m.name}><span>{m.name}</span><div className="muscle-focus-track" aria-hidden="true"><i style={{width:`${m.sets/max*100}%`,background:palette[level(m.sets)]}}/></div><strong>{m.sets} {m.sets===1?'set':'sets'}</strong></div>)}</div>
  </div>
  <p className="small muted">Colours compare areas with your most-trained muscle group. Grey means no tagged strength sets. A set counts toward each tagged muscle, so totals overlap; this does not measure fatigue or recovery.</p>
 </section>;
}
