import {connectStrava} from '../services/stravaConnect';
import { STRAVA_CHANGED, sharingPreferences, saveSharingPreferences, retryUpload } from '../services/stravaSync';
import { useEffect, useState } from 'react';
import { Session } from '../data/types';
import { completeStravaCallback, strengthCoverage, stravaRequest, StravaStatus } from '../services/strava';
export function StravaCallback() {
 const [message,setMessage] = useState('');
 useEffect(()=>{const p = completeStravaCallback(); if(p){setMessage('Finishing your Strava connection…');p.then(()=>{window.dispatchEvent(new Event(STRAVA_CHANGED));setMessage('Strava sign-in received. You can return to Workout Studio.');}).catch(e=>setMessage(e.message));}},[]);
 return message ? <div className="strava-notice" role="status">{message}</div> : null;
}
export default function StravaPanel({session,userId}:{session?:Session;userId:string}) {
 const [status,setStatus] = useState<StravaStatus|null>(null);
 const [preferences,setPreferences] = useState(()=>sharingPreferences(userId));
 const [error,setError] = useState('');
 const [busy,setBusy] = useState(false);
 const [disconnecting,setDisconnecting] = useState(false);
 const changePreferences = (patch:Partial<typeof preferences>) => {const next={...preferences,...patch};try{saveSharingPreferences(userId,next);setPreferences(next);}catch{setError('Could not save sharing preferences.');}};
 const refresh = async () => {
  let result=await stravaRequest<StravaStatus>({action:'status',sessionId:session?.id},userId);
  if(result.post?.status==='sending'&&result.post.upload_id&&session){
   try{await stravaRequest({action:'reconcile',sessionId:session.id},userId);result=await stravaRequest<StravaStatus>({action:'status',sessionId:session.id},userId);}catch{/* Keep the existing upload visible and reconcile on the next check. */}
  }
  setStatus(result);
 };
 useEffect(()=>{let alive=true;stravaRequest<StravaStatus>({action:'status',sessionId:session?.id},userId).then(s=>{if(alive)setStatus(s);}).catch(e=>{if(alive)setError(e.message);});return()=>{alive=false;};},[session?.id,session?.stravaUpload?.state]);
 useEffect(()=>{const changed=()=>{void refresh().catch(()=>{});};window.addEventListener(STRAVA_CHANGED,changed);window.addEventListener('focus',changed);const timer=setInterval(changed,30000);return()=>{window.removeEventListener(STRAVA_CHANGED,changed);window.removeEventListener('focus',changed);clearInterval(timer);};},[session?.id]);
 const run = async(fn:()=>Promise<void>)=>{setBusy(true);setError('');try{await fn();}catch(e){setError((e as Error).message);}finally{setBusy(false);}};
 if(session?.sample) return null;
 const posted = status?.post?.status === 'posted' || session?.stravaUpload?.state === 'posted';
 const pending = ['pending','waiting'].includes(session?.stravaUpload?.state||'') || (status?.post?.status==='sending'&&Boolean(status.post.upload_id));
 const coverage=session?strengthCoverage(session):null;
 const failed = session?.stravaUpload?.state === 'failed' || status?.post?.status === 'failed';
 const uncertain = session?.stravaUpload?.state==='unknown' || Boolean(status?.post && ['sending','unknown'].includes(status.post.status)&&!(status.post.status==='sending'&&status.post.upload_id));
 return <section className="strava-panel">
  <div className="section-title"><h3>Strava</h3><span className="small muted">{status?.connected?'Connected':'Optional connection'}</span></div>
  <p className="small muted">{session ? 'Your workout is sent to Strava as soon as you finish, when connected and automatic sharing is enabled. Strava may take a moment to process it.' : 'Connecting resumes waiting uploads and enables uploads for newly completed workouts. You can switch this off below. Visibility follows your Strava settings.'}</p>
  {coverage && <p className="small muted">{coverage.mapped.length ? `${coverage.mapped.length} matched exercises can be sent as structured sets for Strava’s muscle map. Strava determines the highlighted muscles.` : 'No exercises match Strava yet; this workout will share as a summary without a muscle map.'}{coverage.unmapped.length>0?` Description only: ${coverage.unmapped.map(a=>a.name).join(', ')}. Edit custom activities to choose a Strava exercise match for future sessions.`:''}</p>}
  {error && <p role="alert" className="strava-error">{error}</p>}
  {!status && !error && <p className="small muted">Checking connection…</p>}
  {!status && error && <button className="secondary" disabled={busy} onClick={()=>run(refresh)}>Try again</button>}
  {status && !status.configured && <p className="small muted">Strava sharing is awaiting the site owner’s API setup. Your completed workout stays saved here.</p>}
  {!session && <div className="sharing-options"><label><input type="checkbox" checked={preferences.autoUpload} onChange={e=>changePreferences({autoUpload:e.target.checked})}/> Upload automatically when I finish a workout</label><label><input type="checkbox" checked={preferences.includeHeartRate} onChange={e=>changePreferences({includeHeartRate:e.target.checked})}/> Include recorded heart-rate data for Strava charts, averages and peaks</label><p className="small muted">Heart-rate sharing is off by default. Temperature stays in Workout Studio. These preferences apply to this browser or installed app.</p></div>}
  {status?.configured && !status.connected && <button className="strava-button" disabled={busy} onClick={()=>run(async()=>{await connectStrava(userId);window.dispatchEvent(new Event(STRAVA_CHANGED));await refresh();})}>{busy?'Connecting…':'Connect with Strava'}</button>}
  {posted && <a className="strava-link" href={`https://www.strava.com/activities/${status?.post?.activity_id||session?.stravaUpload?.activityId}`} target="_blank" rel="noopener noreferrer">View on Strava ↗</a>}
  {pending && !posted && <p className="small muted" role="status">{session?.stravaUpload?.message || 'Uploading to Strava… If offline, this resumes when the app is open and online.'}</p>}
  {failed && !pending && !uncertain && !posted && <p role="alert" className="strava-error">Strava upload failed. Your workout is saved. <button className="text-button" disabled={busy} onClick={()=>run(async()=>{await retryUpload(userId,session!);await refresh();})}>Retry Strava upload</button></p>}
  {uncertain && <p role="status" className="small muted">This workout may already be on Strava. Check your activity feed; another post is blocked to prevent duplicates.</p>}
  {status?.connected && !session && <>{disconnecting?<div><p className="small muted">Disconnecting revokes Workout Studio’s access. Workouts already posted to Strava remain there.</p><button className="secondary" disabled={busy} onClick={()=>run(async()=>{await stravaRequest({action:'disconnect'},userId);window.dispatchEvent(new Event(STRAVA_CHANGED));await refresh();setDisconnecting(false);})}>Confirm disconnect</button> <button className="text-button" disabled={busy} onClick={()=>setDisconnecting(false)}>Cancel</button></div>:<button className="text-button" onClick={()=>setDisconnecting(true)}>Disconnect Strava</button>}</>}
 </section>;
}
