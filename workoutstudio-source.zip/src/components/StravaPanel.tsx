import { Browser } from '@capacitor/browser';
import { Capacitor } from '@capacitor/core';
import { STRAVA_CHANGED, sharingPreferences, saveSharingPreferences, retryUpload } from '../services/stravaSync';
import { useEffect, useState } from 'react';
import { Session } from '../data/types';
import { completeStravaCallback, shareDraft, strengthCoverage, stravaRequest, StravaStatus } from '../services/strava';
import type { ShareInput } from '../../supabase/functions/strava/payload';
export function StravaCallback() {
 const [message,setMessage] = useState('');
 useEffect(()=>{const p = completeStravaCallback(); if(p){setMessage('Finishing your Strava connection…');p.then(()=>{window.dispatchEvent(new Event(STRAVA_CHANGED));setMessage('Strava connected. Newly completed workouts upload automatically unless you switch this off in Account settings.');}).catch(e=>setMessage(e.message));}},[]);
 return message ? <div className="strava-notice" role="status">{message}</div> : null;
}
export default function StravaPanel({session,userId}:{session?:Session;userId:string}) {
 const [status,setStatus] = useState<StravaStatus|null>(null);
 const [preferences,setPreferences] = useState(()=>sharingPreferences(userId));
 const [error,setError] = useState('');
 const [busy,setBusy] = useState(false);
 const [draft,setDraft] = useState<ShareInput|null>(null);
 const [disconnecting,setDisconnecting] = useState(false);
 const changePreferences = (patch:Partial<typeof preferences>) => {const next={...preferences,...patch};try{saveSharingPreferences(userId,next);setPreferences(next);}catch{setError('Could not save sharing preferences.');}};
 const refresh = async () => {
  let result=await stravaRequest<StravaStatus>({action:'status',sessionId:session?.id},userId);
  if(result.post?.status==='sending'&&result.post.upload_id&&session){
   try{await stravaRequest({action:'reconcile',sessionId:session.id},userId);result=await stravaRequest<StravaStatus>({action:'status',sessionId:session.id},userId);}catch{/* Keep the existing upload visible and reconcile on the next check. */}
  }
  setStatus(result);
 };
 useEffect(()=>{let alive=true;stravaRequest<StravaStatus>({action:'status',sessionId:session?.id}).then(s=>{if(alive)setStatus(s);}).catch(e=>{if(alive)setError(e.message);});return()=>{alive=false;};},[session?.id,session?.stravaUpload?.state]);
 useEffect(()=>{const changed=()=>{void refresh().catch(()=>{});};window.addEventListener(STRAVA_CHANGED,changed);window.addEventListener('focus',changed);const timer=setInterval(changed,30000);return()=>{window.removeEventListener(STRAVA_CHANGED,changed);window.removeEventListener('focus',changed);clearInterval(timer);};},[session?.id]);
 const run = async(fn:()=>Promise<void>)=>{setBusy(true);setError('');try{await fn();}catch(e){setError((e as Error).message);}finally{setBusy(false);}};
 if(session?.sample) return null;
 const posted = status?.post?.status === 'posted' || session?.stravaUpload?.state === 'posted';
 const pending = session?.stravaUpload?.state === 'pending' || (status?.post?.status==='sending'&&Boolean(status.post.upload_id));
 const coverage=session?strengthCoverage(session):null;
 const failed = session?.stravaUpload?.state === 'failed';
 const uncertain = session?.stravaUpload?.state==='unknown' || Boolean(status?.post && ['sending','unknown'].includes(status.post.status)&&!(status.post.status==='sending'&&status.post.upload_id));
 return <section className="strava-panel">
  <div className="section-title"><h3>Strava</h3><span className="small muted">{status?.connected?'Connected':'Optional connection'}</span></div>
  <p className="small muted">{session ? 'Completed workouts upload automatically when connected and automatic sharing is enabled. No route or GPS data is added.' : 'Connecting enables automatic uploads for newly completed workouts. You can switch this off below. Visibility follows your Strava settings.'}</p>
  {coverage && <p className="small muted">{coverage.mapped.length ? `${coverage.mapped.length} matched exercises can be sent as structured sets for Strava’s muscle map. Strava determines the highlighted muscles.` : 'No exercises match Strava yet; this workout will share as a summary without a muscle map.'}{coverage.unmapped.length>0?` Description only: ${coverage.unmapped.map(a=>a.name).join(', ')}. Edit custom activities to choose a Strava exercise match for future sessions.`:''}</p>}
  {error && <p role="alert" className="strava-error">{error}</p>}
  {!status && !error && <p className="small muted">Checking connection…</p>}
  {!status && error && <button className="secondary" disabled={busy} onClick={()=>run(refresh)}>Try again</button>}
  {status && !status.configured && <p className="small muted">Strava sharing is awaiting the site owner’s API setup. Your completed workout stays saved here.</p>}
  {!session && <div className="sharing-options"><label><input type="checkbox" checked={preferences.autoUpload} onChange={e=>changePreferences({autoUpload:e.target.checked})}/> Upload automatically when I finish a workout</label><label><input type="checkbox" checked={preferences.includeHeartRate} onChange={e=>changePreferences({includeHeartRate:e.target.checked})}/> Include heart-rate averages and peaks in my Strava description</label><p className="small muted">Heart-rate sharing is off by default. Temperature stays in Workout Studio. These preferences apply to this browser or installed app.</p></div>}
  {status?.configured && !status.connected && Capacitor.isNativePlatform() && <p className="small muted"><a href="https://www.sportzlabs.com/workoutstudio/" onClick={e=>{e.preventDefault();void run(()=>Browser.open({url:'https://www.sportzlabs.com/workoutstudio/'}));}}>Open the website to connect Strava</a>, sign in with the same Workout Studio account, then return here.</p>}
  {status?.configured && !status.connected && !Capacitor.isNativePlatform() && <button className="strava-button" disabled={busy} onClick={()=>run(async()=>{const r=await stravaRequest<{url:string}>({action:'connect',redirectUri:new URL(import.meta.env.BASE_URL,window.location.href).href});window.location.assign(r.url);})}>{busy?'Connecting…':'Connect with Strava'}</button>}
  {posted && <a className="strava-link" href={`https://www.strava.com/activities/${status?.post?.activity_id||session?.stravaUpload?.activityId}`} target="_blank" rel="noopener noreferrer">View on Strava ↗</a>}
  {pending && !posted && <p className="small muted" role="status">{session?.stravaUpload?.message || 'Uploading to Strava… If offline, this resumes when the app is open and online.'}</p>}
  {failed && preferences.autoUpload && !posted && <p role="alert" className="strava-error">Automatic upload could not be confirmed. Your workout is saved. <button className="text-button" disabled={busy} onClick={()=>run(async()=>{await retryUpload(userId,session!);await refresh();})}>Check and retry upload</button></p>}
  {uncertain && <p role="status" className="small muted">This workout may already be on Strava. Check your activity feed; another post is blocked to prevent duplicates.</p>}
  {status?.configured && status.connected && session && !posted && !pending && !uncertain && !draft && <button className="strava-button" disabled={busy} onClick={()=>{try{setDraft(shareDraft(session,preferences.includeHeartRate));}catch(e){setError((e as Error).message);}}}>Review for Strava</button>}
  {draft && !posted && !uncertain && <form className="strava-review" onSubmit={e=>{e.preventDefault();run(async()=>{await stravaRequest({action:'share',workout:draft});await refresh();setDraft(null);});}}>
   <label>Activity title<input required maxLength={100} value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})}/></label>
   <label>Activity type<select value={draft.sportType} onChange={e=>setDraft({...draft,sportType:e.target.value,strength:['WeightTraining','Workout'].includes(e.target.value)?shareDraft(session!,preferences.includeHeartRate).strength:undefined})}><option value="Workout">Workout</option><option value="WeightTraining">Weight training</option><option value="Yoga">Yoga</option><option value="Run">Run</option><option value="Ride">Ride</option><option value="Walk">Walk</option><option value="Swim">Swim</option></select></label>
   <label>Duration (minutes)<input type="number" min="0.0167" max="10080" step="any" required value={Number((draft.elapsedTime/60).toFixed(2))} onChange={e=>setDraft({...draft,elapsedTime:Math.round(Number(e.target.value)*60)})}/></label>
   <p className="small muted">Started {new Date(draft.startedAt).toLocaleString()}. Review the duration if your session timer was left running.</p>
   <label>Description<textarea rows={7} maxLength={4000} value={draft.description} onChange={e=>setDraft({...draft,description:e.target.value})}/></label>
   <p className="small muted">This sends the details above to Strava. Visibility follows your Strava account settings. Only checked sets are included.</p>
   <div className="form-actions"><button type="button" className="secondary" disabled={busy} onClick={()=>setDraft(null)}>Cancel</button><button type="submit" className="strava-button" disabled={busy}>{busy?'Posting…':'Post to Strava'}</button></div>
  </form>}
  {status?.connected && !session && <>{disconnecting?<div><p className="small muted">Disconnecting revokes Workout Studio’s access. Workouts already posted to Strava remain there.</p><button className="secondary" disabled={busy} onClick={()=>run(async()=>{await stravaRequest({action:'disconnect'});window.dispatchEvent(new Event(STRAVA_CHANGED));await refresh();setDisconnecting(false);})}>Confirm disconnect</button> <button className="text-button" disabled={busy} onClick={()=>setDisconnecting(false)}>Cancel</button></div>:<button className="text-button" onClick={()=>setDisconnecting(true)}>Disconnect Strava</button>}</>}
 </section>;
}
