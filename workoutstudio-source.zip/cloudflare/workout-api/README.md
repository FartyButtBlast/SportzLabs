# Workout Studio cloud storage

The Worker stores one revisioned workout document per Supabase user in Cloudflare D1. It asks Supabase Auth to verify each access token, and uses the verified user ID as the database key. The browser and iPhone only receive access to their own document. The local copy remains available for offline use.

## One-time Cloudflare setup

1. In Cloudflare, create a D1 database named `workoutstudio` and copy its database ID into `wrangler.jsonc` in place of `REPLACE_WITH_CLOUDFLARE_D1_DATABASE_ID`.
2. Set `SUPABASE_URL` in `wrangler.jsonc` to the existing Supabase project URL. The Worker needs that URL and the project's publishable key so it can validate sessions through Supabase Auth; it does not need a service-role key.
3. From this directory, apply the migration, deploy the Worker, then add its Supabase publishable key:

   ```sh
   pnpm dlx wrangler d1 migrations apply workoutstudio --remote
   pnpm dlx wrangler deploy
   pnpm dlx wrangler secret put SUPABASE_PUBLISHABLE_KEY
   ```

   When prompted, enter the Supabase **publishable** key. Never use a secret or service-role key. `wrangler secret put` deploys the secret as a Worker version.
4. Copy the deployed Worker URL into the app's `VITE_CLOUDFLARE_API_URL` setting, then rebuild and publish the web app and the iPhone app. Include any web preview domains in `CORS_ALLOWED_ORIGINS` before testing those previews.

The Worker accepts requests only from the SportzLabs site, the local development origins, and the Capacitor iOS origin by default. Add an exact origin to `CORS_ALLOWED_ORIGINS` for another app domain. The API uses compare-and-swap revisions; when two devices save concurrently, it merges records by ID and uses the more recently modified device copy for records with matching IDs.

## Data migration behavior

At first sign-in after cloud sync is enabled, the app combines local and cloud templates, custom activities, and sessions by ID. It keeps the newer copy when both devices have edited the same item. The merged result is cached on the current device and saved to D1. Keep the app open and online until the account panel says the workout data is up to date.
