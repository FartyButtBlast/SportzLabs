interface D1Result { success: boolean; meta: { changes: number }; }
interface D1Statement {
  bind(...values: unknown[]): D1Statement;
  first<T>(): Promise<T | null>;
  run(): Promise<D1Result>;
}
interface D1Database { prepare(query: string): D1Statement; }
interface Env {
  DB: D1Database;
  SUPABASE_URL: string;
  SUPABASE_PUBLISHABLE_KEY: string;
  CORS_ALLOWED_ORIGINS: string;
}
interface WorkoutRow { payload: string; revision: number; modified_at: number; updated_at: string; }
interface WorkoutPayload {
  version: 1;
  templates: unknown[];
  customActivities: unknown[];
  sessions: unknown[];
  activeSession: unknown | null;
}

const MAX_BODY_BYTES = 5 * 1024 * 1024;
const json = (body: unknown, status = 200, headers: HeadersInit = {}) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers } });

function corsHeaders(request: Request, env: Env): Headers {
  const origin = request.headers.get("Origin") || "";
  const allowed = (env.CORS_ALLOWED_ORIGINS || "").split(",").map((item) => item.trim()).filter(Boolean);
  const headers = new Headers({ "Vary": "Origin", "Access-Control-Allow-Methods": "GET, PUT, OPTIONS", "Access-Control-Allow-Headers": "Authorization, Content-Type", "Access-Control-Max-Age": "86400" });
  if (allowed.includes(origin)) headers.set("Access-Control-Allow-Origin", origin);
  return headers;
}

async function userIdFor(request: Request, env: Env): Promise<string | null> {
  const authorization = request.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) return null;
  const response = await fetch(`${env.SUPABASE_URL.replace(/\/$/, "")}/auth/v1/user`, {
    headers: { Authorization: authorization, apikey: env.SUPABASE_PUBLISHABLE_KEY },
  });
  if (!response.ok) return null;
  const user = await response.json() as { id?: string };
  return typeof user.id === "string" && user.id ? user.id : null;
}

function snapshot(row: WorkoutRow | null) {
  return row
    ? { data: JSON.parse(row.payload) as WorkoutPayload, revision: row.revision, modifiedAt: row.modified_at }
    : { data: null, revision: 0, modifiedAt: 0 };
}

function validPayload(value: unknown): value is WorkoutPayload {
  if (!value || typeof value !== "object") return false;
  const item = value as Record<string, unknown>;
  return item.version === 1 && Array.isArray(item.templates) && Array.isArray(item.customActivities) && Array.isArray(item.sessions) && (item.activeSession === null || typeof item.activeSession === "object");
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const headers = corsHeaders(request, env);
    if (request.method === "OPTIONS") {
      if (!headers.has("Access-Control-Allow-Origin")) return new Response(null, { status: 403 });
      return new Response(null, { status: 204, headers });
    }
    if (!headers.has("Access-Control-Allow-Origin")) return json({ error: "Origin is not allowed." }, 403, headers);
    const url = new URL(request.url);
    if (url.pathname !== "/v1/workouts" || !["GET", "PUT"].includes(request.method)) return json({ error: "Not found." }, 404, headers);
    let userId: string | null;
    try { userId = await userIdFor(request, env); }
    catch { return json({ error: "Could not verify your sign-in. Try again." }, 502, headers); }
    if (!userId) return json({ error: "Please sign in to access workout sync." }, 401, headers);

    if (request.method === "GET") {
      const row = await env.DB.prepare("SELECT payload, revision, modified_at, updated_at FROM workout_data WHERE user_id = ?").bind(userId).first<WorkoutRow>();
      return json(snapshot(row), 200, headers);
    }

    const length = Number(request.headers.get("Content-Length") || 0);
    if (length > MAX_BODY_BYTES) return json({ error: "Workout data is too large to sync." }, 413, headers);
    let body: { data?: unknown; expectedRevision?: number; modifiedAt?: number };
    try { body = await request.json() as typeof body; }
    catch { return json({ error: "Invalid workout data." }, 400, headers); }
    if (!validPayload(body.data) || !Number.isSafeInteger(body.expectedRevision) || (body.expectedRevision as number) < 0 || !Number.isSafeInteger(body.modifiedAt)) {
      return json({ error: "Workout data could not be saved." }, 400, headers);
    }
    const payload = JSON.stringify(body.data);
    if (new TextEncoder().encode(payload).byteLength > MAX_BODY_BYTES) return json({ error: "Workout data is too large to sync." }, 413, headers);

    let changes = 0;
    if (body.expectedRevision === 0) {
      const result = await env.DB.prepare("INSERT INTO workout_data (user_id, payload, revision, modified_at) VALUES (?, ?, 1, ?) ON CONFLICT(user_id) DO NOTHING").bind(userId, payload, body.modifiedAt).run();
      changes = result.meta.changes;
    } else {
      const result = await env.DB.prepare("UPDATE workout_data SET payload = ?, revision = revision + 1, modified_at = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE user_id = ? AND revision = ?").bind(payload, body.modifiedAt, userId, body.expectedRevision).run();
      changes = result.meta.changes;
    }
    const row = await env.DB.prepare("SELECT payload, revision, modified_at, updated_at FROM workout_data WHERE user_id = ?").bind(userId).first<WorkoutRow>();
    if (!row) return json({ error: "Workout data could not be saved." }, 500, headers);
    if (changes !== 1) return json({ ...snapshot(row), conflict: true }, 409, headers);
    return json(snapshot(row), 200, headers);
  },
};
