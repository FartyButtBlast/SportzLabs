-- Document the existing content field as trusted, administrator-authored HTML.
-- The field remains text so existing drafts and records are preserved unchanged.
comment on column public.sportzlabs_blog_posts.content is
  'Trusted administrator-authored HTML rendered inside the public blog-body CSS class.';
