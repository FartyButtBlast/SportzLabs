-- Additive blog content model. Existing accounts, workouts and settings are untouched.
create table if not exists public.sportzlabs_blog_posts (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]*$'),
  title text not null check (char_length(title) between 1 and 160),
  excerpt text not null default '' check (char_length(excerpt) <= 320),
  content text not null default '',
  category text not null default 'Product updates' check (char_length(category) between 1 and 80),
  author_name text not null default 'SportzLabs' check (char_length(author_name) between 1 and 80),
  status text not null default 'draft' check (status in ('draft','published')),
  published_at timestamptz,
  seo_title text not null default '' check (char_length(seo_title) <= 160),
  seo_description text not null default '' check (char_length(seo_description) <= 320),
  cover_image_url text not null default '' check (char_length(cover_image_url) <= 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists sportzlabs_blog_posts_published_idx on public.sportzlabs_blog_posts(status, published_at desc);
alter table public.sportzlabs_blog_posts enable row level security;
revoke all on public.sportzlabs_blog_posts from public, anon, authenticated;
grant select on public.sportzlabs_blog_posts to anon, authenticated;
create policy sportzlabs_blog_public_read on public.sportzlabs_blog_posts
  for select using (status = 'published' and published_at is not null and published_at <= now());
grant all on public.sportzlabs_blog_posts to service_role;
