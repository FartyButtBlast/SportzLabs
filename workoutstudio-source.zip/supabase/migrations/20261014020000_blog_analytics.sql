-- Additive blog analytics. Public visitors may record only bounded blog events;
-- administrators read aggregated results through the server-only admin function.
create table if not exists public.sportzlabs_blog_events (
  id bigint generated always as identity primary key,
  post_id uuid not null references public.sportzlabs_blog_posts(id) on delete cascade,
  event text not null check (event in ('view','app_click')),
  occurred_at timestamptz not null default now()
);
create index if not exists sportzlabs_blog_events_post_event_idx
  on public.sportzlabs_blog_events(post_id, event, occurred_at desc);
alter table public.sportzlabs_blog_events enable row level security;
revoke all on public.sportzlabs_blog_events from public, authenticated;
grant insert on public.sportzlabs_blog_events to anon, authenticated;
create policy sportzlabs_blog_events_public_insert
  on public.sportzlabs_blog_events
  for insert to anon, authenticated
  with check (
    event in ('view','app_click')
    and occurred_at <= now() + interval '5 minutes'
    and occurred_at >= now() - interval '1 day'
  );
revoke all on public.sportzlabs_blog_events from service_role;
grant all on public.sportzlabs_blog_events to service_role;

create or replace function public.sportzlabs_blog_analytics()
returns table(post_id uuid, event text, event_count bigint)
language sql
stable
security invoker
set search_path = public
as $$
  select post_id, event, count(*)::bigint
  from public.sportzlabs_blog_events
  group by post_id, event
  order by post_id, event;
$$;
revoke all on function public.sportzlabs_blog_analytics() from public, anon, authenticated;
grant execute on function public.sportzlabs_blog_analytics() to service_role;
