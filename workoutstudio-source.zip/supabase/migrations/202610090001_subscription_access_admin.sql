begin;

create table public.sportzlabs_capabilities (
  key text primary key check(key ~ '^[a-z0-9][a-z0-9._-]{0,79}$'),
  name text not null,
  description text not null default '',
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.sportzlabs_tiers (
  id text primary key check(id ~ '^[a-z0-9][a-z0-9-]{0,59}$'),
  name text not null,
  description text not null default '',
  is_default boolean not null default false,
  active boolean not null default true,
  sort_order integer not null default 0,
  capability_keys text[] not null default '{}',
  updated_at timestamptz not null default now()
);
create unique index sportzlabs_one_default_tier on public.sportzlabs_tiers(is_default) where is_default;

create table public.sportzlabs_addons (
  id text primary key check(id ~ '^[a-z0-9][a-z0-9-]{0,59}$'),
  name text not null,
  description text not null default '',
  active boolean not null default true,
  capability_keys text[] not null default '{}',
  updated_at timestamptz not null default now()
);

create table public.sportzlabs_user_access (
  user_id uuid primary key references auth.users(id) on delete cascade,
  tier_id text not null references public.sportzlabs_tiers(id),
  addon_ids text[] not null default '{}',
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
create index sportzlabs_user_access_tier_idx on public.sportzlabs_user_access(tier_id);

do $$
declare t text;
begin
  foreach t in array array['sportzlabs_capabilities','sportzlabs_tiers','sportzlabs_addons','sportzlabs_user_access'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from public, anon, authenticated', t);
    execute format('grant all on public.%I to service_role', t);
    execute format('comment on table public.%I is %L', t, 'Server-only platform data. No client policies by design; authenticated Edge Function enforces authorization.');
  end loop;
end $$;

insert into public.sportzlabs_capabilities(key,name,description) values
  ('workouts.plan','Plan workouts','Create and organize workout routines.'),
  ('workouts.track','Track workout sessions','Record sets, reps, weight, time, and distance.'),
  ('workouts.history','View workout history','Review completed sessions and training summaries.'),
  ('activities.browse','Browse the activity library','Use the built-in activity and exercise library.'),
  ('activities.custom','Create custom activities','Add personal activities to the library.'),
  ('sensors.bluetooth','Connect Bluetooth sensors','Connect compatible heart-rate and temperature sensors.'),
  ('integrations.strava','Connect and share with Strava','Connect Strava and share completed workouts.');

insert into public.sportzlabs_tiers(id,name,description,is_default,active,sort_order,capability_keys) values
  ('free','Free','Core workout planning, activity library, workout tracking, training history, sensor support, and Strava sharing.',true,true,0,ARRAY['workouts.plan','workouts.track','workouts.history','activities.browse','activities.custom','sensors.bluetooth','integrations.strava']);

commit;
