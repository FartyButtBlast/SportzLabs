-- Text preserves Strava's 64-bit id_str without JavaScript rounding.
alter table public.workoutstudio_strava_posts add column upload_id text check (upload_id is null or upload_id ~ '^[1-9][0-9]{0,19}$');
comment on column public.workoutstudio_strava_posts.upload_id is 'Server-only Strava processing ID. A sending record with an upload ID is reconciled, never reposted.';
