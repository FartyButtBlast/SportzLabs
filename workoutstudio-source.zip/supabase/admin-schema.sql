-- Server-only platform administration. Clients use authenticated Edge Functions.
create table public.sportzlabs_admins (user_id uuid primary key references auth.users(id) on delete cascade, created_at timestamptz not null default now());
create table public.sportzlabs_exercises (id text primary key, activity jsonb not null, updated_at timestamptz not null default now());
create table public.sportzlabs_integrations (id text primary key, name text not null, client_id text not null default '', client_secret text not null default '', enabled boolean not null default false, notes text not null default '', updated_at timestamptz not null default now());
create table public.sportzlabs_apps (id text primary key, name text not null, url text not null, description text not null default '', status text not null default 'planned' check(status in ('live','planned')));
create table public.sportzlabs_usage (day date not null default current_date, user_id uuid not null references auth.users(id) on delete cascade, app_id text not null references public.sportzlabs_apps(id), event text not null, count integer not null default 1, primary key(day,user_id,app_id,event));
create index sportzlabs_usage_user_idx on public.sportzlabs_usage(user_id);
create index sportzlabs_usage_app_idx on public.sportzlabs_usage(app_id);
create table public.sportzlabs_audit (id bigint generated always as identity primary key, user_id uuid references auth.users(id) on delete set null, action text not null, target text not null, created_at timestamptz not null default now());
create index sportzlabs_audit_time_idx on public.sportzlabs_audit(created_at desc);
create index sportzlabs_audit_user_idx on public.sportzlabs_audit(user_id);
create table public.sportzlabs_capabilities (key text primary key check(key ~ '^[a-z0-9][a-z0-9._-]{0,79}$'), name text not null, description text not null default '', active boolean not null default true, updated_at timestamptz not null default now());
create table public.sportzlabs_tiers (id text primary key check(id ~ '^[a-z0-9][a-z0-9-]{0,59}$'), name text not null, description text not null default '', is_default boolean not null default false, active boolean not null default true, sort_order integer not null default 0, capability_keys text[] not null default '{}', updated_at timestamptz not null default now());
create unique index sportzlabs_one_default_tier on public.sportzlabs_tiers(is_default) where is_default;
create table public.sportzlabs_addons (id text primary key check(id ~ '^[a-z0-9][a-z0-9-]{0,59}$'), name text not null, description text not null default '', active boolean not null default true, capability_keys text[] not null default '{}', updated_at timestamptz not null default now());
create table public.sportzlabs_user_access (user_id uuid primary key references auth.users(id) on delete cascade, tier_id text not null references public.sportzlabs_tiers(id), addon_ids text[] not null default '{}', updated_by uuid references auth.users(id) on delete set null, updated_at timestamptz not null default now());
create index sportzlabs_user_access_tier_idx on public.sportzlabs_user_access(tier_id);
DO $$ declare t text; begin foreach t in array ARRAY['sportzlabs_admins','sportzlabs_exercises','sportzlabs_integrations','sportzlabs_apps','sportzlabs_usage','sportzlabs_audit','sportzlabs_capabilities','sportzlabs_tiers','sportzlabs_addons','sportzlabs_user_access'] loop execute format('alter table public.%I enable row level security',t); execute format('revoke all on public.%I from public, anon, authenticated',t); execute format('grant all on public.%I to service_role',t); execute format('comment on table public.%I is %L',t,'Server-only platform data. No client policies by design; authenticated Edge Function enforces authorization.'); end loop; end $$;
grant usage, select on sequence public.sportzlabs_audit_id_seq to service_role;
insert into public.sportzlabs_apps(id,name,url,description,status) values ('workoutstudio','Workout Studio','https://www.sportzlabs.com/workoutstudio/','Training plans, exercise library and workout tracking.','live'),('afl-performance-analytics','AFL Performance Analytics','https://aflperformance.sportzlabs.com/','AFL performance analysis.','live');
insert into public.sportzlabs_integrations(id,name,enabled) values ('strava','Strava',true);
insert into public.sportzlabs_capabilities(key,name,description) values
('workouts.plan','Plan workouts','Create and organize workout routines.'),
('workouts.track','Track workout sessions','Record sets, reps, weight, time, and distance.'),
('workouts.history','View workout history','Review completed sessions and training summaries.'),
('activities.browse','Browse the activity library','Use the built-in activity and exercise library.'),
('activities.custom','Create custom activities','Add personal activities to the library.'),
('sensors.bluetooth','Connect Bluetooth sensors','Connect compatible heart-rate and temperature sensors.'),
('integrations.strava','Connect and share with Strava','Connect Strava and share completed workouts.');
insert into public.sportzlabs_tiers(id,name,description,is_default,active,sort_order,capability_keys) values
('free','Free','Core workout planning, activity library, workout tracking, training history, sensor support, and Strava sharing.',true,true,0,ARRAY['workouts.plan','workouts.track','workouts.history','activities.browse','activities.custom','sensors.bluetooth','integrations.strava']);
create function public.sportzlabs_record_usage(p_user uuid,p_app text,p_event text) returns void language sql security invoker set search_path='' as $$
insert into public.sportzlabs_usage(day,user_id,app_id,event) values(current_date,p_user,p_app,p_event)
on conflict(day,user_id,app_id,event) do update set count=least(public.sportzlabs_usage.count+1,10000);
$$;
create function public.sportzlabs_usage_report() returns jsonb language sql stable security invoker set search_path='' as $$
select jsonb_build_object('activeUsers',(select count(distinct user_id) from public.sportzlabs_usage where day>=current_date-29),'events',coalesce((select jsonb_agg(x) from (select app_id,event,sum(count) as count from public.sportzlabs_usage where day>=current_date-29 group by app_id,event order by sum(count) desc) x),'[]'::jsonb),'days',coalesce((select jsonb_agg(x) from (select day,sum(count) as count from public.sportzlabs_usage where day>=current_date-29 group by day order by day) x),'[]'::jsonb));
$$;
revoke all on function public.sportzlabs_record_usage(uuid,text,text), public.sportzlabs_usage_report() from public,anon,authenticated;
grant execute on function public.sportzlabs_record_usage(uuid,text,text), public.sportzlabs_usage_report() to service_role;
