import {strengthFile} from './strength.ts';
import type {ShareInput} from './payload.ts';
export function uploadForm(workout:ShareInput,userId:string){
 const form=new FormData();
 form.set('data_type','json');form.set('name',workout.name);form.set('description',workout.description);form.set('sport_type',workout.sportType);
 form.set('external_id',`workoutstudio-${userId}-${workout.sessionId}`);
 form.set('file',new Blob([JSON.stringify(strengthFile(workout))],{type:'application/json'}),`workoutstudio-${workout.sessionId}.json`);
 return form;
}
export function uploadResult(raw:unknown):{state:'posted';activityId:number}|{state:'processing';uploadId:string}|{state:'failed'|'unknown';message:string}{
 const v=raw as {activity_id?:number;id?:number;id_str?:string;error?:string};
 if(!v||typeof v!=='object')throw new Error('Invalid Strava upload response.');
 if(Number.isSafeInteger(v.activity_id)&&v.activity_id!>0)return {state:'posted',activityId:v.activity_id!};
 if(v.error){return {state:/duplicate/i.test(String(v.error))?'unknown':'failed',message:'Strava could not process the structured workout. Check the activity feed and exercise details. If this app is not enabled for JSON strength uploads, contact Strava developer support.'};}
 const id=typeof v.id_str==='string'?v.id_str:Number.isSafeInteger(v.id)?String(v.id):'';
 if(!/^[1-9][0-9]{0,19}$/.test(id))throw new Error('Strava did not confirm an upload ID.');
 return {state:'processing',uploadId:id};
}
