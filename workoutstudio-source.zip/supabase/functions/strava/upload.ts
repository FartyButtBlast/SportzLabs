import {strengthFile} from './strength.ts';
import type {ShareInput} from './payload.ts';
export function rejectionDiagnostic(status:number,raw:unknown){
 const value=raw&&typeof raw==='object'?raw as Record<string,unknown>:{};
 const clean=(input:unknown)=>typeof input==='string'?input
  .replace(/<[^>]*>/g,'')
  .replace(/Bearer\s+\S+/gi,'Bearer [redacted]')
  .replace(/((?:access_token|refresh_token|client_secret|authorization)["']?\s*[:=]\s*["']?)[^\s,"'}]+/gi,'$1[redacted]')
  .slice(0,512):undefined;
 return {httpStatus:status,at:new Date().toISOString(),error:clean(value.error),message:clean(value.message),status:clean(value.status),errors:Array.isArray(value.errors)?value.errors.slice(0,10).map(e=>({resource:clean(e?.resource),field:clean(e?.field),code:clean(e?.code)})):undefined};
}
export function uploadForm(workout:ShareInput,userId:string){
 const form=new FormData();
 form.set('data_type','json');form.set('name',workout.name);form.set('description',workout.description);form.set('sport_type',workout.sportType);
 form.set('external_id',`workoutstudio-${userId}-${workout.sessionId}`);
 form.set('file',new Blob([JSON.stringify(strengthFile(workout))],{type:'application/json'}),`workoutstudio-${workout.sessionId}.json`);
 return form;
}
export function uploadResult(raw:unknown):{state:'posted';activityId:number}|{state:'processing';uploadId:string}|{state:'failed'|'unknown';message:string}{
 const v=raw as {activity_id?:number;id?:number;id_str?:string;error?:string};
 if(!v||typeof v!=='object')throw new Error('Invalid Strava upload response.');
 if(Number.isSafeInteger(v.activity_id)&&v.activity_id!>0)return {state:'posted',activityId:v.activity_id!};
 if(v.error){return {state:/duplicate|already.exists/i.test(String(v.error))?'unknown':'failed',message:'Strava could not process the workout file. Your workout and readings remain saved. Retry sharing later.'};}
 const id=typeof v.id_str==='string'?v.id_str:Number.isSafeInteger(v.id)?String(v.id):'';
 if(!/^[1-9][0-9]{0,19}$/.test(id))throw new Error('Strava did not confirm an upload ID.');
 return {state:'processing',uploadId:id};
}
// A rejected file has not created an activity. If JSON strength uploads are not
// available to this Strava client, a manual summary can still preserve the work.
// Never fall back after an ambiguous response, authentication/rate-limit error,
// or duplicate rejection: that could create a second activity.
export function canUseSummaryFallback(status:number,body:unknown){
 if(!body||typeof body!=='object')return false;
 const upload=body as {activity_id?:unknown;error?:unknown};
 if(upload.activity_id!=null)return false;
 const serialized=JSON.stringify(body||{});
 if(/duplicate|already.exists/i.test(serialized))return false;
 // Strava also reports terminal processing failures inside a successful HTTP
 // response. A transport success alone does not mean an activity was created.
 if(status>=200&&status<300)return typeof upload.error==='string'&&upload.error.trim().length>0;
 return [400,403,415,422].includes(status);
}
