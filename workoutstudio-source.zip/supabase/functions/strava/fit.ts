import {Encoder,Profile,Utils} from '@garmin/fitsdk';
import {exerciseCatalog} from './catalog.ts';
import {validateStrength} from './strength.ts';
import type {ShareInput} from './payload.ts';
import {validateStreams} from './streams.ts';

const types=Profile.types as unknown as Record<string,Record<string,string>>;
const normalized=(value:string)=>value.replace(/[^a-z0-9]/gi,'').toLowerCase();
const matches=new Map<string,Array<{category:number;subtype:number}>>();
for(const [category,name] of Object.entries(types.exerciseCategory)){
 for(const [subtype,exercise] of Object.entries(types[name+'ExerciseName']||{})){
  const key=normalized(exercise);
  matches.set(key,[...(matches.get(key)||[]),{category:Number(category),subtype:Number(subtype)}]);
 }
}
const categories=new Map(Object.entries(types.exerciseCategory).map(([id,name])=>[normalized(name),Number(id)]));
export function fitExercise(code:string){
 const exercise=exerciseCatalog.find(e=>e.code===code);
 const category=exercise?categories.get(normalized(exercise.category)):undefined;
 const candidates=matches.get(normalized(code))||(/_GENERIC$/.test(code)?matches.get(normalized(code.replace(/_GENERIC$/,''))):undefined);
 const exact=candidates?.find(m=>m.category===category)||(candidates?.length===1?candidates[0]:undefined);
 if(exact)return exact;
 // A known category may be sent without a subtype. Never invent an exact
 // movement or infer a muscle group for an unknown custom exercise.
 return {category:category??65534};
}
export function strengthFit(workout:ShareInput){
 const zone=workout.startedAt.match(/([+-])(\d\d):(\d\d)$/);
 const offset=zone?(Number(zone[2])*3600+Number(zone[3])*60)*(zone[1]==='-'?-1:1):0;
 const {sets,utcOffset}=workout.strength?validateStrength(workout.strength):{sets:[],utcOffset:offset};
 const streams=validateStreams(workout.streams,workout.elapsedTime);
 const start=Utils.convertDateToDateTime(new Date(workout.startedAt));
 const end=start+workout.elapsedTime;
 const encoder=new Encoder();
 encoder.onMesg(Profile.MesgNum.FILE_ID,{type:'activity',manufacturer:'development',product:0,timeCreated:start});
 encoder.onMesg(Profile.MesgNum.DEVICE_INFO,{deviceIndex:'creator',manufacturer:'development',product:0,productName:'Workout Studio',timestamp:start});
 encoder.onMesg(Profile.MesgNum.EVENT,{timestamp:start,event:'timer',eventType:'start'});
 streams?.time.forEach((seconds,i)=>encoder.onMesg(Profile.MesgNum.RECORD,{timestamp:start+seconds,heartRate:streams.heartrate[i]}));
 sets.forEach((set,index)=>{
  const match=fitExercise(set.exercise_type);
  // FIT weight is uint16 with a scale of 16; preserve out-of-range values in
  // the description instead of overflowing or silently changing their value.
  encoder.onMesg(Profile.MesgNum.SET,{messageIndex:index,setType:'active',category:[match.category],...('subtype' in match?{categorySubtype:[match.subtype]}:{}),
   ...(set.repetitions!==undefined?{repetitions:set.repetitions}:{}),
   ...(set.weight!==undefined&&set.weight*16<65535?{weight:set.weight,weightDisplayUnit:'kilogram'}:{}),
   ...(set.duration!==undefined?{duration:set.duration}:{})});
 });
 encoder.onMesg(Profile.MesgNum.EVENT,{timestamp:end,event:'timer',eventType:'stopAll'});
 encoder.onMesg(Profile.MesgNum.LAP,{messageIndex:0,timestamp:end,startTime:start,totalElapsedTime:workout.elapsedTime,totalTimerTime:workout.elapsedTime});
 const sport=/Run$/.test(workout.sportType)?'running':/Ride$/.test(workout.sportType)?'cycling':workout.sportType==='Walk'?'walking':workout.sportType==='Hike'?'hiking':workout.sportType==='Swim'?'swimming':workout.sportType==='Rowing'?'rowing':workout.strength?'training':'generic';
 encoder.onMesg(Profile.MesgNum.SESSION,{messageIndex:0,timestamp:end,startTime:start,totalElapsedTime:workout.elapsedTime,totalTimerTime:workout.elapsedTime,sport,subSport:workout.sportType==='WeightTraining'?'strengthTraining':'generic',firstLapIndex:0,numLaps:1,...(workout.distance!==undefined?{totalDistance:workout.distance}:{}),...(streams?{avgHeartRate:Math.round(streams.heartrate.reduce((n,v)=>n+v,0)/streams.heartrate.length),maxHeartRate:Math.max(...streams.heartrate)}:{})});
 encoder.onMesg(Profile.MesgNum.ACTIVITY,{timestamp:end,localTimestamp:end+utcOffset,totalTimerTime:workout.elapsedTime,numSessions:1,type:'manual',event:'activity',eventType:'stop'});
 return encoder.close();
}
export function fitUploadForm(workout:ShareInput,userId:string){
 const form=new FormData();
 form.set('data_type','fit');form.set('name',workout.name);form.set('description',workout.description);form.set('sport_type',workout.sportType);
 form.set('external_id',`workoutstudio-${userId}-${workout.sessionId}-fit`);
 form.set('file',new Blob([strengthFit(workout)],{type:'application/octet-stream'}),`workoutstudio-${workout.sessionId}.fit`);
 return form;
}
