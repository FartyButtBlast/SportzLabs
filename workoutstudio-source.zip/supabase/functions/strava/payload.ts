import {exerciseCode, validateStrength, type StrengthData, type StrengthSet} from './strength.ts';
export type ShareInput = {
  sessionId: string; name: string; sportType: string; startedAt: string;
  elapsedTime: number; description: string; strength?: StrengthData;
};
export function validateShare(input: unknown): ShareInput {
  const x = input as ShareInput;
  if (!x || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x.sessionId || '')) throw new Error('Invalid session.');
  if (typeof x.name !== 'string' || !x.name.trim() || x.name.length > 100) throw new Error('Use a workout title of 1–100 characters.');
  if (!['Workout', 'WeightTraining', 'Yoga', 'Run', 'Ride', 'Walk', 'Swim'].includes(x.sportType)) throw new Error('Choose a supported activity type.');
  if (!Number.isInteger(x.elapsedTime) || x.elapsedTime < 1 || x.elapsedTime > 604800) throw new Error('Enter a duration between 1 second and 7 days.');
  if (typeof x.startedAt !== 'string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?(?:Z|[+-]\d\d:\d\d)$/.test(x.startedAt) || !Number.isFinite(Date.parse(x.startedAt)) || Date.parse(x.startedAt) > Date.now() + 60000) throw new Error('Invalid workout start time.');
  if (typeof x.description !== 'string' || x.description.length > 4000) throw new Error('Keep the description under 4,000 characters.');
  if(x.strength && !['Workout','WeightTraining','HighIntensityIntervalTraining','Crossfit'].includes(x.sportType)) throw new Error('Structured sets require a strength-compatible activity type.');
  const strength=x.strength?validateStrength(x.strength):legacyStrength(x);
  const sportType=x.sportType==='Workout' && strength?.sets.some(s=>s.weight!==undefined)?'WeightTraining':x.sportType;
  return {sessionId:x.sessionId,name:x.name.trim(),sportType,startedAt:x.startedAt,elapsedTime:x.elapsedTime,description:x.description,...(strength?{strength}:{})};
}

// Older open browser tabs sent only this exact generated description format.
// Recover known movements, never infer exercise identity from body-area tags.
export function legacyStrength(x:ShareInput):StrengthData|undefined {
 if(!['Workout','WeightTraining'].includes(x.sportType)||!x.description.endsWith('Logged with Workout Studio · sportzlabs.com'))return;
 const sets:StrengthSet[]=[];
 for(const block of x.description.split(/\n\s*\n/)){
  const [name,...rows]=block.split('\n');const code=exerciseCode(name.trim());if(!code)continue;
  for(const row of rows){
   const reps=row.match(/^\s*\d+\. (\d+) reps × (\d+(?:\.\d+)?) kg$/);
   const timed=row.match(/^\s*\d+\. (\d+)s (?:× \d+|· \d+(?:\.\d+)? km)$/);
   if(reps && Number(reps[1])>0)sets.push({exercise_type:code,repetitions:Number(reps[1]),weight:Number(reps[2])});
   else if(timed && Number(timed[1])>0)sets.push({exercise_type:code,duration:Number(timed[1])});
  }
 }
 if(!sets.length)return;
 const zone=x.startedAt.match(/([+-])(\d\d):(\d\d)$/);
 const utcOffset=zone?(Number(zone[2])*3600+Number(zone[3])*60)*(zone[1]==='-'?-1:1):0;
 return validateStrength({utcOffset,sets});
}
