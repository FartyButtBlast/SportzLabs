// Verified against https://developers.strava.com/docs/uploads/ (6 October 2026).
// Exact exercise mappings only: body-area tags alone cannot identify a movement.
export const exerciseMappings:Record<string,string> = {
 'Squat':'SQUAT_GENERIC','Book Opener':'THORACIC_ROTATION','Thoracic Rotation':'THORACIC_ROTATION',
 'Back Squat':'BARBELL_BACK_SQUAT','Front Squat':'BARBELL_FRONT_SQUAT','Goblet Squat':'GOBLET_SQUAT','Leg Press':'LEG_PRESS','Single Leg Press':'MACHINE_SINGLE_LEG_PRESS','Hack Squat':'MACHINE_HACK_SQUAT','Bulgarian Split Squat':'BARBELL_BULGARIAN_SPLIT_SQUAT','Walking Lunge':'WALKING_LUNGE','Reverse Lunge':'REVERSE_LUNGE','Step Up':'STEP_UP',
 'Deadlift':'DEADLIFT_GENERIC','Romanian Deadlift':'ROMANIAN_DEADLIFTS','Single Leg Deadlift':'SINGLE_LEG_STRAIGHT_LEG_DEADLIFT','Good Morning':'GOOD_MORNING',
 'Bench Press':'BENCH_PRESS_GENERIC','Incline Bench Press':'INCLINE_BARBELL_BENCH_PRESS','DB Bench Press':'DUMBBELL_BENCH_PRESS','Incline DB Press':'INCLINE_DUMBBELL_BENCH_PRESS','Chest Fly':'FLYE_GENERIC','Cable Fly':'CABLE_CROSSOVER','Push Up':'PUSH_UP_GENERIC',
 'DB Row':'DUMBBELL_ROW','Seated Row':'SEATED_CABLE_ROW','Lat Pulldown':'LAT_PULLDOWN','Pull Up':'PULL_UP_GENERIC','Chin Up':'CLOSE_GRIP_CHIN_UP','Barbell Row':'BENT_OVER_BARBELL_ROW','T Bar Row':'T_BAR_ROW','Assisted Pull Up':'MACHINE_ASSISTED_PULL_UP',
 'Shoulder Press':'SHOULDER_PRESS_GENERIC','DB Shoulder Press':'OVERHEAD_DUMBBELL_PRESS','Arnold Press':'ARNOLD_PRESS','Lateral Raise':'LATERAL_RAISE_GENERIC','Front Raise':'FRONT_RAISE','Reverse Fly':'INCLINE_REVERSE_FLY','Face Pull':'FACE_PULL',
 'Bicep Curl':'CURL_GENERIC','Hammer Curl':'DUMBBELL_HAMMER_CURL','Preacher Curl':'EZ_BAR_PREACHER_CURL','Cable Curl':'CABLE_CURL','Tricep Pushdown':'TRICEPS_PRESSDOWN','Overhead Tricep Extension':'OVERHEAD_DUMBBELL_TRICEPS_EXTENSION','Skull Crusher':'SKULL_CRUSHER','Tricep Dip':'TRICEP_DIP',
 'Plank':'PLANK_GENERIC','Side Plank':'SIDE_PLANK','Cable Crunch':'CABLE_CRUNCH','Hanging Knee Raise':'HANGING_KNEE_RAISE','Russian Twist':'RUSSIAN_TWIST','Ab Wheel Rollout':'AB_WHEEL_ROLLOUT',
 'Hip Thrust':'HIP_THRUST','Glute Bridge':'GLUTE_BRIDGE','Cable Kickback':'CABLE_KICKBACK','Leg Extension':'MACHINE_LEG_EXTENSION','Seated Leg Curl':'MACHINE_LEG_CURL_SEATED','Lying Leg Curl':'LEG_CURL_GENERIC','Standing Calf Raise':'STANDING_CALF_RAISE','Seated Calf Raise':'SEATED_CALF_RAISE',
 'Rowing':'ROWING_MACHINE','Jump Rope':'JUMP_ROPE','Treadmill Run':'RUNNING','Outdoor Run':'RUNNING','Stair Climber':'STAIRMASTER','Assault Bike':'ASSAULT_BIKE',
 'Hamstring Stretch':'STANDING_HAMSTRING_STRETCH','Seated Forward Fold':'SEATED_HAMSTRING_STRETCH','Hip Flexor Stretch':'KNEELING_HIP_FLEXOR_STRETCH','Quad Stretch':'STANDING_QUAD_STRETCH','Pigeon Stretch':'PIGEON_POSE','Figure Four Stretch':'LYING_PIRIFORMIS_STRETCH','Calf Stretch':'TOES_AGAINST_WALL_CALF_STRETCH','Chest Stretch':'WALL_CHEST_STRETCH','Child’s Pose':'CHILDS_POSE_LAT_STRETCH','Lat Stretch':'LAT_STRETCH','Shoulder Stretch':'CROSS_BODY_SHOULDER_STRETCH','Tricep Stretch':'OVERHEAD_TRICEP_STRETCH','Cobra Stretch':'COBRA',
};
const normalize=(s:string)=>s.toLowerCase().replace(/[^a-z0-9]/g,'');
export const supportedExercises = new Set(Object.values(exerciseMappings));
const aliases = new Map(Object.entries(exerciseMappings).flatMap(([name,code])=>[[normalize(name),code],[normalize(code),code]]));
export function exerciseCode(name:string,override?:string){return override&&supportedExercises.has(override)?override:aliases.get(normalize(name));}
export type StrengthSet={exercise_type:string;repetitions?:number;weight?:number;duration?:number};
export type StrengthData={utcOffset:number;sets:StrengthSet[]};
export function validateStrength(value:unknown):StrengthData {
 const x=value as StrengthData;
 if(!x||!Number.isInteger(x.utcOffset)||Math.abs(x.utcOffset)>50400||!Array.isArray(x.sets)||!x.sets.length||x.sets.length>1000)throw new Error('Invalid structured workout.');
 return {utcOffset:x.utcOffset,sets:x.sets.map(s=>{
  if(!s||!supportedExercises.has(s.exercise_type))throw new Error('Unsupported Strava exercise.');
  const clean:StrengthSet={exercise_type:s.exercise_type};
  for(const k of ['repetitions','weight','duration'] as const){
   const v=s[k];if(v===undefined)continue;
   if(!Number.isFinite(v)||v<0||v>(k==='weight'?10000:k==='duration'?604800:10000)||(k!=='weight'&&!Number.isInteger(v)))throw new Error('Invalid exercise set value.');
   clean[k]=v;
  }
  if(!(clean.repetitions!>0)&&!(clean.duration!>0))throw new Error('A set needs repetitions or duration.');
  return clean;
 })};
}
export function strengthFile(workout:{startedAt:string;elapsedTime:number;strength?:StrengthData}){
 if(!workout.strength)throw new Error('Missing structured workout.');
 const {utcOffset,sets}=validateStrength(workout.strength);
 return {version:'1.0',start_time:workout.startedAt,utc_offset:utcOffset,elapsed_time:workout.elapsedTime,creator:{name:'Workout Studio'},sets};
}
