export const nativeRedirect='workoutstudio://www.sportzlabs.com/strava/callback';
export const webRedirects=['https://www.sportzlabs.com/workoutstudio/','https://sportzlabs.com/workoutstudio/','http://localhost:5173/'];
export function allowedRedirect(raw:unknown){return typeof raw==='string'&&(raw===nativeRedirect||webRedirects.includes(raw));}
export function hasScope(raw:unknown,required:string){return typeof raw==='string'&&raw.split(/[\s,]+/).some(scope=>scope===required);}
