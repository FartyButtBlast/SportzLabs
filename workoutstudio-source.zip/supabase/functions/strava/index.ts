import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
import {uploadForm,uploadResult} from './upload.ts';
import { validateShare } from './payload.ts';
const origins = new Set(['https://www.sportzlabs.com', 'https://sportzlabs.com', 'http://127.0.0.1:5173', 'http://localhost:5173', 'capacitor://localhost', 'https://localhost', 'http://localhost']);
const connections = 'workoutstudio_strava_connections';
const posts = 'workoutstudio_strava_posts';
Deno.serve(async (req: Request) => {
 const origin = req.headers.get('origin') || '';
 const headers = { 'Content-Type':'application/json', 'Access-Control-Allow-Origin': origins.has(origin) ? origin : 'https://www.sportzlabs.com', 'Vary':'Origin', 'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info', 'Access-Control-Allow-Methods':'POST, OPTIONS', 'Cache-Control':'no-store' };
 const reply = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers });
 if (origin && !origins.has(origin)) return reply({error:'Origin not allowed.'},403);
 if (req.method === 'OPTIONS') return new Response(null,{status:204,headers});
 if (req.method !== 'POST') return reply({error:'Use POST.'},405);
 const db = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {auth:{persistSession:false,autoRefreshToken:false}});
 const jwt = req.headers.get('authorization')?.replace(/^Bearer /i,'');
 if (!jwt) return reply({error:'Sign in to Workout Studio first.'},401);
 const {data:{user}, error:authError} = await db.auth.getUser(jwt);
 if (authError || !user) return reply({error:'Your session expired. Sign in again.'},401);
 const clientId = Deno.env.get('STRAVA_CLIENT_ID');
 const secret = Deno.env.get('STRAVA_CLIENT_SECRET');
 let lockId: string | null = null;
 const check = (result: {error:unknown}) => { if(result.error) throw new Error('Unable to save integration settings. Please try again.'); };
 try {
  const raw = await req.text();
  if (raw.length > 200000) return reply({error:'Request too large.'},413);
  const body = JSON.parse(raw);
  if (body.action === 'status') {
   const r = await db.from(connections).select('athlete_id').eq('user_id',user.id).maybeSingle(); check(r);
   let post = null;
   if (body.sessionId) { const p = await db.from(posts).select('status,activity_id,upload_id').eq('user_id',user.id).eq('session_id',body.sessionId).maybeSingle(); check(p); post = p.data; }
   return reply({configured:Boolean(clientId && secret),connected:Boolean(r.data?.athlete_id),post});
  }
  if (!clientId || !secret) return reply({error:'Strava setup is awaiting the site owner’s API credentials. Your workout is saved and can be shared once setup is complete.'},503);
  if (!['connect','exchange','share','disconnect','reconcile'].includes(body.action)) return reply({error:'Unknown action.'},400);
  check(await db.from(connections).upsert({user_id:user.id},{onConflict:'user_id',ignoreDuplicates:true}));
  lockId = crypto.randomUUID();
  const locked = await db.from(connections).update({lock_id:lockId,lock_until:new Date(Date.now()+180000).toISOString()}).eq('user_id',user.id).lt('lock_until',new Date().toISOString()).select('*').maybeSingle(); check(locked);
  if (!locked.data) {lockId = null; return reply({error:'A Strava request is already in progress. Please wait a moment.'},409);}
  const c = locked.data;
  const remote = async (url:string,init:RequestInit) => fetch(url,{...init,signal:AbortSignal.timeout(25000)});
  if (body.action === 'connect') {
   const redirect = new URL(body.redirectUri);
   const expectedPath = redirect.hostname === 'localhost' || redirect.hostname === '127.0.0.1' ? '/' : '/workoutstudio/';
   if (!origins.has(redirect.origin) || redirect.pathname !== expectedPath || redirect.search || redirect.hash) return reply({error:'Invalid return address.'},400);
   const state = crypto.randomUUID();
   check(await db.from(connections).update({oauth_state:state,state_expires:new Date(Date.now()+600000).toISOString(),redirect_uri:redirect.href}).eq('user_id',user.id));
   const url = new URL('https://www.strava.com/oauth/authorize');
   url.search = new URLSearchParams({client_id:clientId,redirect_uri:redirect.href,response_type:'code',approval_prompt:'force',scope:'activity:write',state}).toString();
   return reply({url:url.href});
  }
  if (body.action === 'exchange') {
   if (!c.oauth_state || c.oauth_state !== body.state || Date.parse(c.state_expires) < Date.now() || typeof body.code !== 'string' || body.code.length > 1000) return reply({error:'This Strava connection link expired. Connect again from your account.'},400);
   check(await db.from(connections).update({oauth_state:null,state_expires:null}).eq('user_id',user.id));
   if (!String(body.scope || '').split(',').includes('activity:write')) return reply({error:'Strava activity permission was not granted. Connect again and allow workout uploads.'},400);
   const response = await remote('https://www.strava.com/oauth/token',{method:'POST',body:new URLSearchParams({client_id:clientId,client_secret:secret,code:body.code,grant_type:'authorization_code'})});
   if (!response.ok) return reply({error:'Strava could not complete the connection. Please connect again.'},400);
   const token = await response.json();
   if (!token.athlete?.id || !token.access_token || !token.refresh_token) throw new Error('Strava returned an incomplete connection.');
   check(await db.from(connections).update({athlete_id:token.athlete.id,access_token:token.access_token,refresh_token:token.refresh_token,expires_at:token.expires_at,updated_at:new Date().toISOString()}).eq('user_id',user.id));
   return reply({connected:true});
  }
  if (body.action === 'disconnect') {
   if(c.refresh_token) {
    const revoked = await remote('https://www.strava.com/oauth/revoke',{method:'POST',headers:{Authorization:'Basic '+btoa(clientId+':'+secret)},body:new URLSearchParams({token:c.refresh_token,token_type_hint:'refresh_token'})});
    if (!revoked.ok) throw new Error('Strava could not revoke access. Try again, or revoke Workout Studio in Strava’s My Apps settings.');
   }
   check(await db.from(connections).update({athlete_id:null,access_token:null,refresh_token:null,expires_at:null,oauth_state:null,state_expires:null}).eq('user_id',user.id));
   return reply({connected:false});
  }
  const reconciling=body.action==='reconcile';
  if(reconciling && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.sessionId||''))return reply({error:'Invalid session.'},400);
  const workout = reconciling ? null : validateShare(body.workout);
  const sessionId=workout?.sessionId || body.sessionId;
  const previous = await db.from(posts).select('status,activity_id,upload_id').eq('user_id',user.id).eq('session_id',sessionId).maybeSingle(); check(previous);
  if (previous.data?.status === 'posted') return reply({activityId:previous.data.activity_id});
  if (previous.data && previous.data.status !== 'failed' && !(previous.data.status==='sending' && previous.data.upload_id)) return reply({error:'This workout may already have reached Strava. Check your Strava activities before taking further action; automatic reposting is blocked to avoid duplicates.'},409);
  if (!c.refresh_token || !c.athlete_id) return reply({error:'Connect your Strava account first.'},400);
  let accessToken = c.access_token;
  if (c.expires_at < Date.now()/1000 + 90) {
   const refresh = await remote('https://www.strava.com/oauth/token',{method:'POST',body:new URLSearchParams({client_id:clientId,client_secret:secret,grant_type:'refresh_token',refresh_token:c.refresh_token})});
   if (!refresh.ok) throw new Error('Strava access could not be refreshed. Reconnect from your account settings.');
   const token = await refresh.json();
   if(!token.access_token || !token.refresh_token) throw new Error('Strava access could not be refreshed.');
   check(await db.from(connections).update({access_token:token.access_token,refresh_token:token.refresh_token,expires_at:token.expires_at}).eq('user_id',user.id));
   accessToken = token.access_token;
  }
  const settleUpload=async(raw:unknown)=>{
   const result=uploadResult(raw);
   if(result.state==='posted'){
    check(await db.from(posts).update({status:'posted',activity_id:result.activityId}).eq('user_id',user.id).eq('session_id',sessionId));
    return reply({activityId:result.activityId});
   }
   if(result.state==='processing'){
    check(await db.from(posts).update({status:'sending',upload_id:result.uploadId}).eq('user_id',user.id).eq('session_id',sessionId));
    return reply({processing:true});
   }
   check(await db.from(posts).update({status:result.state}).eq('user_id',user.id).eq('session_id',sessionId));
   return reply({error:result.message},422);
  };
  if(previous.data?.status==='sending' && previous.data.upload_id){
   const r=await remote('https://www.strava.com/api/v3/uploads/'+encodeURIComponent(previous.data.upload_id),{headers:{Authorization:'Bearer '+accessToken}});
   if(!r.ok) return reply({error:'Could not check Strava processing yet. The existing upload is preserved; no duplicate will be sent.'},502);
   return await settleUpload(await r.json());
  }
  if(!workout)return reply({error:'No processing upload was found.'},409);
  check(await db.from(posts).upsert({user_id:user.id,session_id:sessionId,status:'sending',upload_id:null},{onConflict:'user_id,session_id'}));
  let response:Response;
  try {
   response = workout.strength ? await remote('https://www.strava.com/api/v3/uploads',{method:'POST',headers:{Authorization:'Bearer '+accessToken},body:uploadForm(workout,user.id)}) : await remote('https://www.strava.com/api/v3/activities',{method:'POST',headers:{Authorization:'Bearer '+accessToken},body:new URLSearchParams({name:workout.name,sport_type:workout.sportType,start_date_local:workout.startedAt,elapsed_time:String(workout.elapsedTime),description:workout.description})});
  } catch {
   await db.from(posts).update({status:'unknown'}).eq('user_id',user.id).eq('session_id',sessionId);
   return reply({error:'Strava did not confirm the result. Check your Strava activity feed. We have blocked another post to avoid creating a duplicate.'},502);
  }
  if (!response.ok) {
   check(await db.from(posts).update({status:response.status >= 500 ? 'unknown':'failed'}).eq('user_id',user.id).eq('session_id',sessionId));
   return reply({error: response.status === 429 ? 'Strava’s request limit was reached. Please try later.' : response.status >= 500 ? 'Strava could not confirm the result. Check your Strava feed before contacting support.' : 'Strava rejected this activity. Check the details and reconnect if necessary.'},502);
  }
  const activity = await response.json();
  if(workout.strength)return await settleUpload(activity);
  if (!Number.isSafeInteger(activity.id)) throw new Error('Strava may have received this workout. Check your activity feed.');
  check(await db.from(posts).update({status:'posted',activity_id:activity.id}).eq('user_id',user.id).eq('session_id',sessionId));
  return reply({activityId:activity.id});
 } catch (error) {
  return reply({error:error instanceof SyntaxError ? 'Invalid request.' : error instanceof Error ? error.message : 'Unable to complete this request.'},400);
 } finally {
  if (lockId) await db.from(connections).update({lock_id:null,lock_until:new Date(0).toISOString()}).eq('user_id',user.id).eq('lock_id',lockId);
 }
});
