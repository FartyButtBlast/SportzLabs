export type HeartRateStreams = {time: number[]; heartrate: number[]};
export function validateStreams(input: unknown, elapsedTime: number): HeartRateStreams | undefined {
  if (input === undefined) return;
  const x = input as HeartRateStreams;
  if (!x || !Array.isArray(x.time) || !Array.isArray(x.heartrate) || !x.time.length || x.time.length > 21600 || x.time.length !== x.heartrate.length) throw new Error('Invalid heart-rate stream.');
  for (let i = 0; i < x.time.length; i++) {
    if (!Number.isInteger(x.time[i]) || x.time[i] < 0 || x.time[i] > elapsedTime || (i > 0 && x.time[i] <= x.time[i-1]) ||
      !Number.isInteger(x.heartrate[i]) || x.heartrate[i] < 1 || x.heartrate[i] > 254) throw new Error('Invalid heart-rate sample.');
  }
  return {time: [...x.time], heartrate: [...x.heartrate]};
}
