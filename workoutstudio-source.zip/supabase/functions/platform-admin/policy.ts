import {supportedExercises} from '../strava/strength.ts';
import {sportTypes,exerciseGroups} from '../strava/catalog.ts';
export const OWNER_EMAIL = 'derek@sportzlabs.com';
export const EVENTS = new Set(['page:Home','page:Workouts','page:Session','page:Library','feature:account','feature:devices','feature:workout','feature:activity','feature:picker','workout:started','workout:completed','workout:previous-values-used','workout:discarded','exercise:custom-saved','strava:connected','strava:disconnected','strava:upload-queued','strava:upload-posted','strava:upload-failed','strava:upload-waiting','strava:upload-unknown','strava:upload-retried']);
export function isOwner(user:{email?:string;email_confirmed_at?:string|null;is_anonymous?:boolean}) { return !user.is_anonymous && !!user.email_confirmed_at && user.email?.toLowerCase() === OWNER_EMAIL; }
const capabilityKey=/^[a-z0-9][a-z0-9._-]{0,79}$/;
const accessId=/^[a-z0-9][a-z0-9-]{0,59}$/;
function validCapabilityKeys(value:any){return Array.isArray(value)&&value.length<=100&&value.every((key:any)=>typeof key==='string'&&capabilityKey.test(key))&&new Set(value).size===value.length;}
export function validateCapability(value:any){
 if(!value||typeof value.key!=='string'||!capabilityKey.test(value.key)||typeof value.name!=='string'||!value.name.trim()||value.name.length>100||typeof value.description!=='string'||value.description.length>500||typeof value.active!=='boolean')throw new Error('Enter a valid capability key, name, description, and status.');
 return {key:value.key,name:value.name.trim(),description:value.description.trim(),active:value.active};
}
export function validateTier(value:any){
 if(!value||typeof value.id!=='string'||!accessId.test(value.id)||typeof value.name!=='string'||!value.name.trim()||value.name.length>100||typeof value.description!=='string'||value.description.length>500||typeof value.active!=='boolean'||!Number.isInteger(value.sort_order)||value.sort_order<0||value.sort_order>10000||!validCapabilityKeys(value.capability_keys))throw new Error('Enter a valid tier and choose valid capabilities.');
 return {id:value.id,name:value.name.trim(),description:value.description.trim(),active:value.active,sort_order:value.sort_order,capability_keys:[...new Set(value.capability_keys)]};
}
export function validateAddon(value:any){
 if(!value||typeof value.id!=='string'||!accessId.test(value.id)||typeof value.name!=='string'||!value.name.trim()||value.name.length>100||typeof value.description!=='string'||value.description.length>500||typeof value.active!=='boolean'||!validCapabilityKeys(value.capability_keys))throw new Error('Enter a valid add-on and choose valid capabilities.');
 return {id:value.id,name:value.name.trim(),description:value.description.trim(),active:value.active,capability_keys:[...new Set(value.capability_keys)]};
}
export function validateExercise(value:any) {
 if(!value || typeof value.id!=='string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(value.id) || typeof value.name!=='string' || !value.name.trim() || value.name.length>120 || !['strength','cardio','stretching'].includes(value.type)) throw new Error('Enter a valid exercise name and type.');
 const tags=['chest','back','shoulders','biceps','triceps','abs','glutes','quads','hamstrings','calves','cardio'];
 if(!Array.isArray(value.tags)||!value.tags.length||value.tags.length>tags.length||value.tags.some((t:any)=>!tags.includes(t))) throw new Error('Choose valid body areas.');
 if(typeof value.description!=='string'||value.description.length>4000) throw new Error('Description must be under 4,000 characters.');
 for(const k of ['sets','reps','weight','time','distance']) if(!Number.isFinite(value.defaults?.[k])||value.defaults[k]<0||value.defaults[k]>(k==='sets'?30:100000)) throw new Error('Enter valid exercise targets.');
 if(value.defaults.sets<1||!Number.isInteger(value.defaults.sets))throw new Error('Sets must be a whole number from 1 to 30.');
 if(value.stravaExerciseType && value.stravaExerciseType!=='CUSTOM'&&!supportedExercises.has(value.stravaExerciseType))throw new Error('Choose a supported Strava movement.');
 if(value.stravaSportType&&!sportTypes.includes(value.stravaSportType))throw new Error('Choose a supported Strava activity type.');
 if(value.metricMode&&!['reps_weight','time_weight','time_distance','time_reps'].includes(value.metricMode))throw new Error('Choose valid measurements.');
 if(value.stravaCategory&&!exerciseGroups[value.stravaCategory])throw new Error('Choose a supported exercise category.');
 return {id:value.id,userId:null,name:value.name.trim(),description:value.description,type:value.type,tags:[...new Set(value.tags)],defaults:value.defaults,metricMode:value.metricMode,stravaSportType:value.stravaSportType,stravaCategory:value.stravaCategory,...(typeof value.stravaExerciseType==='string' && value.stravaExerciseType.length<100 ? {stravaExerciseType:value.stravaExerciseType}: {})};
}
export function validAppUrl(value:string) { try {const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password;}catch{return false;} }
