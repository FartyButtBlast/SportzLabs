import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
import {isOwner,validateExercise,validateCapability,validateTier,validateAddon,validAppUrl,EVENTS} from './policy.ts';
const origins=new Set(['https://workout-studio.derekenderby.chatgpt.site','https://www.sportzlabs.com','https://sportzlabs.com','http://127.0.0.1:5173','http://localhost:5173','capacitor://localhost','https://localhost','http://localhost']);
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'';
 const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':origins.has(origin)?origin:'https://www.sportzlabs.com','Vary':'Origin','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Cache-Control':'no-store'};
 const reply=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers});
 if(origin&&!origins.has(origin))return reply({error:'Origin not allowed.'},403);
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply({error:'Use POST.'},405);
 const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
 const jwt=req.headers.get('authorization')?.replace(/^Bearer /i,'');
 if(!jwt)return reply({error:'Sign in to continue.'},401);
 const {data:{user},error}=await db.auth.getUser(jwt);
 if(error||!user||user.is_anonymous||!user.email_confirmed_at)return reply({error:'A verified email account is required.'},401);
 const check=(r:any)=>{if(r.error)throw new Error('The request could not be saved or loaded. Please try again.');return r.data;};
 try {
  const raw=await req.text();if(raw.length>120000)return reply({error:'Request too large.'},413);
  const b=JSON.parse(raw);
  if(b.action==='catalog')return reply({exercises:check(await db.from('sportzlabs_exercises').select('activity').order('id').limit(1000)).map((x:any)=>x.activity)});
  if(b.action==='track'){
   if(b.app!=='workoutstudio'||!EVENTS.has(b.event))return reply({error:'Unknown usage event.'},400);
   if(b.eventId!==undefined){
    if(typeof b.eventId!=='string'||!/^[-a-zA-Z0-9:]{1,160}$/.test(b.eventId)||typeof b.occurredAt!=='string'||!Number.isFinite(Date.parse(b.occurredAt))||Date.parse(b.occurredAt)>Date.now()+60000)return reply({error:'Invalid usage event.'},400);
    check(await db.rpc('sportzlabs_record_usage_once',{p_user:user.id,p_app:b.app,p_event:b.event,p_id:b.eventId,p_at:b.occurredAt}));
   }else check(await db.rpc('sportzlabs_record_usage',{p_user:user.id,p_app:b.app,p_event:b.event}));return reply({ok:true});
  }
  const owner=isOwner(user);
  const admin=owner||!!check(await db.from('sportzlabs_admins').select('user_id').eq('user_id',user.id).maybeSingle());
  if(!admin)return reply({error:'This account does not have administrator access.'},403);
  const audit=async(action:string,target:string)=>check(await db.from('sportzlabs_audit').insert({user_id:user.id,action,target}));
  if(b.action==='overview'){
   const [apps,report,exercises,auditLog]=await Promise.all([db.from('sportzlabs_apps').select('*').order('name'),db.rpc('sportzlabs_usage_report'),db.from('sportzlabs_exercises').select('id',{count:'exact',head:true}),db.from('sportzlabs_audit').select('action,target,created_at').order('created_at',{ascending:false}).limit(20)]);
   check(exercises);return reply({owner,email:user.email,apps:check(apps),usage:check(report),exerciseOverrides:exercises.count,audit:check(auditLog)});
  }
  if(b.action==='users'){
   const page=Number.isInteger(b.page)&&b.page>0?b.page:1;
   const r=await db.auth.admin.listUsers({page,perPage:50});check(r);
   const records=r.data.users;
   const ids=records.map((u:any)=>u.id);
   const [accessRows,defaultTier]=await Promise.all([
    ids.length?db.from('sportzlabs_user_access').select('user_id,tier_id,addon_ids').in('user_id',ids):Promise.resolve({data:[],error:null}),
    db.from('sportzlabs_tiers').select('id').eq('is_default',true).maybeSingle()
   ]);
   const accessByUser=new Map(check(accessRows).map((v:any)=>[v.user_id,v]));
   const fallbackTier=check(defaultTier)?.id||'free';
   return reply({users:records.map((u:any)=>{const access=accessByUser.get(u.id);return {id:u.id,email:u.email,name:u.user_metadata?.display_name||'',created_at:u.created_at,last_sign_in_at:u.last_sign_in_at,verified:!!u.email_confirmed_at,tier_id:access?.tier_id||fallbackTier,addon_ids:access?.addon_ids||[]};}),total:r.data.total,page});
  }
  if(b.action==='accessCatalog'){
   const [capabilities,tiers,addons]=await Promise.all([
    db.from('sportzlabs_capabilities').select('*').order('key'),
    db.from('sportzlabs_tiers').select('*').order('sort_order').order('name'),
    db.from('sportzlabs_addons').select('*').order('name')
   ]);
   return reply({capabilities:check(capabilities),tiers:check(tiers),addons:check(addons)});
  }
  if(b.action==='blogList'){
   const [postResult,analyticsResult]=await Promise.all([db.from('sportzlabs_blog_posts').select('*').order('updated_at',{ascending:false}).limit(200),db.rpc('sportzlabs_blog_analytics')]);
   const posts=check(postResult);const analytics=check(analyticsResult);const metrics=posts.map((post:any)=>{const rows=analytics.filter((row:any)=>row.post_id===post.id);return {post_id:post.id,views:Number(rows.find((row:any)=>row.event==='view')?.event_count||0),app_clicks:Number(rows.find((row:any)=>row.event==='app_click')?.event_count||0)};});
   return reply({posts,analytics:metrics});
  }
  if(b.action==='saveBlogPost'){
   const v=b.post;
   const slug=typeof v?.slug==='string'?v.slug.trim().toLowerCase():'';
   const title=typeof v?.title==='string'?v.title.trim():'';
   const excerpt=typeof v?.excerpt==='string'?v.excerpt.trim():'';
   const content=typeof v?.content==='string'?v.content.trim():'';
   const category=typeof v?.category==='string'?v.category.trim():'Product updates';
   const authorName=typeof v?.author_name==='string'?v.author_name.trim():'SportzLabs';
   const status=v?.status==='published'?'published':'draft';
   const publishedAt=typeof v?.published_at==='string'&&Number.isFinite(Date.parse(v.published_at))?v.published_at:(status==='published'?new Date().toISOString():null);
   const seoTitle=typeof v?.seo_title==='string'?v.seo_title.trim():'';
   const seoDescription=typeof v?.seo_description==='string'?v.seo_description.trim():'';
   const coverImageUrl=typeof v?.cover_image_url==='string'?v.cover_image_url.trim():'';
   if(!/^[a-z0-9][a-z0-9-]*$/.test(slug)||slug.length>120||!title||title.length>160||excerpt.length>320||!content||content.length>100000||category.length>80||authorName.length>80||seoTitle.length>160||seoDescription.length>320||coverImageUrl.length>1000)return reply({error:'Add a valid slug, title and article content. Article HTML is limited to 100,000 characters and SEO fields are limited to standard lengths.'},400);
   const row={slug,title,excerpt,content,category,author_name:authorName,status,published_at:publishedAt,seo_title:seoTitle,seo_description:seoDescription,cover_image_url:coverImageUrl,updated_at:new Date().toISOString()};
   const result=v?.id?await db.from('sportzlabs_blog_posts').update(row).eq('id',v.id).select('*').single():await db.from('sportzlabs_blog_posts').insert(row).select('*').single();
   const saved=check(result);await audit(status==='published'?'Blog post published':'Blog draft saved',title);return reply({post:saved});
  }
  if(b.action==='deleteBlogPost'){
   if(typeof b.id!=='string')return reply({error:'Choose a blog post to remove.'},400);
   check(await db.from('sportzlabs_blog_posts').delete().eq('id',b.id));await audit('Blog post deleted',b.id);return reply({ok:true});
  }
  if(b.action==='saveCapability'){
   const value=validateCapability(b.capability);
   check(await db.from('sportzlabs_capabilities').upsert({...value,updated_at:new Date().toISOString()}));
   await audit('Capability saved',value.name);return reply({ok:true});
  }
  if(b.action==='saveTier'){
   const value=validateTier(b.tier);
   const existing=check(await db.from('sportzlabs_tiers').select('is_default').eq('id',value.id).maybeSingle());
   if(existing?.is_default&&!value.active)return reply({error:'The default Free tier must remain active.'},400);
   if(value.capability_keys.length){const keys=check(await db.from('sportzlabs_capabilities').select('key').in('key',value.capability_keys));if(keys.length!==value.capability_keys.length)return reply({error:'Choose capabilities that exist in the catalogue.'},400);}
   check(await db.from('sportzlabs_tiers').upsert({...value,is_default:!!existing?.is_default,updated_at:new Date().toISOString()}));
   await audit('Access tier saved',value.name);return reply({ok:true});
  }
  if(b.action==='saveAddon'){
   const value=validateAddon(b.addon);
   if(value.capability_keys.length){const keys=check(await db.from('sportzlabs_capabilities').select('key').in('key',value.capability_keys));if(keys.length!==value.capability_keys.length)return reply({error:'Choose capabilities that exist in the catalogue.'},400);}
   check(await db.from('sportzlabs_addons').upsert({...value,updated_at:new Date().toISOString()}));
   await audit('Access add-on saved',value.name);return reply({ok:true});
  }
  if(b.action==='setUserAccess'){
   const value=b.access;
   if(!value||typeof value.user_id!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value.user_id)||typeof value.tier_id!=='string'||!/^([a-z0-9][a-z0-9-]{0,59})$/.test(value.tier_id)||!Array.isArray(value.addon_ids)||value.addon_ids.length>50||value.addon_ids.some((id:any)=>typeof id!=='string'||!/^([a-z0-9][a-z0-9-]{0,59})$/.test(id)))return reply({error:'Choose a valid user, tier, and set of add-ons.'},400);
   const addonIds=[...new Set(value.addon_ids)];
   const tier=check(await db.from('sportzlabs_tiers').select('id,active').eq('id',value.tier_id).maybeSingle());
   if(!tier||!tier.active)return reply({error:'Choose an active tier.'},400);
   if(addonIds.length){const addons=check(await db.from('sportzlabs_addons').select('id,active').in('id',addonIds));if(addons.length!==addonIds.length||addons.some((v:any)=>!v.active))return reply({error:'Choose active add-ons that exist in the catalogue.'},400);}
   check(await db.from('sportzlabs_user_access').upsert({user_id:value.user_id,tier_id:value.tier_id,addon_ids:addonIds,updated_by:user.id,updated_at:new Date().toISOString()}));
   await audit('User access updated',value.user_id);return reply({ok:true});
  }
  if(b.action==='saveExercise'){
   const activity=validateExercise(b.activity);
   check(await db.from('sportzlabs_exercises').upsert({id:activity.id,activity,updated_at:new Date().toISOString()}));await audit('Exercise saved',activity.name);return reply({activity});
  }
  if(b.action==='integrations'){
   const data=check(await db.from('sportzlabs_integrations').select('*').order('name'));
   return reply({integrations:data.map((v:any)=>({id:v.id,name:v.name,client_id:v.client_id,enabled:v.enabled,notes:v.notes,configured:!!((v.client_id&&v.client_secret)||(v.id==='strava'&&Deno.env.get('STRAVA_CLIENT_ID')&&Deno.env.get('STRAVA_CLIENT_SECRET'))),hasSecret:!!v.client_secret,updated_at:v.updated_at}))});
  }
  if(b.action==='saveIntegration'){
   if(!owner)return reply({error:'Only the platform owner can change integration credentials.'},403);
   const v=b.integration;
   if(!v||!/^[-a-z0-9]{1,60}$/.test(v.id)||typeof v.name!=='string'||!v.name.trim()||v.name.length>100||typeof v.client_id!=='string'||v.client_id.length>300||typeof v.notes!=='string'||v.notes.length>2000||typeof v.enabled!=='boolean'||(v.client_secret!==undefined&&(typeof v.client_secret!=='string'||v.client_secret.length>3000)))return reply({error:'Invalid integration settings.'},400);
   const existing=check(await db.from('sportzlabs_integrations').select('client_secret').eq('id',v.id).maybeSingle());
   check(await db.from('sportzlabs_integrations').upsert({id:v.id,name:v.name.trim(),client_id:v.client_id.trim(),enabled:v.enabled,notes:v.notes,updated_at:new Date().toISOString(),client_secret:v.client_secret?.trim()||existing?.client_secret||''}));
   await audit('Integration settings saved',v.name);return reply({ok:true});
  }
  if(b.action==='saveApp'){
   const v=b.app;
   if(!v||!/^[-a-z0-9]{1,60}$/.test(v.id)||typeof v.name!=='string'||!v.name.trim()||v.name.length>100||typeof v.url!=='string'||v.url.length>1000||!validAppUrl(v.url)||typeof v.description!=='string'||v.description.length>500||!['live','planned'].includes(v.status))return reply({error:'Enter an app name, HTTPS address and valid status.'},400);
   check(await db.from('sportzlabs_apps').upsert({id:v.id,name:v.name.trim(),url:v.url,description:v.description,status:v.status}));await audit('Application saved',v.name);return reply({ok:true});
  }
  return reply({error:'Unknown action.'},400);
 }catch(e){return reply({error:e instanceof SyntaxError?'Invalid request.':e instanceof Error?e.message:'Unable to complete request.'},400);}
});
