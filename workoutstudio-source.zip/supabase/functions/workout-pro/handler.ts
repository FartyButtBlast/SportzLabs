import {readCapabilities} from './access.ts';
import {PROGRESSION,INSIGHTS,validateHistory,suggest,insights} from './engine.ts';
const origins=new Set(['https://workout-studio.derekenderby.chatgpt.site','https://www.sportzlabs.com','https://sportzlabs.com','http://127.0.0.1:5173','http://localhost:5173','capacitor://localhost','https://localhost','http://localhost']);
const MAX_BYTES=2*1024*1024;
export function createHandler(db:any,now:()=>number=Date.now){
 return async(req:Request):Promise<Response>=>{
  const origin=req.headers.get('origin')||'';
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin','Access-Control-Allow-Origin':origins.has(origin)?origin:'https://www.sportzlabs.com','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS'};
  const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
  if(origin&&!origins.has(origin))return reply({error:'Origin not allowed.'},403);
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(req.method!=='POST')return reply({error:'Use POST.'},405);
  try{
   const jwt=req.headers.get('authorization')?.replace(/^Bearer /i,'');
   if(!jwt)return reply({error:'Sign in to continue.'},401);
   const {data,error}=await db.auth.getUser(jwt);
   const user=data?.user;
   if(error||!user||user.is_anonymous||!user.email_confirmed_at)return reply({error:'A verified account is required.'},401);
   // Stream limit also handles chunked requests without trusting Content-Length.
   const reader=req.body?.getReader();let size=0;const chunks:Uint8Array[]=[];
   if(reader)while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX_BYTES){await reader.cancel();return reply({error:'Workout history is too large for one request.'},413);}chunks.push(value);}
   const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
   let body:any;try{body=JSON.parse(new TextDecoder().decode(bytes));}catch{return reply({error:'Invalid request.'},400);}
   if(!body||!['access','progression','insights'].includes(body.action))return reply({error:'Unknown action.'},400);
   const capabilities=await readCapabilities(db,user.id);
   const visible=capabilities.filter(k=>k===PROGRESSION||k===INSIGHTS);
   if(body.action==='access')return reply({capabilities:visible});
   const required=body.action==='progression'?PROGRESSION:INSIGHTS;
   if(!capabilities.includes(required))return reply({error:'This capability is not included in your access.',capabilities:visible},403);
   try{
    const timestamp=now();validateHistory(body.history,user.id,timestamp);
    const result=body.action==='progression'?suggest(body.history,body.templateId,body.exercise,body.target,body.rule,timestamp):insights(body.history,body.days,timestamp);
    return reply({capabilities:visible,result});
   }catch(error){return reply({error:error instanceof Error?error.message:'Invalid workout data.'},400);}
  }catch{return reply({error:'Unable to verify access. Please try again.'},503);}
 };
}
