import {createClient} from 'npm:@supabase/supabase-js@2.117.2';
import {createHandler} from './handler.ts';
const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
// getUser in the handler verifies the bearer token on every request.
Deno.serve(createHandler(db));
