export interface Tier { id: string; active: boolean; capability_keys: string[]; }
export interface Assignment { tier_id: string; addon_ids: string[]; }
// Only server-owned catalogue/assignment rows are inputs. Never use user metadata.
export async function readCapabilities(db: any, userId: string): Promise<string[]> {
  const check=(r:any)=>{if(r.error)throw new Error('Access verification unavailable.');return r.data;};
  const assignment=check(await db.from('sportzlabs_user_access').select('tier_id,addon_ids').eq('user_id',userId).maybeSingle()) as Assignment|null;
  const query=db.from('sportzlabs_tiers').select('id,active,capability_keys');
  const tier=check(await (assignment?query.eq('id',assignment.tier_id):query.eq('is_default',true)).maybeSingle()) as Tier|null;
  if(!tier?.active)return [];
  const keys=new Set(tier.capability_keys);
  if(assignment?.addon_ids.length){
    const addons=check(await db.from('sportzlabs_addons').select('id,active,capability_keys').in('id',assignment.addon_ids)) as Tier[];
    for(const addon of addons)if(addon.active)for(const key of addon.capability_keys)keys.add(key);
  }
  if(!keys.size)return [];
  const capabilities=check(await db.from('sportzlabs_capabilities').select('key,active').in('key',[...keys])) as {key:string;active:boolean}[];
  return capabilities.filter(c=>c.active&&keys.has(c.key)).map(c=>c.key);
}
