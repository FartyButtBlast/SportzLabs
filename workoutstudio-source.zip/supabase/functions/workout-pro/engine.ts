// Server-only calculations. Client imports from this module must be type-only.
export const PROGRESSION = 'workouts.progression';
export const INSIGHTS = 'workouts.insights.advanced';
export interface Rule { minReps: number; maxReps: number; increment: number; }
export interface Row { reps: number; weight: number; done: boolean; time?: number; distance?: number; }
export interface Log { activityId: string; name: string; type: string; metricMode?: string; tags: string[]; rows: Row[]; }
export interface History { id: string; userId: string; templateId: string; completedAt: string | null; sample?: boolean; activities: Log[]; }
export interface Exercise { id: string; name: string; type: string; metricMode?: string; }
export interface Target { sets: number; reps: number; weight: number; }
export interface Suggestion { kind: 'increase' | 'hold' | 'review'; weight: number; reps: number; reason: string; evidence: string[]; }
export interface Point { sessionId: string; date: string; sets: number; reps: number; volume: number; bestWeight: number; estimatedMax: number | null; }
export interface Summary { sessions: number; sets: number; volume: number; }
export type PBKind = 'weight'|'reps'|'volume'|'estimatedMax'|'duration'|'distance';
export interface PBRecord { kind: PBKind; value: number; unit: 'kg'|'reps'|'kg·reps'|'s'|'km'; date: string; sessionId: string; }
export interface ExercisePB { id: string; name: string; type: string; records: PBRecord[]; }
export interface PBEvent { sessionId: string; date: string; exercises: { id: string; name: string; records: PBRecord[] }[]; }
export interface Insights {
  days: number; from: string; previousFrom: string; to: string;
  current: Summary; previous: Summary;
  weeks: { from: string; to: string; sessions: number; sets: number; volume: number }[];
  muscles: { name: string; sets: number }[];
  exercises: { id: string; name: string; points: Point[] }[];
  personalBests: ExercisePB[];
  personalBestEvents: PBEvent[];
}
const DAY = 86400000;
const loaded = (a: Exercise | Log) => a.type === 'strength' && (!a.metricMode || a.metricMode === 'reps_weight');
const excluded = /assisted|assistance|band|push[ -]?up|pull[ -]?up|chin[ -]?up|dip\b|bodyweight|body weight|olympic|snatch|clean\b|jerk\b|jump|swing|throw|plyo/i;
export const eligible = (a: Exercise) => loaded(a) && !excluded.test(a.name);
const validNumber = (n: unknown, max: number, integer = false) => typeof n === 'number' && Number.isFinite(n) && n >= 0 && n <= max && (!integer || Number.isInteger(n));
const label = (s: unknown): s is string => typeof s === 'string' && s.length > 0 && s.length <= 200;
export function validateHistory(value: unknown, userId: string, now: number): asserts value is History[] {
  if (!Array.isArray(value) || value.length > 1000) throw new Error('Use up to 1,000 completed sessions.');
  const ids = new Set<string>();
  for (const s of value) {
    if (!s || s.userId !== userId || !label(s.id) || ids.has(s.id) || !label(s.templateId) || typeof s.completedAt !== 'string' || !Number.isFinite(Date.parse(s.completedAt)) || Date.parse(s.completedAt) > now + 60000 || !Array.isArray(s.activities) || s.activities.length > 100) throw new Error('Invalid workout history.');
    ids.add(s.id);
    for (const a of s.activities) {
      if (!a || !label(a.activityId) || !label(a.name) || !['strength','cardio','stretching'].includes(a.type) || (a.metricMode !== undefined && !['reps_weight','time_weight','time_distance','time_reps'].includes(a.metricMode)) || !Array.isArray(a.tags) || a.tags.length > 30 || !a.tags.every(label) || !Array.isArray(a.rows) || a.rows.length > 100) throw new Error('Invalid exercise history.');
      if (!a.rows.every((r: Row) => r && typeof r.done === 'boolean' && validNumber(r.reps, 10000, true) && validNumber(r.weight, 10000) && (r.time === undefined || validNumber(r.time, 1000000, true)) && (r.distance === undefined || validNumber(r.distance, 1000000)))) throw new Error('Invalid set values.');
    }
  }
}
export function validateProgression(exercise: Exercise, target: Target, rule: Rule, templateId: string) {
  if (!exercise || !label(exercise.id) || !label(exercise.name) || !label(templateId) || !eligible(exercise)) throw new Error('Choose a conventional externally loaded repetition exercise.');
  if (!target || !validNumber(target.sets,30,true) || target.sets < 1 || !validNumber(target.reps,100,true) || !validNumber(target.weight,1000) || target.weight <= 0) throw new Error('Set a positive working weight and valid set targets first.');
  if (!rule || !validNumber(rule.minReps,30,true) || rule.minReps < 1 || !validNumber(rule.maxReps,30,true) || rule.maxReps < rule.minReps || !validNumber(rule.increment,50) || rule.increment < 0.1) throw new Error('Use a rep range from 1–30 and an increment from 0.1–50 kg.');
}
export function suggest(history: History[], templateId: string, exercise: Exercise, target: Target, rule: Rule, now = Date.now()): Suggestion {
  validateProgression(exercise,target,rule,templateId);
  const sessions = history.filter(s => !s.sample && s.completedAt && s.templateId === templateId && s.activities.some(a=>a.activityId===exercise.id)).sort((a,b)=>Date.parse(b.completedAt!)-Date.parse(a.completedAt!)).slice(0,2);
  const result = (kind: Suggestion['kind'], reason: string, weight=target.weight, reps=target.reps): Suggestion => ({kind,reason,weight,reps,evidence:sessions.map(s=>s.completedAt!)});
  if (sessions.length < 2) return result('hold','Record two completed sessions of this exercise in this workout before increasing the load.');
  if (now-Date.parse(sessions[0].completedAt!) > 28*DAY || Date.parse(sessions[0].completedAt!)-Date.parse(sessions[1].completedAt!) > 28*DAY) return result('review','There has been a break of more than 28 days. Review your starting target before progressing.');
  const logs = sessions.map(s=>s.activities.filter(a=>a.activityId===exercise.id));
  if (logs.some(a=>a.length!==1 || !loaded(a[0]) || a[0].name!==exercise.name)) return result('review','Exercise details changed or this exercise appears more than once. Review the target manually.');
  // V1 requires exactly the configured working sets. Extra warm-up/drop sets make
  // the comparison ambiguous; do not infer which rows were working sets.
  if (logs.some(([a])=>a.rows.length!==target.sets || a.rows.some(r=>!r.done || Math.abs(r.weight-target.weight)>0.001))) return result('hold','Both sessions must contain exactly the configured working sets, all completed at the current target weight. Log warm-ups separately.');
  if (logs.some(([a])=>a.rows.some(r=>r.reps<rule.maxReps))) return result('hold',`Keep the weight and work toward ${rule.maxReps} reps on each working set. Both sessions must reach the top of your range.`);
  const next = Math.round((target.weight+rule.increment)*100)/100;
  if (rule.increment/target.weight > 0.10 || next > 1000) return result('review','The selected increase is larger than this rule allows (10% of the current load). Choose a smaller increment or review the target manually.');
  return result('increase',`All ${target.sets} working sets reached at least ${rule.maxReps} reps at ${target.weight} kg in two consecutive matching sessions.`,next,rule.minReps);
}
export function insights(history: History[], days: number, now = Date.now()): Insights {
  if (![28,84].includes(days)) throw new Error('Choose 28 or 84 days.');
  const from=now-days*DAY, prior=from-days*DAY;
  const sessions=history.filter(s=>!s.sample && s.completedAt && Date.parse(s.completedAt)>=prior && Date.parse(s.completedAt)<now);
  const current=sessions.filter(s=>Date.parse(s.completedAt!)>=from), previous=sessions.filter(s=>Date.parse(s.completedAt!)<from);
  const summary=(ss:History[]):Summary=>({sessions:ss.length,sets:ss.reduce((n,s)=>n+s.activities.filter(a=>a.type==='strength').reduce((m,a)=>m+a.rows.filter(r=>r.done).length,0),0),volume:ss.reduce((n,s)=>n+s.activities.filter(loaded).reduce((m,a)=>m+a.rows.filter(r=>r.done).reduce((v,r)=>v+r.weight*r.reps,0),0),0)});
  const muscles=new Map<string,number>(), exercises=new Map<string,{id:string;name:string;points:Point[]}>();
  for(const s of [...current].sort((a,b)=>Date.parse(a.completedAt!)-Date.parse(b.completedAt!))) for(const a of s.activities) {
    const rows=a.rows.filter(r=>r.done);
    if(a.type==='strength') for(const tag of new Set(a.tags.filter(t=>t!=='cardio'))) muscles.set(tag,(muscles.get(tag)||0)+rows.length);
    if(!loaded(a) || !rows.length) continue;
    const entry=exercises.get(a.activityId)||{id:a.activityId,name:a.name,points:[]};
    entry.name=a.name;
    const estimates=rows.filter(r=>r.weight>0 && r.reps>=1 && r.reps<=10 && !excluded.test(a.name)).map(r=>r.reps===1?r.weight:r.weight*(1+r.reps/30));
    const point:Point={sessionId:s.id,date:s.completedAt!,sets:rows.length,reps:rows.reduce((n,r)=>n+r.reps,0),volume:rows.reduce((n,r)=>n+r.weight*r.reps,0),bestWeight:Math.max(...rows.map(r=>r.weight)),estimatedMax:estimates.length?Math.round(Math.max(...estimates)*10)/10:null};
    const old=entry.points.find(p=>p.sessionId===s.id);
    if(old){old.sets+=point.sets;old.reps+=point.reps;old.volume+=point.volume;old.bestWeight=Math.max(old.bestWeight,point.bestWeight);old.estimatedMax=old.estimatedMax===null?point.estimatedMax:point.estimatedMax===null?old.estimatedMax:Math.max(old.estimatedMax,point.estimatedMax);}else entry.points.push(point);
    exercises.set(a.activityId,entry);
  }
  const personalBests = new Map<string, ExercisePB>();
  const bestValues = new Map<string, Map<PBKind, number>>();
  const personalBestEvents: PBEvent[] = [];
  const metricUnit: Record<PBKind, PBRecord['unit']> = {weight:'kg',reps:'reps',volume:'kg·reps',estimatedMax:'kg',duration:'s',distance:'km'};
  const addMetric = (metrics: Map<PBKind,number>, kind: PBKind, value: number) => {
    if (Number.isFinite(value) && value > 0) metrics.set(kind, Math.max(metrics.get(kind) || 0, value));
  };
  const metricsFor = (a: Log): Map<PBKind,number> => {
    const metrics = new Map<PBKind,number>(), rows = a.rows.filter(r=>r.done);
    if (!rows.length) return metrics;
    const mode = a.metricMode || (a.type === 'strength' ? 'reps_weight' : undefined);
    if (a.type === 'strength' && mode === 'reps_weight') {
      addMetric(metrics,'weight',Math.max(...rows.map(r=>r.weight)));
      addMetric(metrics,'reps',Math.max(...rows.map(r=>r.reps)));
      addMetric(metrics,'volume',rows.reduce((n,r)=>n+r.weight*r.reps,0));
      const estimates=rows.filter(r=>r.weight>0&&r.reps>=1&&r.reps<=10&&!excluded.test(a.name)).map(r=>r.reps===1?r.weight:r.weight*(1+r.reps/30));
      if(estimates.length) addMetric(metrics,'estimatedMax',Math.max(...estimates));
    } else {
      if (rows.some(r=>(r.time||0)>0)) addMetric(metrics,'duration',rows.reduce((n,r)=>n+(r.time||0),0));
      if (rows.some(r=>(r.distance||0)>0)) addMetric(metrics,'distance',rows.reduce((n,r)=>n+(r.distance||0),0));
      if (rows.some(r=>r.reps>0)) addMetric(metrics,'reps',rows.reduce((n,r)=>n+r.reps,0));
    }
    return metrics;
  };
  const ordered = history.filter(s=>!s.sample&&s.completedAt&&Date.parse(s.completedAt)<now).sort((a,b)=>Date.parse(a.completedAt!)-Date.parse(b.completedAt!));
  for (const s of ordered) {
    const sessionExercises = new Map<string,{name:string;type:string;metrics:Map<PBKind,number>}>();
    for (const a of s.activities) {
      const metrics = metricsFor(a); if (!metrics.size) continue;
      const current=sessionExercises.get(a.activityId)||{name:a.name,type:a.type,metrics:new Map<PBKind,number>()};
      for (const [kind,value] of metrics) current.metrics.set(kind,kind==='volume'||kind==='duration'||kind==='distance'||kind==='reps'?((current.metrics.get(kind)||0)+value):Math.max(current.metrics.get(kind)||0,value));
      sessionExercises.set(a.activityId,current);
    }
    const eventExercises: PBEvent['exercises'] = [];
    for (const [id,entry] of sessionExercises) {
      const best=bestValues.get(id)||new Map<PBKind,number>(), records: PBRecord[] = [];
      for (const [kind,value] of entry.metrics) if (!best.has(kind)||value>best.get(kind)!+0.000001) {
        const record: PBRecord={kind,value:Math.round(value*10)/10,unit:metricUnit[kind],date:s.completedAt!,sessionId:s.id};
        records.push(record);best.set(kind,value);
      }
      bestValues.set(id,best);
      const existing=personalBests.get(id)||{id,name:entry.name,type:entry.type,records:[]};
      const recordByKind=new Map(existing.records.map(record=>[record.kind,record]));
      for(const record of records) recordByKind.set(record.kind,record);
      existing.name=entry.name; existing.records=[...recordByKind.values()];
      personalBests.set(id,existing);
      if(records.length) eventExercises.push({id,name:entry.name,records});
    }
    if(eventExercises.length) personalBestEvents.push({sessionId:s.id,date:s.completedAt!,exercises:eventExercises});
  }
  const periodEvents=personalBestEvents.filter(e=>Date.parse(e.date)>=from&&Date.parse(e.date)<now);
  return {days,from:new Date(from).toISOString(),previousFrom:new Date(prior).toISOString(),to:new Date(now).toISOString(),current:summary(current),previous:summary(previous),
    weeks:Array.from({length:days/7},(_,i)=>{const start=from+i*7*DAY,end=start+7*DAY;return {from:new Date(start).toISOString(),to:new Date(end).toISOString(),...summary(current.filter(s=>Date.parse(s.completedAt!)>=start&&Date.parse(s.completedAt!)<end))};}),
    muscles:[...muscles].map(([name,sets])=>({name,sets})).sort((a,b)=>b.sets-a.sets),exercises:[...exercises.values()].sort((a,b)=>a.name.localeCompare(b.name)),personalBests:[...personalBests.values()].sort((a,b)=>a.name.localeCompare(b.name)),personalBestEvents:periodEvents};
}
