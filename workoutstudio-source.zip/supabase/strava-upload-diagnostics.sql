-- Diagnostic responses stay in the existing server-only, RLS-protected table.
alter table public.workoutstudio_strava_posts
 add column if not exists structured_diagnostic jsonb,
 add column if not exists summary_diagnostic jsonb;
comment on column public.workoutstudio_strava_posts.structured_diagnostic is 'Bounded Strava rejection fields only; no request payload, headers or tokens. Server-only support diagnostics.';
comment on column public.workoutstudio_strava_posts.summary_diagnostic is 'Bounded Strava summary rejection fields only. Server-only support diagnostics.';
