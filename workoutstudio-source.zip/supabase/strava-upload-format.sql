alter table public.workoutstudio_strava_posts
 add column if not exists upload_format text check (upload_format in ('json','fit','summary'));
comment on column public.workoutstudio_strava_posts.upload_format is 'Format associated with the current upload attempt; preserves safe JSON to FIT to summary recovery across retries.';
