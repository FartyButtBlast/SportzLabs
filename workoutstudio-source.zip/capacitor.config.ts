import type { CapacitorConfig } from '@capacitor/cli';
const config:CapacitorConfig={
 appId:'com.sportzlabs.workoutstudio',
 appName:'Workout Studio',
 webDir:'dist-native',
 ios:{contentInset:'automatic'},
 android:{allowMixedContent:false},
};
export default config;
